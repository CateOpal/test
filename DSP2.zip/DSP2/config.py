"""全局配置。

安全约定：任何密钥都不写死在业务代码里。
优先级：进程环境变量 > 项目根目录 .env 文件 > 报错提示。
"""

from __future__ import annotations

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
ENV_FILE = BASE_DIR / ".env"


def _load_env_file(path: Path) -> None:
    """读取简易 KEY=VALUE 格式的 .env，不覆盖已存在的环境变量。"""
    if not path.exists():
        return
    try:
        raw_text = path.read_text(encoding="utf-8")
    except OSError:
        return
    for raw_line in raw_text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


_load_env_file(ENV_FILE)


def _env_bool(name: str, default: bool) -> bool:
    value = os.environ.get(name)
    if value is None:
        return default
    return value.strip().lower() not in ("0", "false", "no", "off", "")


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except ValueError:
        return default


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.environ.get(name, default))
    except ValueError:
        return default


# ---------------------------------------------------------------- DeepSeek
DEEPSEEK_API_KEY: str = os.environ.get("DEEPSEEK_API_KEY", "").strip()
DEEPSEEK_BASE_URL: str = os.environ.get(
    "DEEPSEEK_BASE_URL", "https://api.deepseek.com"
).strip().rstrip("/")
# deepseek-chat = 非思考模型；deepseek-flash 默认带 thinking，靠 thinking 参数关闭
MODEL: str = os.environ.get("DEEPSEEK_MODEL", "deepseek-chat").strip()
# 关闭思维链：真人聊天不会先把内心推理发出来
DISABLE_THINKING: bool = _env_bool("DEEPSEEK_DISABLE_THINKING", True)
REQUEST_TIMEOUT: float = _env_float("DEEPSEEK_TIMEOUT", 60.0)
JSON_MAX_RETRY: int = _env_int("JSON_MAX_RETRY", 3)
MAX_CONCURRENCY: int = _env_int("MAX_CONCURRENCY", 6)

# ---------------------------------------------------------------- 数据布局
USER_ID: str = os.environ.get("DSG_USER_ID", "user_001")
# 不写死任何默认名字：用户叫什么只能来自登录/建档时自己的输入。
# 留空 = 没有兜底名，调用方必须显式提供（否则 create_account 会拒绝空名）。
DEFAULT_USER_NAME: str = os.environ.get("DSG_USER_NAME", "")

# ---------------------------------------------------------------- 调度参数
# 需求钟摆的巡检间隔（秒）。真实使用建议 180~600，演示可调小。
PROACTIVE_TICK_SECONDS: int = _env_int("PROACTIVE_TICK_SECONDS", 60)
# 防抖窗口（秒）：用户连发碎句时合并成一条。
# 1.5s/2s 都太短 —— 真人打字需要时间，窗口内继续打字要滑动顺延，
# 停打满 3 秒才把这几句用 \n 拼接成一段提交给路由。
DEBOUNCE_WINDOW: float = _env_float("DEBOUNCE_WINDOW", 3.0)
# 每日主动消息上限（兜底，真实幅度由 ⑦ 号 API 的 proactive_intensity 决定）
RATE_LIMIT_PER_CHAR_PER_DAY: int = _env_int("RATE_LIMIT_PER_CHAR_PER_DAY", 6)
# 反思（⑫）允许触发的小时
REFLECTION_HOURS: tuple = tuple(
    int(h) for h in os.environ.get("REFLECTION_HOURS", "23,3").split(",") if h.strip()
)
# 记忆衰减（⑬）间隔天数
DECAY_INTERVAL_DAYS: int = _env_int("DECAY_INTERVAL_DAYS", 7)
# 每 N 轮跑一次画像/事件类慢速 API
SLOW_ANALYZE_EVERY: int = _env_int("SLOW_ANALYZE_EVERY", 4)
# ⑮ 意识流的最小间隔（分钟）。独处走神不需要每分钟算一次，
# 调太小会白烧钱，也会让 ⑦ 的巡检被拖慢。
CONSCIOUSNESS_EVERY_MINUTES: int = _env_int("CONSCIOUSNESS_EVERY_MINUTES", 20)
# 特征候选中计数达到该值才写进 state.json
TRAIT_CONFIRM_COUNT: int = _env_int("TRAIT_CONFIRM_COUNT", 3)
# 短期上下文保留条数
BUFFER_MAX_KEEP: int = _env_int("BUFFER_MAX_KEEP", 30)

# ---------------------------------------------------------------- 识图
# 当前主模型（deepseek-chat）不接受图像输入。想让 ③ 号真的"看得见图"，
# 需要一个支持视觉的 OpenAI 兼容端点，并把这里打开。关着的时候优雅降级为纯文本。
VISION_ENABLED: bool = _env_bool("DSG_VISION_ENABLED", False)

# ---------------------------------------------------------------- ⑲ 人格种子
# 创建角色时用户没填"基础性格"：掷一次骰子，98% 由 ⑲ 生成一个完整的随机人
# （大五/暗黑三角/创伤/全职业谱系），剩下 2% 才是中性骨架。
PERSONA_SEED_PROBABILITY: float = _env_float("PERSONA_SEED_PROBABILITY", 0.98)

# ---------------------------------------------------------------- 联网搜索（工具调用）
# 打开后 ① 在需要实时信息时可发起 tool_calls，由后端拦截执行并把结果回注。
# 端点需为 OpenAI 兼容工具调用的模型 + 一个自建搜索 HTTP 服务（如 SearXNG）。
WEB_SEARCH_ENABLED: bool = _env_bool("DSG_WEB_SEARCH_ENABLED", False)
WEB_SEARCH_ENDPOINT: str = os.environ.get("DSG_WEB_SEARCH_ENDPOINT", "").strip()

# ---------------------------------------------------------------- 撤回
# 用户发出消息后，允许撤回自己的上一句的时间窗口（秒）
USER_RECALL_WINDOW: float = _env_float("USER_RECALL_WINDOW", 2.0)
# 同一轮对话中，间隔超过这个秒数才插一条仿微信的时间提示
TIME_SEPARATOR_SECONDS: int = _env_int("TIME_SEPARATOR_SECONDS", 180)

# ---------------------------------------------------------------- UI 个性化
# 头像/背景仅为 UI 展示用，不进入任何 API 上下文
BG_IMAGE: str = os.environ.get("DSG_BG_IMAGE", "").strip()
DEFAULT_AVATAR: str = os.environ.get("DSG_DEFAULT_AVATAR", "").strip()
WINDOW_WIDTH: int = _env_int("DSG_WINDOW_WIDTH", 1100)
WINDOW_HEIGHT: int = _env_int("DSG_WINDOW_HEIGHT", 690)
WINDOW_TITLE: str = os.environ.get("DSG_WINDOW_TITLE", "DSG")

# ---------------------------------------------------------------- 通知
ENABLE_NOTIFY: bool = _env_bool("DSG_ENABLE_NOTIFY", True)


def require_api_key() -> str:
    """入口处统一校验密钥是否已配置。"""
    if DEEPSEEK_API_KEY:
        return DEEPSEEK_API_KEY
    raise SystemExit(
        "\n[配置缺失] 未检测到 DeepSeek API Key。\n"
        "  方式一（推荐）：在项目根目录 DSP2/.env 中写入  DEEPSEEK_API_KEY=sk-xxxxxx\n"
        "  方式二：设置环境变量 DEEPSEEK_API_KEY\n"
    )
