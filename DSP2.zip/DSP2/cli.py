"""命令行模式：不装环境也能跑完整链路（用于验证 17 个 API 真的在动）。

    python cli.py                      选一个已有角色开聊
    python cli.py new                  走创建向导
    python cli.py new --name 林晚 ...  一步创建
    python cli.py list                 列出角色
    python cli.py state <id>           打印生命状态
"""

from __future__ import annotations

import argparse
import asyncio
import sys
from typing import Optional

from config import DEFAULT_USER_NAME, require_api_key
from service import CharacterForm, DSPService


def _pick_char(service: DSPService) -> str:
    ids = service.char_ids()
    if not ids:
        print("还没有任何角色，先执行：python cli.py new")
        sys.exit(1)
    if len(ids) == 1:
        return ids[0]
    print("已有角色：")
    for index, char_id in enumerate(ids, 1):
        print(f"  {index}. {service.name_of(char_id)} ({char_id})")
    choice = input("选择编号：").strip()
    try:
        return ids[int(choice) - 1]
    except (ValueError, IndexError):
        return ids[0]


async def cmd_new(service: DSPService, args: argparse.Namespace) -> None:
    print("—— 创建角色（带 * 的是必填）——")
    name = args.name or input("* 角色名：").strip()
    gender = args.gender or (input("性别（女/男，默认女）：").strip() or "女")
    age_raw = args.age or input("年龄（默认 24）：").strip() or "24"
    try:
        age = int(age_raw)
    except ValueError:
        age = 24
    birthday = args.birthday or input("生日 YYYY-MM-DD（可留空）：").strip()
    occupation = args.occupation or input("职业（可留空）：").strip()
    expertise = args.expertise or input("特长（逗号分隔，可留空）：").strip()
    persona = args.persona or input("* 基础性格（一段自然语言）：").strip()

    print("正在把人设翻译成数值基线……")
    char_id = service.create_character(
        CharacterForm(
            display_name=name,
            gender=gender,
            age=age,
            birthday=birthday,
            base_persona=persona,
            occupation=occupation,
            expertise=expertise,
        )
    )
    print(f"创建完成：{name}（{char_id}）")
    await service.start_background()
    print("后台生命已挂上，可以直接聊天了：python cli.py", char_id)


async def cmd_chat(service: DSPService, char_id: str) -> None:
    name = service.name_of(char_id)
    await service.start_background()
    def _on_proactive(cid, msgs, meta):
        first = ""
        for item in msgs:
            if isinstance(item, dict) and item.get("text"):
                first = str(item["text"])
                break
        print(f"\n〔{name} 主动开口 · {meta.get('trigger_reason', '')}〕{first}\n你：", end="", flush=True)

    service.subscribe(_on_proactive)
    print(f"\n=== 正在和 {name} 聊天（{service.user_name()} 是你自己）===")
    print("    /state 看她的状态 | /rename 改你自己的名字 | /wake 手动触发一次主动消息 | /q 退出")
    history = service.history(char_id, limit=20)
    for msg in history[-10:]:
        prefix = "你" if msg.get("role") == "user" else name
        print(f"{prefix}：{msg.get('text')}")

    loop = asyncio.get_event_loop()
    while True:
        try:
            text = await loop.run_in_executor(None, input, "你：")
        except (EOFError, KeyboardInterrupt):
            break
        text = (text or "").strip()
        if not text:
            continue
        if text in ("/q", "/quit", "exit"):
            break
        if text == "/state":
            from ui.dialogs import _render

            print(_render(service.summary(char_id)))
            continue
        if text == "/rename":
            new_name = (await loop.run_in_executor(None, input, "新名字：")).strip()
            if new_name:
                service.rename_user(new_name)
                print(f"已改名：{new_name}（她下一轮会看到这个称呼）")
            continue
        if text == "/wake":
            await service.force_proactive(char_id)
            continue
        def _on_result(result) -> None:
            codes = " ".join(result.get("codes") or [])
            print(f"{name}：{result.get('text')}")
            print(f"   〔本轮唤醒 {codes}　耗时 {result.get('elapsed', 0):.1f}s〕", flush=True)

        await service.send(char_id, text, _on_result)


def cmd_list(service: DSPService) -> None:
    ids = service.char_ids()
    if not ids:
        print("（空）")
        return
    for char_id in ids:
        meta = service.registry.get(char_id).load("meta.json")
        print(f"{char_id}\t{meta.get('display_name')}\t{meta.get('last_message_preview') or ''}")


def cmd_state(service: DSPService, char_id: str) -> None:
    from ui.dialogs import _render

    print(_render(service.summary(char_id)))


async def amain() -> None:
    parser = argparse.ArgumentParser(description="DSP2 拟真数字生命 —— 命令行模式")
    parser.add_argument("command", nargs="?", default="chat", choices=["chat", "new", "list", "state", "ui"])
    parser.add_argument("char_id", nargs="?", default="")
    parser.add_argument("--name", default="")
    parser.add_argument("--gender", default="")
    parser.add_argument("--age", default="")
    parser.add_argument("--birthday", default="")
    parser.add_argument("--occupation", default="")
    parser.add_argument("--expertise", default="")
    parser.add_argument("--persona", default="")
    args = parser.parse_args()

    if args.command == "ui":
        from ui.app import run

        run()
        return

    require_api_key()
    service = DSPService()

    # 没有用户档案就先建档：名字要注入给 ① 做称呼锚点
    if args.command in ("new", "chat", "state") and not service.has_account():
        print("第一次使用，先给你自己建个档案（角色会用这个名字称呼你）。")
        name = input("你的名字：").strip() or DEFAULT_USER_NAME
        service.create_account(name)
        print(f"已建档：{name}\n")

    if args.command == "new":
        await cmd_new(service, args)
    elif args.command == "list":
        cmd_list(service)
    elif args.command == "state":
        cmd_state(service, args.char_id or _pick_char(service))
    else:
        char_id = args.char_id or _pick_char(service)
        try:
            await cmd_chat(service, char_id)
        finally:
            await service.stop_background()


def main() -> None:
    try:
        asyncio.run(amain())
    except KeyboardInterrupt:
        print("\n已退出")


if __name__ == "__main__":
    main()
