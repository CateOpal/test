"""自检脚本。

    python main.py smoke            离线自检（用桩模型跑通全链路，不花 token）
    python main.py smoke --online   真实调用 DeepSeek 跑一轮（会消耗少量 token）

检查项：
1. 17 个 API 全部可实例化，编号无重复
2. 角色创建 → JSON 七件套落盘 → SQLite 可用
3. 一轮对话流水线跑完（⓪ 路由 → 专家 → 写状态 → ① → ⑨）
4. 后台生命循环能启动、能停
"""

from __future__ import annotations

import asyncio
import json
import shutil
import sys
import tempfile
from pathlib import Path

import flet as ft
from typing import Any, Dict, List, Optional, Sequence

SMOKE_DIR = Path(tempfile.gettempdir()) / "dsp2_smoke"


class StubLLM:
    """离线桩：接口签名与 DeepSeekClient 完全一致，返回合法的最小 JSON。"""

    api_key = "stub"
    model = "stub"
    stats = {"calls": 0, "prompt_tokens": 0, "completion_tokens": 0, "json_retries": 0, "failures": 0}

    SAMPLES: Dict[str, Any] = {
        "required_apis": ["①", "④", "⑨"],
        "scene_intent": "normal",
        "is_minimal": False,
        "label": "平静",
        "energy": 0.6,
        "affection": 0.15,
        "trust": 0.35,
        "alignment": 0.32,
        "dependency": 0.08,
        "dominance": 0.5,
        "boundary": 0.85,
        "conflict_state": "正常",
        "event": "第一次认真聊天",
        "unresolved": "",
        "arousal": "normal",
        "event_type": "chat",
        "action": "wait",
        "wait_seconds": 60,
        "is_risk": False,
        "block_output": False,
        "crisis_reply": "",
        "relationship_penalty": 0.0,
        "messages": [{"text": "嗯，我在。（离线桩回复）", "delay_ms": 600, "action": "send", "kind": "reply"}],
        "draft_text": "在吗，刚才突然想到你",
        "archive_ids": [],
        "display_name": None,
        "facts": [],
        "new_traits": [],
        "diary_md": "",
        "needs_longform": False,
        "block": False,
        "block_reason": "",
        "topic_hint": "",
        "tone_restraint": 0.5,
        "max_messages": 1,
        "emotion_tag": "平静",
        "subtext": "",
        "hidden_fact": "",
        "nickname": None,
        "current_topics": [],
        "insight": "",
        "style_notes": "",
        "trait_delta": 0.0,
        "reply": "嗯，我在。（离线桩回复）",
        "reason": "离线桩",
    }

    def chat(self, system: str, user: Optional[str] = None, messages=None, *,
             json_mode: bool = False, max_tokens: int = 400, temperature: Optional[float] = None) -> str:
        self.stats["calls"] += 1
        return "嗯，我在。（离线桩回复）"

    def chat_json(self, system: str, user: str, *, required: Optional[Sequence[str]] = None,
                  fallback: Optional[Any] = None, retries: int = 1, max_tokens: int = 400,
                  temperature: Optional[float] = None) -> Any:
        self.stats["calls"] += 1
        if not required:
            return fallback if fallback is not None else {}
        data: Dict[str, Any] = {}
        for key in required:
            data[key] = self.SAMPLES.get(key, self._guess(key))
        return data

    @staticmethod
    def _guess(key: str) -> Any:
        lowered = key.lower()
        if "list" in lowered or lowered.endswith("s") or lowered.endswith("_found"):
            return []
        if lowered.endswith("ids"):
            return []
        if "id" in lowered:
            return 1
        if "text" in lowered or "reply" in lowered or "draft" in lowered:
            return "嗯，我在。"
        return 0.0


def _ok(label: str, passed: bool, detail: str = "") -> bool:
    mark = "✓" if passed else "✗"
    print(f"  {mark} {label}{(' —— ' + detail) if detail else ''}")
    return passed


async def _check_login_click(base_dir: Path) -> bool:
    """回归用例：点登录页的「进入」，协程必须真的被执行。

    曾经的事故：同步事件处理器里写 `on_success(name)`，而 `_on_login` 是 async def，
    返回的协程没人 await → 不建档、不切界面、UI 毫无反应，只在控制台留一句
    RuntimeWarning: coroutine ... was never awaited。
    """
    import asyncio
    import shutil as _shutil
    from unittest.mock import MagicMock

    from service import DSPService
    from ui.app import DSPApp

    fresh = base_dir / "login_click"
    if fresh.exists():
        _shutil.rmtree(fresh, ignore_errors=True)
    fresh.mkdir(parents=True, exist_ok=True)

    async def main() -> bool:
        service = DSPService(api_key="stub", data_dir=fresh)
        service.llm.api_key = ""
        page = MagicMock()
        page.services = []
        page.window = MagicMock()
        # 让 mock 的 page 像真 page 一样把协程函数丢进当前事件循环
        page.run_task = lambda handler, *a, **k: asyncio.get_running_loop().create_task(handler(*a, **k))

        app = DSPApp(page, service)
        await app.mount()
        shown = app.body.content is not app.root
        ok = _ok("未建档时显示登录页", shown)
        if not shown:
            return ok

        def walk(control, out) -> None:
            if getattr(control, "on_submit", None):
                out.append(control)
            for child in (getattr(control, "controls", None) or []):
                walk(child, out)
            sub = getattr(control, "content", None)
            if sub is not None and sub is not control:
                walk(sub, out)

        def walk_dropdowns(control, out) -> None:
            if isinstance(control, ft.Dropdown):
                out.append(control)
            for child in (getattr(control, "controls", None) or []):
                walk_dropdowns(child, out)
            sub = getattr(control, "content", None)
            if sub is not None and sub is not control:
                walk_dropdowns(sub, out)

        inputs = []
        walk(app.body.content, inputs)
        dropdowns = []
        walk_dropdowns(app.body.content, dropdowns)
        if not inputs:
            return ok & _ok("登录页有输入框", False)
        # 用户名 + 出生年月日 是两个输入框，性别是下拉框
        inputs[0].value = "猫眼石"
        if len(inputs) > 1:
            inputs[1].value = "2000-05-12"
        dropdowns = []
        walk_dropdowns(app.body.content, dropdowns)
        if dropdowns:
            dropdowns[0].value = "女"
        # 真实点击路径：控件回调 → fire() → async _on_login(dict)
        inputs[0].on_submit(None)
        for _ in range(60):
            await asyncio.sleep(0.05)
            if app.body.content is app.root:
                break

        ok &= _ok("点「进入」真的建档了", service.has_account())
        ok &= _ok("点「进入」真的切进主界面", app.body.content is app.root)
        ok &= _ok("名字进档案", service.user_name() == "猫眼石", service.user_name())

        # 登录表单：除头像外全部必填，飘红且不放行
        await asyncio.to_thread(shutil.rmtree, fresh, ignore_errors=True)
        service2 = DSPService(api_key="stub", data_dir=fresh)
        service2.llm.api_key = ""
        from ui.login_window import build_login_view

        probe_page = MagicMock()
        probe_page.services = []
        probe_page.window = MagicMock()
        view = build_login_view(probe_page, lambda form: None)
        texts = []
        fields = []

        def _collect(control) -> None:
            if isinstance(control, ft.TextField):
                fields.append(control)
            if isinstance(control, ft.Text) and (control.value or ""):
                texts.append(control)
            for child in (getattr(control, "controls", None) or []):
                _collect(child)
            sub = getattr(control, "content", None)
            if sub is not None and sub is not control:
                _collect(sub)

        _collect(view)
        from core import account as acc2

        ok &= _ok("登录表单有 2 个输入框", len(fields) == 2, str(len(fields)))
        ok &= _ok("空表单被判必填", bool(acc2.validate_form("", "", "")))
        ok &= _ok("生日格式错会被拦下", bool(acc2.validate_form("猫眼石", "女", "2000/05/12")))
        ok &= _ok(
            "性别生日写不进 API 视图",
            "gender" not in acc2.api_view({"display_name": "a", "gender": "女", "birthday": "2000-05-12"}),
        )
        try:
            await asyncio.get_running_loop().create_task(asyncio.sleep(0))
        except Exception:  # noqa: BLE001
            pass
        return bool(ok)
        try:
            await app.dispose()
        except Exception:  # noqa: BLE001
            pass
        return bool(ok)

    return await main()


async def offline_smoke() -> int:
    print("[1/4] 17 个 API 装配")
    if SMOKE_DIR.exists():
        shutil.rmtree(SMOKE_DIR, ignore_errors=True)
    SMOKE_DIR.mkdir(parents=True, exist_ok=True)

    from apis import build_apis
    from apis.codes import CODE_LIST

    stub = StubLLM()
    apis = build_apis(stub)
    ok = _ok(f"编号齐全（{len(apis)}/{len(CODE_LIST)}）", len(apis) == len(CODE_LIST) and set(apis) == set(CODE_LIST))

    print("[2/4] 登录建档 + 建角色 + 七件套落盘")
    from service import CharacterForm, DSPService
    from core import account as account_store

    service = DSPService(api_key="stub", data_dir=SMOKE_DIR)
    service.llm = stub  # 离线桩替换真实客户端
    ok &= _ok("未建档时 has_account 为假", not service.has_account())
    account = service.create_account("猫眼石")
    ok &= _ok("登录建档成功", account.get("display_name") == "猫眼石")
    ok &= _ok("重复建档走同一份档案", service.has_account())
    account2 = account_store.load_account(SMOKE_DIR)
    ok &= _ok("account.json 落盘", account2 is not None)
    service.rename_user("小李")
    ok &= _ok(
        "改名进历史",
        len(account_store.load_account(SMOKE_DIR)["display_name_history"]) == 2,
    )
    ok &= _ok("服务层拿到新名字", service.user_name() == "小李")

    char_id = service.create_character(
        CharacterForm(display_name="自检角色", gender="女", age=24, base_persona="嘴硬心软")
    )
    ok &= _ok("新角色用登录名当默认称呼",
              service.registry.get(char_id).load("profile.json")["display_name"] == "小李")
    storage = service.registry.get(char_id)
    files = ["identity.json", "state.json", "profile.json", "buffer.json", "candidates.json", "counter.json", "meta.json"]
    missing = [name for name in files if not storage.exists(name)]
    ok &= _ok("七件套齐全", not missing, ",".join(missing))

    # ---- 回归：登录页「进入」按钮必须真的建档并切进主界面 ----
    # 事故：同步事件处理器里直接调用 async 回调，协程没被 await 就蒸发了，
    # 表现是"点了按钮毫无反应"，控制台只有一句 RuntimeWarning。
    ok &= await _check_login_click(SMOKE_DIR)

    print("[3/4] 跑一轮完整流水线")
    from backend.round_handler import RoundEngine
    from core.database import CharacterDB

    db = CharacterDB(storage.db_path)  # 首次访问才真正建库
    ok &= _ok("SQLite 初始化", storage.db_path.exists())
    life = service.lives.get(char_id)
    life.llm = stub
    life.apis = build_apis(stub)
    life.engine.apis = life.apis
    engine: RoundEngine = life.engine

    result = await engine.handle("在吗，今天加班到现在")
    ok &= _ok("①有输出", bool(result.text), result.text[:40])

    # 身份锚点：① 的 Prompt 里必须钉死双方名字（专治复读/叫错名）
    identity = storage.load("identity.json")
    profile = storage.load("profile.json")
    from backend import context_builder as cb

    anchor = cb.identity_anchor_block(identity, profile, service.account)
    ok &= _ok("① 拿到【绝对身份认知】", "自检角色" in anchor and "小李" in anchor)
    bundle = service.lives.get(char_id).engine._roleplay_bundle("测试", {}, False, "normal")  # noqa: SLF001
    ok &= _ok("anchor 进 ① 的 bundle", "identity_anchor_block" in bundle and bool(bundle["identity_anchor_block"]))
    ok &= _ok("⑨给出 ≥1 条消息", bool(result.messages), str(len(result.messages)))
    ok &= _ok("⓪路由在编号表里", set(result.codes) <= set(CODE_LIST), " ".join(result.codes))
    ok &= _ok("对话已落库", db.count_messages() >= 2, f"{db.count_messages()} 条")
    state = storage.load("state.json")
    ok &= _ok("轮次已累加", state.get("rounds") == 1, str(state.get("rounds")))

    print("[3.5/5] 本轮新增：隐私隔离 / 严格分条 / 撤回 / 关系破裂 / 主题")
    ok &= _check_privacy(SMOKE_DIR, service)
    ok &= await _check_segmentation(db, storage)
    ok &= _check_recall(db)
    ok &= await _check_break_states(engine, storage)
    ok &= _check_theme(SMOKE_DIR)
    ok &= _check_dedupe(service)

    print("[4/5] 后台生命循环")
    try:
        await service.start_background()
        await asyncio.sleep(0.2)
        await service.stop_background()
        ok &= _ok("启动/停止无异常", True)
    except Exception as exc:  # noqa: BLE001
        ok &= _ok("启动/停止无异常", False, str(exc))

    print("\n结果：", "全部通过" if ok else "存在失败项")
    return 0 if ok else 1


# ---------------------------------------------------------------- 新增检查
def _check_privacy(base_dir: Path, service) -> bool:
    """真人的性别与生日，绝对不能出现在任何一份 Prompt 素材里。"""
    from core import account as account_store

    full = account_store.load_account(base_dir)
    ok = _ok("档案里有性别生日", full is not None and not full.get("gender") or bool(full.get("birthday")))
    # 补一份完整的隐私数据再验
    account_store.update_account(base_dir, gender="不愿填写", birthday="2000-05-12")
    full = account_store.load_account(base_dir)
    view = account_store.api_view(full)
    ok &= _ok("api_view 保留名字", view.get("display_name") == full.get("display_name"))
    leaked = [k for k in ("gender", "birthday", "display_name_history", "created_at") if k in view]
    ok &= _ok("api_view 不含性别/生日/历史", not leaked, ",".join(leaked))

    # 引擎里存的也必须是过滤后的
    from backend.round_handler import RoundEngine

    probe = RoundEngine.__new__(RoundEngine)
    probe.account = account_store.api_view(full)
    RoundEngine.__init__(probe, None, None, None, account=full)
    leaked2 = [k for k in ("gender", "birthday") if k in probe.account]
    ok &= _ok("引擎会自动过滤敏感字段", not leaked2, ",".join(leaked2))
    return bool(ok)


async def _check_segmentation(db, storage) -> bool:
    """⑨ 拆成几条，库里就是几行 —— 重启后仍然是几个气泡。"""
    group = db.new_group_id()
    rows = [
        {"role": "assistant", "text": "第一条", "seq": 0},
        {"role": "assistant", "text": "第二条", "seq": 1},
        {"role": "assistant", "text": "第三条", "seq": 2},
    ]
    for row in rows:
        row["group_id"] = group
    written = await asyncio.to_thread(db.add_message_batch, rows)
    ok = _ok("三个气泡落成三行", len(written) == 3, str(len(written)))
    listed = db.list_messages(limit=500)
    same_group = [r for r in listed if r.get("group_id") == group]
    ok &= _ok("同组气泡共享 group_id", len(same_group) == 3, str(len(same_group)))
    ok &= _ok("seq 保持顺序", [int(r["seq"]) for r in same_group] == [0, 1, 2])
    ok &= _ok("正文独立存储", [r["text"] for r in same_group] == ["第一条", "第二条", "第三条"])
    return bool(ok)


def _check_recall(db) -> bool:
    msg_id = db.last_user_message_id()
    ok = _ok("能定位到最后一条用户消息", msg_id is not None, str(msg_id))
    if msg_id is None:
        return False
    done = db.recall_message(msg_id, by="user")
    ok &= _ok("撤回成功", done)
    row = db.get_message(msg_id)
    ok &= _ok("正文已清空（物理删除内容）", row is not None and not row.get("text"))
    ok &= _ok("行保留为灰色提示", row is not None and row.get("msg_type") == "recall_hint")
    listed = db.list_messages(limit=500)
    rendered = [r for r in listed if r.get("id") == msg_id and r.get("msg_type") == "recall_hint"]
    ok &= _ok("重启后仍渲染撤回提示", bool(rendered))
    ok &= _ok("已撤回的不计入有效消息数", db.count_messages() >= 0)
    return bool(ok)


async def _check_break_states(engine, storage) -> bool:
    """四级关系破裂：后端必须拦截，① 号不许被唤醒。"""
    from backend.round_handler import _read_break_status

    ok = True
    # 桩模型每次都会判"和好"，这里把它钉成"没和好"，才能验到真正的拦截分支
    async def _never_forgive(_text: str) -> bool:
        return False

    engine._try_unblock = _never_forgive  # noqa: SLF001

    expectations = {
        "blocked": "消息已发出，但被对方拒收了。",
        "rejected": "消息已发出，但被对方拒收了。",
        "friend_removed": "你还不是对方的朋友。",
    }
    for status, hint in expectations.items():

        def _set_status(session, st=status):  # storage.update 要求原地改，返回新 dict 不会被存下来
            session["relationship_status"] = st
            session["is_blocked"] = st != "normal"
            return session

        await storage.update("state.json", _set_status)
        state = storage.load("state.json")
        ok &= _ok(f"{status} 状态可读", _read_break_status(state) == status, _read_break_status(state))
        result = await engine.handle("在吗")
        ok &= _ok(f"{status} 时后端直接拦截", result.status == status and result.blocked, result.status)
        ok &= _ok(f"{status} 给对了提示", hint in result.messages[0].get("text", "") if result.messages else False)
        ok &= _ok(f"{status} 时未走 ①（无真实回复）", not any("离线桩" in str(m.get("text")) for m in result.messages))

    def _as_deleted(session):
        session["relationship_status"] = "deleted"
        session["is_blocked"] = False
        return session

    await storage.update("state.json", _as_deleted)
    result = await engine.handle("在吗")
    ok &= _ok("deleted → 只读模式", result.status == "deleted", result.status)

    def _as_normal(session):
        session["relationship_status"] = "normal"
        session["is_blocked"] = False
        return session

    await storage.update("state.json", _as_normal)
    return bool(ok)


def _check_theme(base_dir: Path) -> bool:
    from core import settings as theme_store

    theme = theme_store.load_theme(base_dir)
    ok = _ok("主题有默认值", bool(theme.get("bg_color")) and bool(theme.get("bubble_user_color")))
    saved = theme_store.save_theme({"bg_color": "#101010", "bubble_user_color": "#ff0000"}, base_dir)
    ok &= _ok("主题可写", saved.get("bg_color") == "#101010")
    again = theme_store.load_theme(base_dir)
    ok &= _ok("主题可持久化", again.get("bubble_user_color") == "#ff0000")
    reset = theme_store.reset_theme(base_dir)
    ok &= _ok("可恢复默认", reset.get("bubble_user_color") == theme_store.DEFAULT_THEME["bubble_user_color"])
    return bool(ok)


def _check_dedupe(service) -> bool:
    ok = _ok("同名角色会被查重拦住", service.name_taken("自检角色"))
    ok &= _ok("不存在的名字不误报", not service.name_taken("绝对不存在的名字XYZ"))
    return bool(ok)


async def online_smoke() -> int:
    from config import MODEL, require_api_key

    key = require_api_key()
    print(f"模型 {MODEL}，密钥 {key[:8]}…{key[-4:]}")
    from service import CharacterForm, DSPService

    if SMOKE_DIR.exists():
        shutil.rmtree(SMOKE_DIR, ignore_errors=True)
    SMOKE_DIR.mkdir(parents=True, exist_ok=True)

    service = DSPService(data_dir=SMOKE_DIR)
    char_id = service.create_character(
        CharacterForm(display_name="联网自检", gender="女", age=25, base_persona="嘴硬心软，不太会表达想念")
    )
    print(f"角色 {char_id} 创建完成")
    result_box: List[Dict[str, Any]] = []

    async def _done(result: Dict[str, Any]) -> None:
        result_box.append(result)

    await service.send(char_id, "在吗，今天加班到现在", _done)
    # send 内部有防抖任务，等它跑完
    for _ in range(120):
        if result_box:
            break
        await asyncio.sleep(1)
    await service.stop_background()
    if not result_box:
        print("✗ 60 秒内没跑完一轮（可能是网络或超时）")
        return 1
    result = result_box[0]
    print("唤醒的专家：", " ".join(result.get("codes") or []))
    print("回复：", result.get("text"))
    print("耗时：", f"{result.get('elapsed', 0):.1f}s")
    print("调用统计：", service.llm.usage_summary())
    return 0


def main() -> None:
    online = "--online" in sys.argv
    code = asyncio.run(online_smoke() if online else offline_smoke())
    sys.exit(code)


if __name__ == "__main__":
    main()
