"""自检脚本。

    python main.py smoke            离线自检（用桩模型跑通全链路，不花 token）
    python main.py smoke --online   真实调用 DeepSeek 跑一轮（会消耗少量 token）

检查项：
1. 20 个 API 全部可实例化，编号无重复（含 ⑰ 作息 / ⑱ 工具裁决 / ⑲ 人格种子）
2. 角色创建 → JSON 七件套落盘 → SQLite 可用
3. 一轮对话流水线跑完（⓪ 路由 → 专家 → 写状态 → ① → ⑨）
4. 后台生命循环能启动、能停
5. 防抖 3 秒滑动窗口用 \n 拼接；锚点黑盒只用 profile；迷糊消息次日遮蔽
"""

from __future__ import annotations

import asyncio
import json
import shutil
import sys
import tempfile
from datetime import datetime
from pathlib import Path

import flet as ft
from typing import Any, Dict, List, Optional, Sequence

SMOKE_DIR = Path(tempfile.gettempdir()) / "dsp2_smoke"


class StubLLM:
    """离线桩：接口签名与 DeepSeekClient 完全一致，返回合法的最小 JSON。"""

    api_key = "stub"
    model = "stub"
    stats = {"calls": 0, "prompt_tokens": 0, "completion_tokens": 0, "json_retries": 0, "failures": 0}

    SAMPLES: Dict[str, Any] = {
        "required_apis": ["①", "④", "⑨"],
        "scene_intent": "normal",
        "is_minimal": False,
        "label": "平静",
        "energy": 0.6,
        "affection": 0.15,
        "trust": 0.35,
        "alignment": 0.32,
        "dependency": 0.08,
        "dominance": 0.5,
        "boundary": 0.85,
        "conflict_state": "正常",
        "event": "第一次认真聊天",
        "unresolved": "",
        "arousal": "normal",
        "event_type": "chat",
        "action": "wait",
        "wait_seconds": 60,
        "is_risk": False,
        "block_output": False,
        "crisis_reply": "",
        "relationship_penalty": 0.0,
        "messages": [{"text": "嗯，我在。（离线桩回复）", "delay_ms": 600, "action": "send", "kind": "reply"}],
        "draft_text": "在吗，刚才突然想到你",
        "archive_ids": [],
        "display_name": None,
        "facts": [],
        "new_traits": [],
        "diary_md": "",
        "needs_longform": False,
        "block": False,
        "block_reason": "",
        "topic_hint": "",
        "tone_restraint": 0.5,
        "max_messages": 1,
        "emotion_tag": "平静",
        "subtext": "",
        "hidden_fact": "",
        "nickname": None,
        "current_topics": [],
        "insight": "",
        "style_notes": "",
        "trait_delta": 0.0,
        "reply": "嗯，我在。（离线桩回复）",
        "reason": "离线桩",
        # ── ⑰ 现实日历作息 ──
        "her_clock": "2026-10-20 07:11 周二",
        "sleep_window": {"start": "23:30", "end": "07:00"},
        "busy_windows": [],
        "holiday_note": "",
        "can_reply": True,
        "rhythm_note": "离线桩：普通人的一天",
        # ── ⑱ 工具裁决 ──
        "accept_task": True,
        "minutes": 10,
        "content": "",
        "refuse_reason": "",
        "guide_for_roleplay": "",
        # ── ⑲ 人格种子 ──
        "occupation": "急诊科医生",
        "personality_ocean": {"openness": 0.6, "conscientiousness": 0.7, "extraversion": 0.4, "agreeableness": 0.5, "neuroticism": 0.5},
        "dark_triad": {"narcissism": 0.1, "machiavellianism": 0.1, "psychopathy": 0.05},
        "trauma": "无",
        "language_profile": {"mother_tongue": "中文", "typing_habits": "句尾不加标点"},
        "physical_constraints": {"sleep_habit": "夜猫子", "health_notes": ""},
        "timezone_offset": 0.0,
        "seed_summary": "离线桩人物",
        # ── ④ 复合情绪 / ⑧ 内心反应 ──
        "primary_emotion": "平静",
        "secondary_emotion": "",
        "compound_label": "平静",
        "is_drowsy": False,
        "internal_reaction": "",
        "attachment_style": "secure",
        "speaking_style": "自然口语",
    }

    def chat(self, system: str, user: Optional[str] = None, messages=None, *,
             json_mode: bool = False, max_tokens: int = 400, temperature: Optional[float] = None) -> str:
        self.stats["calls"] += 1
        return "嗯，我在。（离线桩回复）"

    def chat_json(self, system: str, user: str, *, required: Optional[Sequence[str]] = None,
                  fallback: Optional[Any] = None, retries: int = 1, max_tokens: int = 400,
                  temperature: Optional[float] = None) -> Any:
        self.stats["calls"] += 1
        if not required:
            return fallback if fallback is not None else {}
        data: Dict[str, Any] = {}
        for key in required:
            data[key] = self.SAMPLES.get(key, self._guess(key))
        return data

    @staticmethod
    def _guess(key: str) -> Any:
        lowered = key.lower()
        if "list" in lowered or lowered.endswith("s") or lowered.endswith("_found"):
            return []
        if lowered.endswith("ids"):
            return []
        if "id" in lowered:
            return 1
        if "text" in lowered or "reply" in lowered or "draft" in lowered:
            return "嗯，我在。"
        return 0.0


def _ok(label: str, passed: bool, detail: str = "") -> bool:
    mark = "✓" if passed else "✗"
    print(f"  {mark} {label}{(' —— ' + detail) if detail else ''}")
    return passed


async def _check_login_click(base_dir: Path) -> bool:
    """回归用例：点登录页的「进入」，协程必须真的被执行。

    曾经的事故：同步事件处理器里写 `on_success(name)`，而 `_on_login` 是 async def，
    返回的协程没人 await → 不建档、不切界面、UI 毫无反应，只在控制台留一句
    RuntimeWarning: coroutine ... was never awaited。
    """
    import asyncio
    import shutil as _shutil
    from unittest.mock import MagicMock

    from service import DSPService
    from ui.app import DSPApp

    fresh = base_dir / "login_click"
    if fresh.exists():
        _shutil.rmtree(fresh, ignore_errors=True)
    fresh.mkdir(parents=True, exist_ok=True)

    async def main() -> bool:
        service = DSPService(api_key="stub", data_dir=fresh)
        service.llm.api_key = ""
        page = MagicMock()
        page.services = []
        page.window = MagicMock()
        # 让 mock 的 page 像真 page 一样把协程函数丢进当前事件循环
        page.run_task = lambda handler, *a, **k: asyncio.get_running_loop().create_task(handler(*a, **k))

        app = DSPApp(page, service)
        await app.mount()
        shown = app.body.content is not app.root
        ok = _ok("未建档时显示登录页", shown)
        if not shown:
            return ok

        def walk(control, out) -> None:
            if getattr(control, "on_submit", None):
                out.append(control)
            for child in (getattr(control, "controls", None) or []):
                walk(child, out)
            sub = getattr(control, "content", None)
            if sub is not None and sub is not control:
                walk(sub, out)

        def walk_dropdowns(control, out) -> None:
            if isinstance(control, ft.Dropdown):
                out.append(control)
            for child in (getattr(control, "controls", None) or []):
                walk_dropdowns(child, out)
            sub = getattr(control, "content", None)
            if sub is not None and sub is not control:
                walk_dropdowns(sub, out)

        inputs = []
        walk(app.body.content, inputs)
        dropdowns = []
        walk_dropdowns(app.body.content, dropdowns)
        if not inputs:
            return ok & _ok("登录页有输入框", False)
        # 用户名 + 出生年月日 是两个输入框，性别是下拉框
        inputs[0].value = "猫眼石"
        if len(inputs) > 1:
            inputs[1].value = "2000-05-12"
        dropdowns = []
        walk_dropdowns(app.body.content, dropdowns)
        if dropdowns:
            dropdowns[0].value = "女"
        # 真实点击路径：控件回调 → fire() → async _on_login(dict)
        inputs[0].on_submit(None)
        for _ in range(60):
            await asyncio.sleep(0.05)
            if app.body.content is app.root:
                break

        ok &= _ok("点「进入」真的建档了", service.has_account())
        ok &= _ok("点「进入」真的切进主界面", app.body.content is app.root)
        ok &= _ok("名字进档案", service.user_name() == "猫眼石", service.user_name())

        # 登录表单：除头像外全部必填，飘红且不放行
        await asyncio.to_thread(shutil.rmtree, fresh, ignore_errors=True)
        service2 = DSPService(api_key="stub", data_dir=fresh)
        service2.llm.api_key = ""
        from ui.login_window import build_login_view

        probe_page = MagicMock()
        probe_page.services = []
        probe_page.window = MagicMock()
        view = build_login_view(probe_page, lambda form: None)
        texts = []
        fields = []

        def _collect(control) -> None:
            if isinstance(control, ft.TextField):
                fields.append(control)
            if isinstance(control, ft.Text) and (control.value or ""):
                texts.append(control)
            for child in (getattr(control, "controls", None) or []):
                _collect(child)
            sub = getattr(control, "content", None)
            if sub is not None and sub is not control:
                _collect(sub)

        _collect(view)
        from core import account as acc2

        ok &= _ok("登录表单有 2 个输入框", len(fields) == 2, str(len(fields)))
        ok &= _ok("空表单被判必填", bool(acc2.validate_form("", "", "")))
        ok &= _ok("生日格式错会被拦下", bool(acc2.validate_form("猫眼石", "女", "2000/05/12")))
        ok &= _ok(
            "性别生日写不进 API 视图",
            "gender" not in acc2.api_view({"display_name": "a", "gender": "女", "birthday": "2000-05-12"}),
        )
        try:
            await asyncio.get_running_loop().create_task(asyncio.sleep(0))
        except Exception:  # noqa: BLE001
            pass
        return bool(ok)
        try:
            await app.dispose()
        except Exception:  # noqa: BLE001
            pass
        return bool(ok)

    return await main()


async def offline_smoke() -> int:
    print(f"[1/4] API 装配")
    if SMOKE_DIR.exists():
        shutil.rmtree(SMOKE_DIR, ignore_errors=True)
    SMOKE_DIR.mkdir(parents=True, exist_ok=True)

    from apis import build_apis
    from apis.codes import CODE_LIST

    stub = StubLLM()
    apis = build_apis(stub)
    ok = _ok(f"编号齐全（{len(apis)}/{len(CODE_LIST)}）", len(apis) == len(CODE_LIST) and set(apis) == set(CODE_LIST))

    print("[2/4] 登录建档 + 建角色 + 七件套落盘")
    from service import CharacterForm, DSPService
    from core import account as account_store

    service = DSPService(api_key="stub", data_dir=SMOKE_DIR)
    service.llm = stub  # 离线桩替换真实客户端
    ok &= _ok("未建档时 has_account 为假", not service.has_account())
    account = service.create_account("猫眼石")
    ok &= _ok("登录建档成功", account.get("display_name") == "猫眼石")
    ok &= _ok("重复建档走同一份档案", service.has_account())
    account2 = account_store.load_account(SMOKE_DIR)
    ok &= _ok("account.json 落盘", account2 is not None)
    service.rename_user("小李")
    ok &= _ok(
        "改名进历史",
        len(account_store.load_account(SMOKE_DIR)["display_name_history"]) == 2,
    )
    ok &= _ok("服务层拿到新名字", service.user_name() == "小李")

    char_id = service.create_character(
        CharacterForm(display_name="自检角色", gender="女", age=24, base_persona="嘴硬心软")
    )
    ok &= _ok("新角色用登录名当默认称呼",
              service.registry.get(char_id).load("profile.json")["display_name"] == "小李")
    storage = service.registry.get(char_id)
    files = ["identity.json", "state.json", "profile.json", "buffer.json", "candidates.json", "counter.json", "meta.json"]
    missing = [name for name in files if not storage.exists(name)]
    ok &= _ok("七件套齐全", not missing, ",".join(missing))

    # ---- 回归：登录页「进入」按钮必须真的建档并切进主界面 ----
    # 事故：同步事件处理器里直接调用 async 回调，协程没被 await 就蒸发了，
    # 表现是"点了按钮毫无反应"，控制台只有一句 RuntimeWarning。
    ok &= await _check_login_click(SMOKE_DIR)

    print("[3/4] 跑一轮完整流水线")
    from backend.round_handler import RoundEngine
    from core.database import CharacterDB

    db = CharacterDB(storage.db_path)  # 首次访问才真正建库
    ok &= _ok("SQLite 初始化", storage.db_path.exists())
    life = service.lives.get(char_id)
    life.llm = stub
    life.apis = build_apis(stub)
    life.engine.apis = life.apis
    engine: RoundEngine = life.engine

    result = await engine.handle("在吗，今天加班到现在")
    ok &= _ok("①有输出", bool(result.text), result.text[:40])

    # 身份锚点：① 的 Prompt 里必须钉死双方名字（专治复读/叫错名）
    identity = storage.load("identity.json")
    profile = storage.load("profile.json")
    from backend import context_builder as cb

    anchor = cb.identity_anchor_block(identity, profile, service.account)
    ok &= _ok("① 拿到【绝对身份认知】", "自检角色" in anchor and "小李" in anchor)
    bundle = service.lives.get(char_id).engine._roleplay_bundle("测试", {}, False, "normal")  # noqa: SLF001
    ok &= _ok("anchor 进 ① 的 bundle", "identity_anchor_block" in bundle and bool(bundle["identity_anchor_block"]))
    ok &= _ok("⑨给出 ≥1 条消息", bool(result.messages), str(len(result.messages)))
    ok &= _ok("⓪路由在编号表里", set(result.codes) <= set(CODE_LIST), " ".join(result.codes))
    ok &= _ok("对话已落库", db.count_messages() >= 2, f"{db.count_messages()} 条")
    state = storage.load("state.json")
    ok &= _ok("轮次已累加", state.get("rounds") == 1, str(state.get("rounds")))

    print("[3.5/5] 本轮新增：隐私隔离 / 严格分条 / 撤回 / 关系破裂 / 主题")
    ok &= _check_privacy(SMOKE_DIR, service)
    ok &= await _check_segmentation(db, storage)
    ok &= _check_recall(db)
    ok &= await _check_break_states(engine, storage)
    ok &= _check_theme(SMOKE_DIR)
    ok &= _check_dedupe(service)

    print("[3.8/5] 后数十轮新增：⑰⑱⑲ / 3 秒防抖 / 锚点黑盒 / 迷糊遮蔽")
    ok &= _check_new_apis(stub)
    ok &= _check_anchor_blackbox()
    ok &= await _check_debounce(engine)
    ok &= _check_world_gate()
    ok &= _check_drowsy_mask(storage)

    print("[4/5] 后台生命循环")
    try:
        await service.start_background()
        await asyncio.sleep(0.2)
        await service.stop_background()
        ok &= _ok("启动/停止无异常", True)
    except Exception as exc:  # noqa: BLE001
        ok &= _ok("启动/停止无异常", False, str(exc))

    print("\n结果：", "全部通过" if ok else "存在失败项")
    return 0 if ok else 1


# ---------------------------------------------------------------- 新增检查
def _check_privacy(base_dir: Path, service) -> bool:
    """真人的性别与生日，绝对不能出现在任何一份 Prompt 素材里。"""
    from core import account as account_store

    full = account_store.load_account(base_dir)
    ok = _ok("档案里有性别生日", full is not None and not full.get("gender") or bool(full.get("birthday")))
    # 补一份完整的隐私数据再验
    account_store.update_account(base_dir, gender="不愿填写", birthday="2000-05-12")
    full = account_store.load_account(base_dir)
    view = account_store.api_view(full)
    ok &= _ok("api_view 保留名字", view.get("display_name") == full.get("display_name"))
    leaked = [k for k in ("gender", "birthday", "display_name_history", "created_at") if k in view]
    ok &= _ok("api_view 不含性别/生日/历史", not leaked, ",".join(leaked))

    # 引擎里存的也必须是过滤后的
    from backend.round_handler import RoundEngine

    probe = RoundEngine.__new__(RoundEngine)
    probe.account = account_store.api_view(full)
    RoundEngine.__init__(probe, None, None, None, account=full)
    leaked2 = [k for k in ("gender", "birthday") if k in probe.account]
    ok &= _ok("引擎会自动过滤敏感字段", not leaked2, ",".join(leaked2))
    return bool(ok)


async def _check_segmentation(db, storage) -> bool:
    """⑨ 拆成几条，库里就是几行 —— 重启后仍然是几个气泡。"""
    group = db.new_group_id()
    rows = [
        {"role": "assistant", "text": "第一条", "seq": 0},
        {"role": "assistant", "text": "第二条", "seq": 1},
        {"role": "assistant", "text": "第三条", "seq": 2},
    ]
    for row in rows:
        row["group_id"] = group
    written = await asyncio.to_thread(db.add_message_batch, rows)
    ok = _ok("三个气泡落成三行", len(written) == 3, str(len(written)))
    listed = db.list_messages(limit=500)
    same_group = [r for r in listed if r.get("group_id") == group]
    ok &= _ok("同组气泡共享 group_id", len(same_group) == 3, str(len(same_group)))
    ok &= _ok("seq 保持顺序", [int(r["seq"]) for r in same_group] == [0, 1, 2])
    ok &= _ok("正文独立存储", [r["text"] for r in same_group] == ["第一条", "第二条", "第三条"])
    return bool(ok)


def _check_recall(db) -> bool:
    msg_id = db.last_user_message_id()
    ok = _ok("能定位到最后一条用户消息", msg_id is not None, str(msg_id))
    if msg_id is None:
        return False
    done = db.recall_message(msg_id, by="user")
    ok &= _ok("撤回成功", done)
    row = db.get_message(msg_id)
    ok &= _ok("正文已清空（物理删除内容）", row is not None and not row.get("text"))
    ok &= _ok("行保留为灰色提示", row is not None and row.get("msg_type") == "recall_hint")
    listed = db.list_messages(limit=500)
    rendered = [r for r in listed if r.get("id") == msg_id and r.get("msg_type") == "recall_hint"]
    ok &= _ok("重启后仍渲染撤回提示", bool(rendered))
    ok &= _ok("已撤回的不计入有效消息数", db.count_messages() >= 0)
    return bool(ok)


async def _check_break_states(engine, storage) -> bool:
    """四级关系破裂：后端必须拦截，① 号不许被唤醒。"""
    from backend.round_handler import _read_break_status

    ok = True
    # 桩模型每次都会判"和好"，这里把它钉成"没和好"，才能验到真正的拦截分支
    async def _never_forgive(_text: str) -> bool:
        return False

    engine._try_unblock = _never_forgive  # noqa: SLF001

    expectations = {
        "blocked": "消息已发出，但被对方拒收了。",
        "rejected": "消息已发出，但被对方拒收了。",
        "friend_removed": "你还不是对方的朋友。",
    }
    for status, hint in expectations.items():

        def _set_status(session, st=status):  # storage.update 要求原地改，返回新 dict 不会被存下来
            session["relationship_status"] = st
            session["is_blocked"] = st != "normal"
            return session

        await storage.update("state.json", _set_status)
        state = storage.load("state.json")
        ok &= _ok(f"{status} 状态可读", _read_break_status(state) == status, _read_break_status(state))
        result = await engine.handle("在吗")
        ok &= _ok(f"{status} 时后端直接拦截", result.status == status and result.blocked, result.status)
        ok &= _ok(f"{status} 给对了提示", hint in result.messages[0].get("text", "") if result.messages else False)
        ok &= _ok(f"{status} 时未走 ①（无真实回复）", not any("离线桩" in str(m.get("text")) for m in result.messages))

    def _as_deleted(session):
        session["relationship_status"] = "deleted"
        session["is_blocked"] = False
        return session

    await storage.update("state.json", _as_deleted)
    result = await engine.handle("在吗")
    ok &= _ok("deleted → 只读模式", result.status == "deleted", result.status)

    def _as_normal(session):
        session["relationship_status"] = "normal"
        session["is_blocked"] = False
        return session

    await storage.update("state.json", _as_normal)
    return bool(ok)


def _check_theme(base_dir: Path) -> bool:
    from core import settings as theme_store

    theme = theme_store.load_theme(base_dir)
    ok = _ok("主题有默认值", bool(theme.get("bg_color")) and bool(theme.get("bubble_user_color")))
    saved = theme_store.save_theme({"bg_color": "#101010", "bubble_user_color": "#ff0000"}, base_dir)
    ok &= _ok("主题可写", saved.get("bg_color") == "#101010")
    again = theme_store.load_theme(base_dir)
    ok &= _ok("主题可持久化", again.get("bubble_user_color") == "#ff0000")
    reset = theme_store.reset_theme(base_dir)
    ok &= _ok("可恢复默认", reset.get("bubble_user_color") == theme_store.DEFAULT_THEME["bubble_user_color"])
    return bool(ok)


def _check_dedupe(service) -> bool:
    ok = _ok("同名角色会被查重拦住", service.name_taken("自检角色"))
    ok &= _ok("不存在的名字不误报", not service.name_taken("绝对不存在的名字XYZ"))
    return bool(ok)


# ---------------------------------------------------------------- 后数十轮新增的回归
def _check_new_apis(stub) -> bool:
    """⑰⑱⑲ 三个新大脑：装配成功、契约字段齐全、数值兜底生效。"""
    from apis import build_apis

    apis = build_apis(stub)
    ok = _ok("⑰⑱⑲ 已注册", all(c in apis for c in ("⑰", "⑱", "⑲")))
    rhythm = apis["⑰"].run({"identity": {}, "user_clock": "2026-10-20 23:11 周一", "timezone_offset": -12.0})
    ok &= _ok("⑰ 返回睡眠窗口", bool((rhythm.get("sleep_window") or {}).get("start")))
    ok &= _ok("⑰ 给出 can_reply", isinstance(rhythm.get("can_reply"), bool))
    judge = apis["⑱"].run({"tool_request": {"intent": "set", "minutes": 10, "content": "吃药"}})
    ok &= _ok("⑱ 返回 accept_task", isinstance(judge.get("accept_task"), bool))
    seed = apis["⑲"].run({"gender": "女", "age": 24, "nationality": "", "avatar_note": ""})
    ok &= _ok("⑲ 掷出完整人格", bool((seed.get("personality_ocean") or {}).get("openness")) and bool(seed.get("occupation")))
    ok &= _ok("⑲ 带暗黑三角", isinstance(seed.get("dark_triad"), dict) and "narcissism" in seed["dark_triad"])
    ok &= _ok("⑲ 带语言/生理/时区档案", all(k in seed for k in ("language_profile", "physical_constraints", "timezone_offset")))
    return bool(ok)


def _check_anchor_blackbox() -> bool:
    """【绝对身份认知】只用 profile：account 里的真名/性别/生日不许出现在锚点里。"""
    from backend import context_builder as cb

    identity = {"char_display_name": "阿灯"}
    profile = {"display_name": "猫眼石"}
    account = {"display_name": "猎户座", "gender": "女", "birthday": "2000-01-01"}
    anchor = cb.identity_anchor_block(identity, profile, account)
    ok = _ok("锚点用角色眼中的名字", "猫眼石" in anchor)
    ok &= _ok("锚点不含 account 真名", "猎户座" not in anchor)
    ok &= _ok("锚点不含生日", "2000-01-01" not in anchor)
    return bool(ok)


async def _check_debounce(engine) -> bool:
    """3 秒滑动窗口防抖：连发三句合并成一轮，用换行拼接。"""
    import backend.round_handler as rh

    original = rh.DEBOUNCE_WINDOW
    rh.DEBOUNCE_WINDOW = 0.2  # 测试里把窗口压小，机制不变
    captured: List[str] = []

    async def handler(text: str) -> None:
        captured.append(text)

    try:
        await engine.submit("第一句", handler)
        await asyncio.sleep(0.05)
        await engine.submit("第二句", handler)
        await engine.submit("第三句", handler)
        for _ in range(40):
            if captured:
                break
            await asyncio.sleep(0.05)
    finally:
        rh.DEBOUNCE_WINDOW = original
    ok = _ok("三句碎话合并成一轮", len(captured) == 1, str(len(captured)))
    ok &= _ok(
        "用换行拼接（不是 ' / '）",
        bool(captured) and captured[0] == "第一句\n第二句\n第三句",
        (captured[0].replace("\n", "\\n") if captured else ""),
    )
    return bool(ok)


def _check_world_gate() -> bool:
    """⑰ 的数值闸门：睡眠窗口判定、跨零点、缺数据不拦截。"""
    from core import world

    ok = _ok("无节律表时默认能回", world.can_reply_now({}, {}))
    ok &= _ok(
        "跨零点窗口判定",
        world._in_window(60, 23 * 60 + 30, 7 * 60)  # 01:00 在 23:30~07:00 里
        and world._in_window(23 * 60 + 50, 23 * 60 + 30, 7 * 60)  # 23:50 也在
        and not world._in_window(12 * 60, 23 * 60 + 30, 7 * 60),  # 中午不在
    )
    ok &= _ok("非法窗口不拦截", world._hhmm("25:99") is None)
    state = {"world_rhythm": {"sleep_window": {"start": "23:30", "end": "07:00"}, "can_reply": True}}
    now_dt = datetime.now()
    now_min = now_dt.hour * 60 + now_dt.minute
    expect = not world._in_window(now_min, 23 * 60 + 30, 7 * 60)
    ok &= _ok("can_reply 与窗口一致", world.can_reply_now({"timezone_offset": 0.0}, state) == expect)
    return bool(ok)


def _check_drowsy_mask(storage) -> bool:
    """迷糊消息次日遮蔽：前一天的 drowsy 条目从她的上下文视野里消失，但原始记录还在。"""
    storage.append_buffer("assistant", "呜……再睡五分钟", 999, drowsy=True)
    data = storage.load("buffer.json")
    data["recent_messages"][-1]["time"] = "2000-01-01 03:30:00"  # 伪装成昨天凌晨
    storage.save("buffer.json", data)
    visible = storage.visible_messages(30)
    ok = _ok("昨天的迷糊话被遮蔽", all("再睡五分钟" not in (m.get("text") or "") for m in visible))
    raw = storage.recent_messages(30)
    ok &= _ok("原始记录仍在（只是视野遮蔽）", any("再睡五分钟" in (m.get("text") or "") for m in raw))
    storage.append_buffer("assistant", "嗯……怎么了", 1000, drowsy=True)
    visible2 = storage.visible_messages(30)
    ok &= _ok("今天的迷糊话仍然可见", any("怎么了" in (m.get("text") or "") for m in visible2))
    return bool(ok)


async def online_smoke() -> int:
    from config import MODEL, require_api_key

    key = require_api_key()
    print(f"模型 {MODEL}，密钥 {key[:8]}…{key[-4:]}")
    from service import CharacterForm, DSPService

    if SMOKE_DIR.exists():
        shutil.rmtree(SMOKE_DIR, ignore_errors=True)
    SMOKE_DIR.mkdir(parents=True, exist_ok=True)

    service = DSPService(data_dir=SMOKE_DIR)
    char_id = service.create_character(
        CharacterForm(display_name="联网自检", gender="女", age=25, base_persona="嘴硬心软，不太会表达想念")
    )
    print(f"角色 {char_id} 创建完成")
    result_box: List[Dict[str, Any]] = []

    async def _done(result: Dict[str, Any]) -> None:
        result_box.append(result)

    await service.send(char_id, "在吗，今天加班到现在", _done)
    # send 内部有防抖任务，等它跑完
    for _ in range(120):
        if result_box:
            break
        await asyncio.sleep(1)
    await service.stop_background()
    if not result_box:
        print("✗ 60 秒内没跑完一轮（可能是网络或超时）")
        return 1
    result = result_box[0]
    print("唤醒的专家：", " ".join(result.get("codes") or []))
    print("回复：", result.get("text"))
    print("耗时：", f"{result.get('elapsed', 0):.1f}s")
    print("调用统计：", service.llm.usage_summary())
    return 0


def main() -> None:
    online = "--online" in sys.argv
    code = asyncio.run(online_smoke() if online else offline_smoke())
    sys.exit(code)


if __name__ == "__main__":
    main()
