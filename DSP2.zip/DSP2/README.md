# DSP2 —— 拟真数字生命系统

> 不是"会聊天的 AI 助手"，而是一个**在文件里长期活着的人**。
> 她有自己的性格数值、记忆钩子、未闭环的小事、会随时间上涨的需求，
> 也会在你不理她的时候自己开口，在深夜写反思日记，然后慢慢忘掉一些不重要的事。

---

## 一、需求要点（从分享对话中提取并确认的结论）

| 维度 | 最终确认的做法 |
| --- | --- |
| 核心思路 | **把"判断"全部外包给 20 个大语言模型 API**，后端（Track）只做 IO、调度和数值写回，代码里不允许出现 `if 用户很生气 then ...` 这种语义分支 |
| 组织方式 | 每个 LLM 是一个**岗位**：一份岗位说明书（SYSTEM_PROMPT）+ 一个 JSON 契约 + 一组兜底值 |
| 分工 | ⓪ 路由总控按本轮场景点名要唤醒哪些专家，其余 16 个各管一件事（见下表） |
| 并行 | 被点名的专家**并行调用**，互不阻塞；① 扮演 + ⑨ 发送策略在专家结论写回状态之后再跑 |
| 存储 | 每个角色一个目录：7 个 JSON（身份 / 状态 / 用户画像 / 短期上下文 / 特征候选 / 计数器 / UI 元信息）+ 1 个 SQLite（events 钩子 + 完整消息历史） |
| 涌现 | 情绪 + 关系 + 需求随时间推移自然演化；⑫ 深夜反思、⑬ 定期遗忘、⑪ 低频特征候选累积达到阈值才变成稳定特征 |
| 时间 | 模型没有时钟：所有"现在几点 / 上次聊天多久前 / 她今年几岁"都由代码算成客观变量注入 Prompt |
| 关系破裂四级 | `normal / blocked / rejected / friend_removed / deleted`。前三种 → 后端直接拦截、**不唤醒 ①**，用户气泡上出现红叹号；`deleted` → 整个面板变灰、只读历史。**这四个值只能由 ⑤ 号写入，UI 里不存在任何能查看或切换它的按钮** |
| 隐私保护 | `account.json` 里同时存着"给模型看的"和"不给模型看的"。只有 `user_id / display_name / avatar_path / avatar_note` 能通过 `api_view()` 出闸；**性别与出生年月日任何情况下都不会进 Prompt**，她想知道只能靠你亲口告诉她 |
| 消息分条 | ⑨ 拆成 3 个气泡，数据库就**严格存 3 行**（同 `group_id`、按 `seq` 排序）。绝不合并回一条 —— 否则重启后三个气泡又塌成一坨 |
| 撤回 | ⑨ 可下发 `{"action":"recall","target_msg_id":…}`，后端物理清空正文、留一行灰色提示；用户可在发出后 2 秒内撤回自己上一句，后端向 ③ 传 `recall_event` 由她决定装没看见还是追问 | |
| 身份锚点 | ① 号 Prompt 顶部插入由代码生成的【绝对身份认知】块，把"你是谁 / 她是谁 / 现在几点 / 该怎么称呼你"钉死，杜绝复读用户台词、叫错名字 |
| 用户账户 | `data/users/{uid}/account.json` 存真人档案（真名 / 改名历史 / 头像 / 性别 / 生日），首次启动走登录页建档；改名会同步到所有角色的称呼锚点 |
| 模板自由 | 所有模板里**不许有写死的人设**。旧的男女模板写死了"高中语文老师 / 古诗词 / 文艺复兴艺术"，结果所有角色都像一个模子刻的 —— 现在只剩中性数值骨架，具体是什么样的人由模型按你填的国籍与文化边界推导 |
| 识图 | 图片转 base64 交给 ③ 号提炼 `image_context` 再喂给 ①。注意：DeepSeek 文本模型**不接受图像输入**，要真看图需换支持视觉的 OpenAI 兼容端点并把 `.env` 里 `DSG_VISION_ENABLED` 打开，否则优雅降级为纯文本 |
| 高频日常 | 极简短句走 ⓪ 的 `is_minimal` 特批通道，只唤醒必要的专家；长回复只在表白/道歉/冲突等场景开（③ 的 `needs_longform`） |
| 定时器 | 用户说"X 分钟后提醒我"→③ 号产出 `timer_action` → 写入 `state.json.unresolved_timers` → 到点了作为主动开口的理由 |
| 主动消息 | ⑦ 时机决策按需求钟摆（关注/认可随时间上涨）+ 时钟 + 未闭环钩子 + 今日额度决定是否开口；⑩ 起草，⑨ 排版分批发送 |
| 安全 | ⑧ 是唯一有"一票否决权"的岗位，判定危机时 `block_output=true`，跳过 ① 直接输出危机回应 |
| 界面 | 左侧图标栏 + partners 列表 + 右侧消息区，沿用原有 Flet UI 视觉（深色气泡、蓝色用户气泡、10 圆角、15 号字） |

---

## 二、目录结构

```
DSP2/
├── main.py                入口：ui（默认） / cli / smoke
├── cli.py                 命令行聊天、建角色、看状态
├── smoke.py               自检（离线桩 / 联网一轮）
├── service.py             服务层：装配 registry / LLM / 后台生命，UI 与 CLI 共用
├── tools/
│   ├── seed_proactive_test.py  生成/重置"主动消息测试角色"（不调 API、不花钱）
│   └── proactive_probe.py      单角色探针：打印 ⑦ 的原始裁决，--send 强制发一条
├── config.py              全局配置（密钥只读环境变量与 .env）
├── .env / .env.example    密钥与调参（.env 已在 .gitignore 中）
├── requirements.txt       依赖（只有 flet 是必需的，网络层用标准库 urllib）
│
├── core/                  核心层 —— 只做 IO / 时间 / 调度，零语义判断
│   ├── account.py         用户本人档案 + api_view() 隐私闸门（性别生日永不出库）
│   ├── settings.py        外观设置 theme.json：背景 / 字体 / 各种颜色，缺键自动补默认
│   ├── llm.py             DeepSeek 唯一出口：发请求、去围栏、洗 JSON、重试、关思维链
│   ├── storage.py         原子写 + 协程锁；**同一角色只留一个句柄**，避免各自缓存读到旧数据
│   ├── database.py        SQLite：events（未闭环钩子/秘密）+ messages（严格分条 + 撤回占位）
│   ├── defaults.py        中性数值骨架（无写死人设）+「人设推导」按国籍/文化边界翻译
│   ├── scheduler.py       后台生命循环：需求钟摆 / 深夜反思 / 定期遗忘 / 定时器 / 主动开口
│   └── timeutil.py        时间工具：clock_block、idle_text、周岁计算
│
├── apis/                  20 个裁决大脑 —— 每个 = SYSTEM_PROMPT + JSON 契约 + 兜底值
│   ├── codes.py           ⓪①…⑯ 编号表 + 别名解析 + 核心组 / 极简组
│   ├── base.py            基类：call_json（带字段校验与重试）/ call_text
│   ├── api00_router.py    ⓪ 路由总控（ traffic commander ）
│   ├── api01_roleplay.py  ① 角色扮演：唯一的最终输出者
│   ├── api02_user_emotion.py   ② 用户情绪感知（只读，不改角色状态）
│   ├── api03_topic_memory.py   ③ 话题与记忆钩子 / 外号 / 定时器意图
│   ├── api04_char_emotion.py   ④ 角色情绪生成
│   ├── api05_relationship.py   ⑤ 关系分量演化 + 拉黑/和解
│   ├── api06_event_record.py   ⑥ 事件入库（含 hidden_fact 秘密）
│   ├── api07_timing.py         ⑦ 时机决策（是否主动开口）
│   ├── api08_safety.py         ⑧ 安全基线与危机干预（一票否决）
│   ├── api09_send_strategy.py  ⑨ 发送策略：拆句 / 延迟 / 撤回节奏
│   ├── api10_proactive_draft.py ⑩ 主动消息起草
│   ├── api11_trait_evolution.py ⑪ 低频特质演化（候选 → 达到阈值才稳定）
│   ├── api12_reflection.py     ⑫ 深夜反思日记 + 次日情绪基调
│   ├── api13_memory_decay.py   ⑬ 记忆衰减与归档
│   ├── api14_user_facts.py     ⑭ 用户画像（长期事实 / 称呼）
│   ├── api15_consciousness.py  ⑮ 意识流（后台自言自语，可能变成主动开口）
│   └── api16_cognition.py      ⑯ 认知一致性（年龄/职业/知识盲区不许穿帮）
│
├── backend/               编排层 —— 单轮流水线
│   ├── round_handler.py   防抖合并 → 拦截 → ⓪路由 → 并行专家 → 写状态 → ① → ⑨ → 落库
│   ├── context_builder.py 把 identity/state/profile 拼成给模型看的中文块
│   ├── state_writer.py    把各专家的 delta/expectation 搬成纯数值（只搬运，不判断）
│   └── thresholds.py      长度规则、延迟缩放、数值夹紧
│
├── ui/                    界面层
│   ├── app.py             主界面组装 + 登录页路由 + 消息播放 + 主题应用
│   ├── login_window.py    首次启动建档（头像 / 性别 / 用户名 / 生日，除头像外必填飘红）
│   ├── drawer.py          右侧抽屉：改头像 / 改名 / 删除角色（严禁出现拉黑开关）
│   ├── chat_list.py       左侧图标栏（上聊天 / 下账号·加角色·设置）+ partners 列表
│   ├── chat_window.py     右侧消息区：气泡 / 正在输入 / 撤回 / 红叹号
│   ├── dialogs.py         创建角色 / 设置 / 生命状态 / 二次确认
│   └── widgets.py         基础控件
│
└── data/users/{user_id}/characters/{char_id}/
    ├── identity.json      身份：法定主名、自称、生日、大五人格、依恋、文化底色、认知盲区
    ├── state.json         状态：情绪 / 需求 / 关系分量 / 演化特征 / 定时器 / 拉黑
    ├── profile.json       用户画像（她眼里的你）
    ├── buffer.json        短期上下文（近 30 条，唯一进模型的对话数据）
    ├── candidates.json    特征候选计数（⑪ 累积用）
    ├── counter.json       轮次 / 每日主动次数 / 上次反思与遗忘日期
    ├── meta.json          UI 元数据（头像、最后一条预览、未读数）
    ├── memory.db          SQLite：events + messages
    └── reflections/       ⑫ 写的反思日记（按日期 .md）
```

---

## 三、单轮对话是怎么走完的

```
用户发消息（UI 气泡立刻上屏）
   │
   ├─ 防抖合并（DEBOUNCE_WINDOW 秒内的连发碎句合成一条）
   ├─ 拉黑检查：被拉黑时仍然读取，交给 ⑤ 判断要不要和好
   │
   ├─ ⓪ 路由：输出 required_apis 列表 + scene_intent + is_minimal
   ├─ 并行唤醒被点名的专家（信号量限并发，失败用各自的 FALLBACK 兜底）
   ├─ 把专家结论写回 state.json（纯数值搬运：delta / expectation / 列表追加）
   ├─ ⑧ 判定 crisis → 跳过 ①，直接输出危机回应
   ├─ ① 角色扮演：把 persona / 关系 / 状态 / 时间 / 专家情报 拼成 Prompt，产出回复正文
   ├─ ⑨ 发送策略：拆成若干条 + 每条 delay_ms + 可能的 recall 节奏
   └─ 落库：buffer.json（短期）+ memory.db（长期）+ meta.json（列表预览）
```

后台另有一条生命线（`core/scheduler.py`）：每个巡检周期让 needs 随时间上涨，
到点问 ⑦ 该不该开口，开口就让 ⑩ 起草 → ⑨ 排版 → 回调 UI；深夜让 ⑫ 写日记；
每隔 N 天让 ⑬ 整理记忆；用户设的定时器到点也走同一条主动通道。

---

## 四、安装与运行

```bash
cd DSP2
pip install -r requirements.txt      # 只有 flet 是必需的

# 配置密钥：已经写在 .env 里；也可改用环境变量
# Windows PowerShell：
$env:DEEPSEEK_API_KEY = "sk-xxxxxx"

python main.py               # 打开桌面界面
python main.py ui            # 同上
python main.py cli new       # 命令行建角色（走人设推导）
python main.py cli           # 命令行聊天（/state 看状态，/wake 手动触发一次主动消息，/q 退出）
python main.py cli list      # 列出角色
python main.py cli state <id># 打印生命状态
python main.py smoke         # 离线自检（不消耗 token）
python main.py smoke --online# 真实跑一轮，打印消耗的 token 与耗时
```

> 密钥优先级：**进程环境变量 > 项目根目录 `.env`**。
> `.env` 已加入 `.gitignore`；代码里没有任何明文密钥（`require_api_key()` 会在缺失时报错并给出配置提示）。

---

## 五、20 个岗位一览

| 编号 | 岗位 | 它决定什么 | 输出到哪里 |
| --- | --- | --- | --- |
| ⓪ | 路由总控 | 这轮要叫醒谁、场景是什么、是不是极简路径 | `required_apis` / `scene_intent` / `is_minimal` |
| ① | 角色扮演 | **最终说什么**（唯一的输出者，可申请联网搜索工具） | 回复正文 |
| ② | 用户情绪感知 | 你现在的情绪、真实需求、潜在攻击性 | 供 ①⑤⑧ 参考 |
| ③ | 话题与记忆 | 是否值得长期记住、外号、定时器意图、撤回有没有被看到、要不要长回复 | `state` / `identity` / `timers` |
| ④ | 角色情绪生成 | 她现在的复合情绪（主导+次要）、能量、是否迷糊、是否在戴面具 | `state.emotion` |
| ⑤ | 关系演化 | 好感/信任/依赖/边界的 delta、是否拉黑 | `state.relationship` |
| ⑥ | 事件入库 | 这件小事要不要存、有没有藏着没说出口的秘密 | `events` 表 |
| ⑦ | 时机决策 | 现在该不该主动开口、等多久再问 | 调度器 |
| ⑧ | 安全与危机 | 有没有触碰底线、她内心的第一反应、要不要强制走出角色 | 一票否决通道 |
| ⑨ | 发送策略 | 拆成几条、每条隔多久、要不要撤回 | UI 播放列表 |
| ⑩ | 主动起草 | 主动开口时说什么 | ⑦→⑩→⑨ |
| ⑪ | 特质演化 | 哪些口头禅/语气在稳定出现（低频、需累积） | `candidates` → `evolved_traits` |
| ⑫ | 深夜反思 | 写反思日记、调整次日情绪基调与关系倾向 | `reflections/*.md` + `state` |
| ⑬ | 记忆衰减 | 哪些钩子该归档（定期遗忘） | `events.status=archived` |
| ⑭ | 用户画像 | 你是什么样的人、该怎么称呼你 | `profile.json` |
| ⑮ | 意识流 | 独处时在想什么（可能变成主动消息） | `state` / 触发 ⑩ |
| ⑯ | 认知一致性 | 这句话会不会让她穿帮（年龄/职业/盲区） | 修正 ① 的表达边界 |
| ⑰ | 现实日历作息 | 她的时区、职业作息、睡眠窗口、节假日、此刻能不能回消息 | `state.world_rhythm`（每天一次） |
| ⑱ | 工具裁决 | 定时器/提醒这类工具请求，她接不接、怎么接 | 接受才注册；拒绝由 ① 说出口 |
| ⑲ | 人格种子 | 创建角色没填性格时，98% 掷出一个完整随机人（大五/暗黑三角/创伤/全职业） | `identity.json` 深层档案 |

> 注：编号只代表岗位，不代表执行顺序；⓪~⑯ 的顺序由 ⓪ 的输出决定，
> ⑰⑱⑲ 不走路由 —— 由后端在固定时机点名（每天巡检 / 出现工具意图 / 创建角色）。

---

## 六、调参速查（都在 `.env`）

| 键 | 默认 | 作用 |
| --- | --- | --- |
| `DEEPSEEK_MODEL` | `deepseek-chat` | 换 `deepseek-flash` 时保持 `DEEPSEEK_DISABLE_THINKING=true`，以免思考过程漏进聊天 |
| `PROACTIVE_TICK_SECONDS` | 60 | 后台巡检间隔，越小越"黏人" |
| `DEBOUNCE_WINDOW` | 3.0 | 用户连发碎句的合并窗口（滑动窗口：停打满 3 秒才用 `\n` 拼接提交） |
| `PERSONA_SEED_PROBABILITY` | 0.98 | 创建角色没填性格时，掷出 ⑲ 完整随机人的概率（剩 2% 是中性骨架） |
| `DSG_WEB_SEARCH_ENABLED` / `DSG_WEB_SEARCH_ENDPOINT` | 关 / 空 | ① 的联网搜索工具调用（tool_calls 拦截执行，需自建搜索端点） |
| `RATE_LIMIT_PER_CHAR_PER_DAY` | 6 | 每日主动消息上限 |
| `SLOW_ANALYZE_EVERY` | 4 | 每几轮补跑一次 ⑪ / ⑭ |
| `TRAIT_CONFIRM_COUNT` | 3 | 口头禅被 ⑪ 认出几次才变成稳定特征 |
| `REFLECTION_HOURS` | 23,3 | 允许写日记的小时 |
| `DECAY_INTERVAL_DAYS` | 7 | 遗忘整理间隔 |
| `DSG_BG_IMAGE` / `DSG_DEFAULT_AVATAR` | 空 | 纯 UI 用的本地背景图 / 头像路径 |

---

## 七、实测开销

一次普通聊天约 5~8 次 API 调用、4~5 秒、¥0.01~0.02；
让 ⑦ 判断"该不该主动开口"是唯一会周期性轮询的调用 —— 想省 token 就把 `PROACTIVE_TICK_SECONDS` 调大。

---

## 八、第二轮修正记录（针对实测暴露的问题）

| 症状 | 根因 | 修法 |
| --- | --- | --- |
| 她把你说的话当自己的台词复读 | 长上下文里模型分不清"谁在说这句话" | ① 号 Prompt 顶部新增【绝对身份认知】块，显式列出"你是 X / 对面是 Y / Y 刚说的是这句"，并明令禁止复述对方原句 |
| 叫错名字（改名后仍在叫旧名） | 用户名写死在 `config` 默认值里，且没有跨角色同步 | 新增 `core/account.py` 真人档案层 + 登录页建档；改名走 `rename_user()`，同步刷新所有存活角色的 account 锚点 |
| 问她"现在几点"答不上来 | 时间只在 `clock_block` 里，① 没被强制要求 | 身份锚点把客观时间直接钉进去，并要求她必须能答；答不出时用生活化表达而非"我不知道" |
| 问"你是不是 AI"就露馅 | 无应对约束 | 锚点明确：打死否认自己是 AI/程序/语言模型，用她自己的脾气回怼 |
| 同时到期的多个定时器只响一个，其余被丢弃 | `_check_timers` 取 `due[0]` 后没把剩下的放回队列 | 改为按创建时间排序、处理首条、`due[1:] + remain` 全部回写状态 |
| **点了「进入」毫无反应，进不去主界面** | 登录页的 `_enter` 是同步事件处理器，里面直接调用了 async 的 `_on_login`，返回的协程没人 await 就蒸发了（控制台只有一句 `RuntimeWarning: coroutine ... was never awaited`）。而旧的 mock 测试是直接 `asyncio.run(app._on_login(...))`，绕过了真实点击路径，所以没测出来 | `ui/widgets.py` 新增 `fire(page, callback, *args)`：识别 awaitable 并真正调度执行（优先 `page.run_task`，再退到事件循环 / `asyncio.run`）；登录页改用它。自检已加回归用例 |
| API 401 / 欠费时创建角色直接崩 | `derive_persona` 把异常往外抛 | 捕获后回落到性别预设模板，UI 层提示"已用预设模板"而不是报错退出 |

```bash
python main.py smoke   # 自检已覆盖：登录建档 → 改名同步 → 身份锚点注入 → 定时器循环
```

### 第三轮：按《终极开发执行手册》全面升级

| 手册要求 | 落地情况 |
| --- | --- |
| 登录窗口：头像 / 性别 / 用户名 / 生日，除头像外必填飘红 | `ui/login_window.py` + `core/account.validate_form()` |
| 左侧栏：上聊天信息，下账号 / 加角色 / 设置 | `ui/chat_list.build_left_panel()` |
| 头部只留角色名 + Menu，其下多一行状态文本（正在输入…） | `ui/chat_window.ChatPane.set_status()` |
| 每个气泡旁边带头像 | `ui/widgets.message_row()` |
| 每轮 >3 分钟插一条仿微信时间提示 | `ChatPane._maybe_time_line()`，阈值 `TIME_SEPARATOR_SECONDS` |
| 角色撤回（⑨ 下发）+ 用户 2 秒内撤回上一句 | 后端 `_apply_recall_actions` + `service.recall_user_message()`；数据库真删正文、留灰色提示 |
| 输入框图片按钮 | `FilePicker` + ③ 号识图 → `image_context` → ① |
| 右侧 NavigationDrawer：头像 / 名字 / 删除 | `ui/drawer.py`，删除前打包备份到 `backups/` |
| 设置：背景图色 / 全局字体 / 气泡字体 / 发送按钮 / 气泡 / 其他控件色 + API | `core/settings.py` + `SettingsDialog`，改完立刻生效 |
| 创建角色：国籍、文化边界、头像描述、查重、先渲染后写入 | `CreateCharacterDialog` + `create_character_async()`（走 `asyncio.to_thread`） |
| account 隐私：只有头像与用户名可读 | `core/account.api_view()`，引擎与调度器入口都强制过闸 |
| 模板绝对自由、无写死数据 | 去掉旧模板里的职业/兴趣/剧情预设，改成中性数值骨架 |
| ⑦ 按外向性动态调阈值 + 破冰 | `scheduler.extraversion_threshold()` + ⑦ 的 `is_first_proactive` |
| 拉黑黑盒：UI 不许有按钮 | 移除了原来头部的拉黑按钮；状态面板也不再显示拉黑状态 |
| 四级关系破裂 | `state.relationship_status`，后端拦截分支 + `deleted` 灰化只读 |
| 严格分条存储 | messages 表加 `group_id / seq`，一条气泡一行 |
| 写入不阻塞 UI | 创建角色、数据库批量写入走 `asyncio.to_thread` |

> **手册内部有一处冲突，这里说明取舍**：第 4 条说抽屉里要放拉黑按钮，
> 但第 5 条、第 6 条和"存储与数据流向"部分都强调**"严禁出现拉黑/拒收按钮，
> UI 上任何按钮都不能改这些状态，全凭 ⑤ 号决定"**。
> 我按后者执行 —— 抽屉里只有头像、名字、删除。这符合这套系统"黑盒感"的核心诉求。

自检：离线 60+ 项全通过（`python main.py smoke`），真实 API 一轮 7 次调用 5.2s ¥0.0164，
真实 flet Page 隐藏模式跑通「登录建档 → 空表单拦截 → 选角色 → 三分条渲染 → 撤回 → 抽屉 → 主题 → 删除备份」十步。

登录链路额外用 **flet 真实 Page**（`FLET_APP_HIDDEN` 隐藏模式）跑通：显示登录页 → 触发「进入」→ 建档 → 切主界面 → 列出角色 → 选中后标题/副标题/历史气泡全部正常。

> 教训写在这里：`python main.py smoke` 只能覆盖逻辑层，**UI 事件路径要用真实点击方式测**。
> 直接调 `asyncio.run(app._on_login(...))` 会绕过 bug 本身。

---

## 九、第四轮：主动发消息专项（为什么你"半天没看到"）

### 1. 真凶不是性格，是 400

⑦ 号时机决策的岗位说明书是纯中文写的 —— 它给了 JSON 结构模板，却**一次都没出现"JSON"这个词**。
DeepSeek 有个硬性规定：只要请求里带了 `response_format={"type":"json_object"}`，
消息中就必须出现 `json` 字样，否则整个请求直接 `HTTP 400`。

于是 ⑦ 每一次调用都被拒，`chat_json` 重试 3 次后静默返回兜底值：

```json
{"action": "wait", "wait_seconds": 3600, "reason": "解析失败兜底"}
```

**她一小时只看一次表，看完还说"再等一小时"** —— 所以永远等不到她主动。

修法放在 `core/llm.py` 的网络出口统一处理：开 JSON 模式时若消息里没有 `json` 字样，
自动给 user 消息补一句"只输出一个 JSON 对象"。17 份 prompt 一份都不用改。
修完实测 ⑦ 耗时 1.5s、`action=proactive`，理由和切入点都给得很具体。

### 2. 测试角色：糖糖（char_E）

```bash
python tools/seed_proactive_test.py          # 新建
python tools/seed_proactive_test.py --reset  # 打回"正想找人说话"的初始态
```

她是一份**极端样本**（不是作弊，是把"该开口"的条件全摆到位）：

| 项目 | 值 | 用意 |
| --- | --- | --- |
| 外向性 / 宜人性 | 0.96 / 0.88 | 见谁都想先开口 |
| 渴望关注 | 0.88 | 此刻正想找人说话 |
| 关系 | 每天聊几句的朋友，好感 0.76、边界感 0.30 | 不怕打扰你 |
| 距你上次说话 | 18 分钟 | 够久，但不至于触发"被冷落"的反向抑制 |
| 未闭环钩子 | 2 条（忘拍的照片 / 想问的下班） | ⑩ 有具体切入点，不用尬聊 |
| 首次开口 | 是 | ⑦ 的破冰规则生效 |
| `test_wait_cap_seconds` | 90 | 只对她生效的**数值闸门** |

`test_wait_cap_seconds` 写在 state.json 里：⑦ 说等一小时，后台也最多 90 秒就再问一次。
它只压缩等待时长，不改变 ⑦ 的判断 —— 仍然是"她决定发不发"，不是"到点就发"。

### 3. 三种验证方式（任选）

1. **什么都不做**：选中糖糖，实测 **10 秒**后第一条主动消息就到了（真实后台循环，不是探针）。
2. **点按钮**：点头部菜单 → 抽屉最下方「让她现在开口」（只有 `is_test_character` 的角色才有这一项）。
3. **看裁决**：
   ```bash
   python tools/proactive_probe.py char_E          # 只问 ⑦，打印 action / wait_seconds / 理由
   python tools/proactive_probe.py char_E --send   # 强制走 ⑩ 起草 → ⑨ 排版 → 落库并回显气泡
   ```

### 4. 顺带修掉的两处"看不见"

| 症状 | 根因 | 修法 |
| --- | --- | --- |
| 她明明发了消息，你在别的会话里什么都没看到 | `_notify` 只往 `page.pubsub` 丢了一条，而全项目没有任何订阅者 | 改成 `SnackBar` 浮条提示 + 左侧未读红点；pubsub 保留不动 |
| 后台巡检很慢、token 烧得快 | ⑮ 意识流只要空闲 ≥3 分钟就每次巡检都跑一遍，5 个空闲角色一小时 300 次请求 | `counter.last_consciousness_at` 记时间戳，间隔由 `CONSCIOUSNESS_EVERY_MINUTES`（默认 20 分钟）控制 |

### 5. 测试完怎么收尾

- 想留着当参考：不用管，她就是个普通角色，可以正常聊天。
- 想删干净：抽屉 → 删除角色（会打包备份到 `data/users/user_001/backups/`）。
- 想让某个**正式**角色也快速验证：把 `"test_wait_cap_seconds": 90` 手动加进它的 state.json，
  验证完删掉这两个字段即可恢复原行为。
