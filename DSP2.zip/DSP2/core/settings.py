"""界面外观与 API 偏好设置。

位置：`data/users/{user_id}/theme.json`，与 account.json 平级。

为什么单独一份文件：设置是"这台电脑上的观感"，和生物状态无关。
换个机器、换份数据目录，行程这种行为百万次会影响生命状态，但字号不该变。

这里只存**取值**，不存判断逻辑。界面层拿到的是一份完整的 dict，
缺哪个键就用下面的默认值补上，永远不会因为旧版本缺字段而渲染失败。
"""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional

from config import DATA_DIR, USER_ID

THEME_FILE = "theme.json"

DEFAULT_THEME: Dict[str, Any] = {
    # 背景：image 优先于 color
    "bg_image": "",
    "bg_color": "#1e1e1e",
    # 文字
    "text_color": "#ffffff",
    "sub_text_color": "#9e9e9e",
    # 字体（空串表示用软件默认字族）
    "font_global": "",
    "font_bubble": "",
    # 气泡：区分自己发的和对方发的
    "bubble_user_color": "#1472d0",
    "bubble_char_color": "#2f2f2f",
    "bubble_user_text_color": "#ffffff",
    "bubble_char_text_color": "#ffffff",
    # 发送按钮
    "send_button_color": "#1472d0",
    "send_button_text_color": "#ffffff",
    # 其他控件全局色：侧边栏、输入框、分割线、抽屉
    "panel_color": "#252526",
    "input_color": "#2f2f2f",
    "divider_color": "#2b2b2b",
    "drawer_color": "#202020",
    "accent_color": "#1472d0",
    # 气泡圆角与字号
    "bubble_radius": 10,
    "bubble_font_size": 15,
}

FONT_CHOICES: List[str] = [
    "",  # 软件默认
    "Microsoft YaHei",
    "SimHei",
    "KaiTi",
    "SimSun",
    "DengXian",
    "HarmonyOS Sans SC",
    "Source Han Sans SC",
]


def theme_dir(base_dir: Optional[Path] = None, user_id: Optional[str] = None) -> Path:
    base = Path(base_dir or DATA_DIR)
    path = base / "users" / (user_id or USER_ID)
    path.mkdir(parents=True, exist_ok=True)
    return path


def theme_path(base_dir: Optional[Path] = None, user_id: Optional[str] = None) -> Path:
    return theme_dir(base_dir, user_id) / THEME_FILE


def _atomic_write(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as file:
            json.dump(data, file, ensure_ascii=False, indent=2)
            file.flush()
            os.fsync(file.fileno())
        os.replace(tmp, path)
    except Exception:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def load_theme(base_dir: Optional[Path] = None, user_id: Optional[str] = None) -> Dict[str, Any]:
    """永远返回一份完整的主题 —— 缺键自动补默认值。"""
    theme = dict(DEFAULT_THEME)
    path = theme_path(base_dir, user_id)
    if not path.exists():
        return theme
    try:
        with path.open("r", encoding="utf-8") as file:
            saved = json.load(file)
    except (OSError, json.JSONDecodeError):
        return theme
    if isinstance(saved, dict):
        theme.update({k: v for k, v in saved.items() if k in DEFAULT_THEME})
    return theme


def save_theme(theme: Dict[str, Any], base_dir: Optional[Path] = None, user_id: Optional[str] = None) -> Dict[str, Any]:
    merged = load_theme(base_dir, user_id)
    merged.update({k: v for k, v in theme.items() if k in DEFAULT_THEME})
    _atomic_write(theme_path(base_dir, user_id), merged)
    return merged


def update_theme(**fields: Any) -> Dict[str, Any]:
    return save_theme(dict(fields))


def reset_theme(base_dir: Optional[Path] = None, user_id: Optional[str] = None) -> Dict[str, Any]:
    path = theme_path(base_dir, user_id)
    if path.exists():
        path.unlink()
    return dict(DEFAULT_THEME)


def font_family(theme: Dict[str, Any], key: str = "font_global") -> Optional[str]:
    """给 Flet 用的字族；空串表示不指定，交给系统默认。"""
    value = str(theme.get(key) or "").strip()
    return value or None
