"""初始 JSON 结构生成。

用户创建角色时提供：性别 / 姓名 / 出生日期 / 基础性格（可空）/ 特长 / 职业 / 国籍 / 文化边界。
其余（大五人格权重、依恋类型、文化底色、认知盲区）由一次"人设推导"把文字翻译成数值基线。

绝对自由原则（本轮新增的硬约束）：
    模板里**不许有任何写死的人设**。旧版本的两套男女模板里写死了
    "高中语文老师 / 古诗词 / 文艺复兴时期的艺术"这类内容，结果是模型的注意力
    总是被这些句子拉走，用户自己填的设定反而成了陪衬 —— 所有角色都像一个模子刻的。

    现在模板只剩**数值骨架**：人格五项给中位值、说话方式给空字符串，
    凡是"这个人具体是什么样"的部分，一律交给模型按用户填的内容推导。
"""

from __future__ import annotations

import random
from typing import Any, Dict, Optional

from core import timeutil

# ---------------------------------------------------------------- 中性骨架
# 注意：这里不允许出现职业、爱好、地域、人际关系等任何具体内容，
# 只能出现"容器形状"（有哪些字段、数值大致落在什么区间）。
OCEAN_MID = {
    "openness": 0.5,
    "conscientiousness": 0.5,
    "extraversion": 0.5,
    "agreeableness": 0.5,
    "neuroticism": 0.5,
}

NEUTRAL_SKELETON: Dict[str, Any] = {
    "gender": "女",
    "self_reference": "我",
    "occupation": "",
    "expertise": [],
    "culture_profile": {
        "origin": "",
        "knowledge_domains": [],
        "interests": [],
        "blind_spots": [],
    },
    "personality_ocean": dict(OCEAN_MID),
    "attachment_style": "secure",
    "speaking_style": "",
    # ── ⑲ 人格种子 / ⑰ 现实作息 的容器（默认空 = 和用户同一时区的普通人）──
    # 相对用户所在地的时差（小时，-12~+12，0=同一时区）
    "timezone_offset": 0.0,
    # 暗黑三角与过往创伤：不写进 persona_block 的明面，只影响潜意识层的判断
    "psychology_profile": {
        "dark_triad": {"narcissism": 0.1, "machiavellianism": 0.1, "psychopathy": 0.05},
        "trauma": "",
    },
    # 母语与打字习惯（标点/语气词/错别字率）
    "language_profile": {"mother_tongue": "中文", "typing_habits": ""},
    # 作息倾向与身体约束（夜班/早睡/小毛病）
    "physical_constraints": {"sleep_habit": "", "health_notes": ""},
}

# 基础性格留空时的随机种子：只给一个"倾向"，不给人设，
# 剩下的补全交给模型（见 derive_persona 的 randomize=True）
RANDOM_PERSONA_SEEDS = [
    "外冷内热，不擅长表达关心",
    "嘴硬心软，越在意越装作无所谓",
    "慢热，熟了以后话很多",
    "乐观爱吐槽，习惯用玩笑化解尴尬",
    "安静敏感，善于观察细节",
    "直来直去，不太考虑后果",
    "认真固执，认准的事很难劝动",
    "随和但容易被动，很少主动做决定",
]


def skeleton_for(gender: str) -> Dict[str, Any]:
    """按性别返回一份中性骨架 —— 只是两个容器，不是两种人。"""
    import copy

    data = copy.deepcopy(NEUTRAL_SKELETON)
    data["gender"] = gender or "女"
    return data


TEMPLATE_FEMALE = skeleton_for("女")
TEMPLATE_MALE = skeleton_for("男")
TEMPLATES = {"女": TEMPLATE_FEMALE, "female": TEMPLATE_FEMALE, "男": TEMPLATE_MALE, "male": TEMPLATE_MALE}


PERSONA_SYSTEM_PROMPT = """\
你是一位人物设定翻译专家。用户提供了一组字段，请你把它们翻译成\
可以用于长期演化的客观数值基线。

严格输出 JSON（不要任何解释文字），格式如下：
{
  "personality_ocean": {"openness": 0.0, "conscientiousness": 0.0, "extraversion": 0.0, "agreeableness": 0.0, "neuroticism": 0.0},
  "attachment_style": "secure | anxious | avoidant | disorganized",
  "speaking_style": "一句话描述这个人的说话方式",
  "traits_suggestion": ["初始特质1", "初始特质2"],
  "culture_profile": {
    "origin": "原生文化背景",
    "knowledge_domains": ["熟悉领域"],
    "interests": ["向往但不精通的领域"],
    "blind_spots": ["真实存在的认知盲区，会让她/他在这些话题上露怯"]
  },
  "avatar_impression": "若提供了头像描述，用一句话写她/他给人的第一印象；否则空字符串"
}

规则：
1. 数值必须是 0~1 的浮点数，禁止极端值 0.0 或 1.0（真实人格不存在绝对）。
2. 允许出现互相矛盾的组合（例如高尽责但低宜人），不要为了自洽而抹平冲突。
3. blind_spots 必须具体，不要写"未知领域"这种空话；要和这个人的年龄、职业、时代相符。
4. 国籍只用来校准文化背景与时代感的合理范围，**不要**套任何国家刻板印象，
   同一国籍内部也要允许巨大个体差异。
5. 若"文化或圈子边界"一栏为空，请只依据国籍推导出**最低限度**的文化底色，
   留出大量未知区域 —— 文化边界后续会在真实对话中动态补全。
6. 没有任何设定暗示故事情节。不要写这个人的过去经历了什么、认识谁、有什么目标，
   只描述"她/他这个人是什么质地"。
7. 字段缺失就基于常识合理补全，不要反问，也不要在 JSON 外多写一个字。
"""


def pick_random_persona() -> str:
    """基础性格留空时，后端掷一次骰子 —— 只掷"倾向"，不掷人设。"""
    return random.choice(RANDOM_PERSONA_SEEDS)


def derive_persona(
    client,
    gender: str,
    base_persona: str,
    occupation: str,
    expertise: str,
    age: int,
    nationality: str = "",
    culture_boundary: str = "",
    avatar_note: str = "",
    randomize: bool = False,
) -> Dict[str, Any]:
    """把用户的自然语言描述翻译成数值基线；**任何失败都必须回落到中性骨架**。

    优雅降级：用户自带密钥，余额不足 / 401 / 网络抖动都是常态。
    绝不能因为一次调用失败就让"创建角色"这件事失败 —— 人设可以后面慢慢演化。
    """
    fallback = skeleton_for(gender)
    if randomize and not (base_persona or "").strip():
        base_persona = pick_random_persona()
    if client is None or not getattr(client, "api_key", ""):
        return dict(fallback)

    payload: Dict[str, Any] = {}
    if gender:
        payload["性别"] = gender
    if age:
        payload["年龄"] = age
    if occupation:
        payload["职业"] = occupation
    if expertise:
        payload["特长"] = expertise
    if nationality:
        payload["国籍"] = nationality
    # 文化边界：给了就照用，没给则让模型只按国籍推最低限度的底色
    payload["文化或圈子边界"] = culture_boundary or "（未填写，请只依据国籍推导最低限度底色）"
    payload["头像描述"] = avatar_note or "（未提供）"
    payload["用户描述的基础性格"] = base_persona or "（用户未填写，请你自行补全）"

    try:
        data = client.chat_json(
            PERSONA_SYSTEM_PROMPT,
            _dump(payload),
            required=["personality_ocean", "attachment_style"],
            fallback=None,
            max_tokens=700,
        )
    except Exception as exc:  # noqa: BLE001  401 / 余额不足 / 网络错误
        print(f"[人设推导降级] 调用失败（{exc}），改用中性骨架。")
        return dict(fallback)
    if not isinstance(data, dict):
        return dict(fallback)

    ocean = data.get("personality_ocean") or {}
    merged_ocean = dict(fallback["personality_ocean"])
    for key in merged_ocean:
        try:
            value = float(ocean.get(key, merged_ocean[key]))
        except (TypeError, ValueError):
            continue
        merged_ocean[key] = round(min(0.98, max(0.02, value)), 2)

    culture = dict(fallback["culture_profile"])
    incoming = data.get("culture_profile") or {}
    for key in ("origin", "knowledge_domains", "interests", "blind_spots"):
        value = incoming.get(key)
        if value:
            culture[key] = value
    # 用户明确给了文化边界 → 原样塞进 interests⑯ 认知裁决会读它
    if (culture_boundary or "").strip():
        items = [x.strip() for x in culture_boundary.replace("，", ",").replace("、", ",").split(",") if x.strip()]
        culture["interests"] = list(dict.fromkeys(list(culture.get("interests") or []) + items))

    result: Dict[str, Any] = {
        "personality_ocean": merged_ocean,
        "attachment_style": data.get("attachment_style") or fallback["attachment_style"],
        "speaking_style": data.get("speaking_style") or "",
        "traits_suggestion": data.get("traits_suggestion") or [],
        "culture_profile": culture,
        "avatar_impression": data.get("avatar_impression") or "",
    }
    # 职业/特长由用户填，用户没填就保持空 —— 不替用户编
    result["occupation"] = occupation or ""
    result["expertise"] = expertise if isinstance(expertise, list) else []
    return result


def _dump(obj: Any) -> str:
    import json

    return json.dumps(obj, ensure_ascii=False)


def _num(value: Any, default: float) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


# ---------------------------------------------------------------- 默认文件
def build_defaults(
    user_id: str,
    char_id: str,
    display_name: str,
    gender: str = "女",
    age: int = 24,
    birthday: str = "",
    base_persona: str = "",
    occupation: str = "",
    expertise: Optional[list] = None,
    template: Optional[Dict[str, Any]] = None,
    user_display_name: str = "",
    nationality: str = "",
    culture_boundary: str = "",
    avatar_note: str = "",
    avatar_impression: str = "",
    seed: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """返回该角色目录下所有文件的初始内容。文件名 -> 数据。"""
    template = template or skeleton_for(gender)
    now = timeutil.now()
    now_text = timeutil.iso(now)
    expertise_list = expertise or list(template.get("expertise", []))
    boundary_list = [x.strip() for x in (culture_boundary or "").replace("，", ",").replace("、", ",").split(",") if x.strip()]

    identity = {
        "char_id": char_id,
        # 法定主名：用户起的昵称永远改不动它
        "char_display_name": display_name,
        "nicknames": [],
        "active_nickname": None,
        "gender": gender,
        "self_reference": template.get("self_reference", "我"),
        "birthday": birthday or "",
        "age_at_creation": age,
        "current_age": age,
        "occupation": occupation or template.get("occupation", ""),
        "expertise": expertise_list,
        "culture_profile": dict(template.get("culture_profile", {})),
        "personality_ocean": dict(template.get("personality_ocean", {})),
        "attachment_style": template.get("attachment_style", "secure"),
        "speaking_style": template.get("speaking_style", ""),
        "self_awareness": "human",
        "nationality": nationality or "",
        # 文化/圈子边界：原文保留 + 拆成列表，⑯ 号认知裁决按它决定
        # 这个人在哪些话题上是"圈内人"，哪些话题上会露怯
        "culture_boundary": boundary_list,
        "culture_boundary_raw": culture_boundary or "",
        # 头像不只是 UI 装饰：它被当成一条"外观暗示"参与人设推导
        "avatar_note": avatar_note or "",
        "avatar_impression": avatar_impression or "",
        # ── ⑲ 人格种子写入的深层档案（缺省 = 普通人的空容器）──
        "timezone_offset": _num(template.get("timezone_offset"), 0.0),
        "psychology_profile": dict(template.get("psychology_profile") or {}),
        "language_profile": dict(template.get("language_profile") or {}),
        "physical_constraints": dict(template.get("physical_constraints") or {}),
        # 种子自述（仅创建者可见的调试信息，不进任何 Prompt）
        "seed_summary": str((seed or {}).get("seed_summary") or ""),
        "created_at": now_text,
    }

    state = {
        "char_id": char_id,
        "emotion": {
            "label": "平静",
            "energy": 0.6,
            "physical_state": "正常",
            "patience_threshold": 0.6,
            "is_masking": False,
            "updated_at": now_text,
        },
        "needs": {"attention": 0.3, "validation": 0.3},
        "relationship": {
            "social_roles": [{"role": "陌生人", "weight": 1.0, "is_active": True}],
            "affection": 0.10,
            "alignment": 0.30,
            "trust": 0.30,
            "dominance": 0.50,
            "dependency": 0.05,
            "boundary": 0.90,
            "conflict_state": "正常",
            "power_struggle": {"is_stalemate": False, "who_blinks_first": None, "pressure_level": 0.0},
            "updated_at": now_text,
        },
        "evolved_traits": {"catchphrases": [], "tone": "", "knowledge_updates": []},
        "life_events": [],
        "stress_state": None,
        # ── 关系破裂四级 ──
        # blocked / rejected / friend_removed → 用户气泡上的红色感叹号（她也收不到或不想收）
        # deleted → 整个聊天面板变灰，只读历史
        # 这四个值**只能由 ⑤ 号关系演化 API 写入**，UI 上没有任何按钮能改
        "relationship_status": "normal",
        "relationship_status_reason": "",
        "relationship_status_at": None,
        # 兼容旧版本的布尔位，读写时 relationship_status 优先
        "is_blocked": False,
        "block_reason": "",
        "last_proactive_time": None,
        "last_user_message_time": None,
        "last_reflection_at": None,
        "last_decay_at": None,
        "unresolved_timers": [],
        # ⑰ 的缓存：今天她的作息表（sleep_window/busy_windows/can_reply…），
        # 空 dict = 还没算过，后台巡检会在今天第一次 tick 时补齐
        "world_rhythm": {},
        "rounds": 0,
    }

    profile = {
        "user_id": user_id,
        "display_name": user_display_name,
        "display_name_history": [{"value": user_display_name, "changed_at": now_text}],
        "user_personality_insight": "",
        "style_notes": "",
        "facts": [],
        "last_updated": now_text,
    }

    buffer = {"recent_messages": [], "max_keep": 30}
    candidates = {"catchphrases": {}, "tone_shifts": {}}
    counter = {
        "rounds": 0,
        "last_slow_analyze": 0,
        "last_reflection_date": None,
        "last_decay_date": None,
        "proactive_daily": {"date": timeutil.day_of_year_key(), "count": 0},
    }
    meta = {
        "char_id": char_id,
        "display_name": display_name,
        "avatar_path": "",
        "bio": "",
        "last_message_preview": "",
        "last_message_time": None,
        "unread_count": 0,
        "pinned": False,
        "muted": False,
        "archived": False,
        "created_at": now_text,
    }
    return {
        "identity.json": identity,
        "state.json": state,
        "profile.json": profile,
        "buffer.json": buffer,
        "candidates.json": candidates,
        "counter.json": counter,
        "meta.json": meta,
    }
