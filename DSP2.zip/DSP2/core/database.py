"""SQLite 长期记忆层。

events  : 未闭环钩子 / 高唤醒事件 / 隐瞒的秘密（hidden_fact）/ 生日与里程碑
messages: 完整对话历史

messages 的分条铁律（本轮新增）：
    ⑨ 号把一句话拆成 3 个气泡，这里就必须**严格存成 3 行**。
    绝不可以在写库时合并回一条 —— 否则软件一重启，三个气泡又塌成一坨，
    用户会看到"刚才明明是三条，重开变成一条"。

    同一批气泡共享一个 group_id，用 seq 决定顺序；撤回时把该行正文清掉、
    标成 recall_hint，UI 才会稳定显示"对方撤回了一条消息"。
"""

from __future__ import annotations

import sqlite3
import threading
from datetime import datetime
from typing import Any, Dict, List, Optional

from core import timeutil

_LOCK = threading.Lock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS events (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp    TEXT,
    event        TEXT,
    unresolved   TEXT,
    hidden_fact  TEXT,
    subtext      TEXT,
    arousal      TEXT DEFAULT 'normal',
    emotion_tag  TEXT,
    event_type   TEXT DEFAULT 'chat',
    status       TEXT DEFAULT 'open'
);
CREATE TABLE IF NOT EXISTS messages (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    role       TEXT,
    text       TEXT,
    timestamp  TEXT,
    round_no   INTEGER DEFAULT 0,
    extra      TEXT,
    group_id   TEXT DEFAULT '',
    seq        INTEGER DEFAULT 0,
    msg_type   TEXT DEFAULT 'text',
    is_deleted INTEGER DEFAULT 0,
    image_path TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_events_status ON events(status);
CREATE INDEX IF NOT EXISTS idx_messages_id ON messages(id);
"""

# 旧库缺列时补齐，避免升级后读历史崩掉
_MIGRATIONS = [
    ("group_id", "ALTER TABLE messages ADD COLUMN group_id TEXT DEFAULT ''"),
    ("seq", "ALTER TABLE messages ADD COLUMN seq INTEGER DEFAULT 0"),
    ("msg_type", "ALTER TABLE messages ADD COLUMN msg_type TEXT DEFAULT 'text'"),
    ("is_deleted", "ALTER TABLE messages ADD COLUMN is_deleted INTEGER DEFAULT 0"),
    ("image_path", "ALTER TABLE messages ADD COLUMN image_path TEXT DEFAULT ''"),
]


class CharacterDB:
    def __init__(self, db_path: str) -> None:
        self.db_path = str(db_path)
        self._init()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=10)
        conn.row_factory = sqlite3.Row
        return conn

    def _init(self) -> None:
        with _LOCK, self._connect() as conn:
            conn.executescript(SCHEMA)
            existing = {row[1] for row in conn.execute("PRAGMA table_info(messages)")}
            for column, sql in _MIGRATIONS:
                if column not in existing:
                    conn.execute(sql)
            # 补完列才建索引 —— 建在还没加上的列上会直接报 no such column，
            # 老库第一次打开就崩。
            conn.execute("CREATE INDEX IF NOT EXISTS idx_messages_group ON messages(group_id)")

    # ---------------------------------------------------------------- events
    def add_event(self, event: Dict[str, Any]) -> int:
        sql = (
            "INSERT INTO events (timestamp, event, unresolved, hidden_fact, subtext, "
            "arousal, emotion_tag, event_type, status) VALUES (?,?,?,?,?,?,?,?,?)"
        )
        params = (
            event.get("timestamp") or timeutil.now_str(),
            event.get("event") or "",
            event.get("unresolved"),
            event.get("hidden_fact"),
            event.get("subtext"),
            event.get("arousal") or "normal",
            event.get("emotion_tag"),
            event.get("event_type") or "chat",
            event.get("status") or "open",
        )
        with _LOCK, self._connect() as conn:
            cur = conn.execute(sql, params)
            return int(cur.lastrowid)

    def open_events(self, limit: int = 20, min_arousal: Optional[str] = None) -> List[Dict[str, Any]]:
        sql = "SELECT * FROM events WHERE status='open'"
        params: List[Any] = []
        if min_arousal:
            sql += " AND arousal=?"
            params.append(min_arousal)
        sql += " ORDER BY id DESC LIMIT ?"
        params.append(limit)
        with _LOCK, self._connect() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

    def resolve_event(self, event_id: int) -> None:
        with _LOCK, self._connect() as conn:
            conn.execute("UPDATE events SET status='closed' WHERE id=?", (event_id,))

    def archive_events(self, event_ids: List[int]) -> None:
        if not event_ids:
            return
        marks = ",".join("?" * len(event_ids))
        with _LOCK, self._connect() as conn:
            conn.execute(
                f"UPDATE events SET status='archived' WHERE id IN ({marks})",
                tuple(event_ids),
            )

    def count_events(self) -> int:
        with _LOCK, self._connect() as conn:
            return int(conn.execute("SELECT COUNT(*) FROM events").fetchone()[0])

    # ---------------------------------------------------------------- messages
    @staticmethod
    def new_group_id() -> str:
        import uuid

        return uuid.uuid4().hex[:12]

    def add_message(
        self,
        role: str,
        text: str,
        round_no: int = 0,
        extra: str = "",
        group_id: str = "",
        seq: int = 0,
        msg_type: str = "text",
        image_path: str = "",
    ) -> int:
        """插入一条消息，返回 rowid。拆几个气泡就调几次，各次 seq 递增。"""
        sql = (
            "INSERT INTO messages (role, text, timestamp, round_no, extra, "
            "group_id, seq, msg_type, is_deleted, image_path) VALUES (?,?,?,?,?,?,?,?,?,?)"
        )
        params = (
            role,
            text,
            timeutil.now_str(),
            round_no,
            extra,
            group_id or self.new_group_id(),
            seq,
            msg_type,
            0,
            image_path or "",
        )
        with _LOCK, self._connect() as conn:
            cur = conn.execute(sql, params)
            return int(cur.lastrowid)

    def add_message_batch(self, rows: List[Dict[str, Any]]) -> List[int]:
        """一次 Round Trip 写入同一批气泡（同 group_id，seq 递增），保证顺序原子。"""
        ids: List[int] = []
        group_id = self.new_group_id()
        with _LOCK, self._connect() as conn:
            for index, row in enumerate(rows):
                cur = conn.execute(
                    "INSERT INTO messages (role, text, timestamp, round_no, extra, "
                    "group_id, seq, msg_type, is_deleted, image_path) VALUES (?,?,?,?,?,?,?,?,?,?)",
                    (
                        row.get("role") or "assistant",
                        row.get("text") or "",
                        row.get("timestamp") or timeutil.now_str(),
                        int(row.get("round_no") or 0),
                        row.get("extra") or "",
                        row.get("group_id") or group_id,
                        int(row.get("seq") if row.get("seq") is not None else index),
                        row.get("msg_type") or "text",
                        0,
                        row.get("image_path") or "",
                    ),
                )
                ids.append(int(cur.lastrowid))
        return ids

    def recall_message(self, msg_id: int, by: str = "character") -> bool:
        """撤回：正文物理清空，行本身留下来当灰色提示用。

        完全 DELETE 会导致重启后连"对方撤回了一条消息"都消失，
        看起来像那条消息从来没存在过 —— 和真实 IM 的观感不符。
        """
        with _LOCK, self._connect() as conn:
            cur = conn.execute(
                "UPDATE messages SET is_deleted=1, text='', msg_type='recall_hint', extra=? "
                "WHERE id=? AND is_deleted=0",
                (by, int(msg_id)),
            )
            return cur.rowcount > 0

    def last_user_message_id(self) -> Optional[int]:
        with _LOCK, self._connect() as conn:
            row = conn.execute(
                "SELECT id FROM messages WHERE role='user' AND is_deleted=0 "
                "ORDER BY id DESC LIMIT 1"
            ).fetchone()
        return int(row[0]) if row else None

    def get_message(self, msg_id: int) -> Optional[Dict[str, Any]]:
        with _LOCK, self._connect() as conn:
            row = conn.execute("SELECT * FROM messages WHERE id=?", (int(msg_id),)).fetchone()
        return dict(row) if row else None

    def list_messages(self, limit: int = 200, before_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """按 group_id / seq 稳定排序输出，撤回行保留（UI 负责渲染灰色提示）。"""
        sql = "SELECT * FROM messages"
        params: List[Any] = []
        if before_id:
            sql += " WHERE id < ?"
            params.append(before_id)
        sql += " ORDER BY id ASC, seq ASC LIMIT ?"
        params.append(limit)
        with _LOCK, self._connect() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

    def count_messages(self) -> int:
        with _LOCK, self._connect() as conn:
            return int(conn.execute("SELECT COUNT(*) FROM messages WHERE is_deleted=0").fetchone()[0])
