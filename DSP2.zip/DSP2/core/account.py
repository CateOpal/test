"""用户账户 —— 这套系统里唯一属于"真人"的档案。

位置：`data/users/{user_id}/account.json`，与 characters/ 平级，跨角色共享。

隐私红线（这是本轮新增的硬约束）：
    同一个文件里同时存着"给 AI 看的"和"绝对不给 AI 看的"两类信息。
    - 可被任何 API 读取：user_id / display_name / avatar_path / avatar_note
    - 任何情况下都不许进 Prompt：gender / birthday

    真人的性别与出生年月日，是用户在对话中自己愿不愿意说的事。
    用户没说，模型就必须不知道 —— 不能因为它在同一个 JSON 里就被顺手塞进上下文。
    所有拿账户信息给 Prompt 的地方，一律走 `api_view()`，不许直接传整个 dict。
"""

from __future__ import annotations

import json
import tempfile
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

from config import DATA_DIR, USER_ID
from core import timeutil

ACCOUNT_FILE = "account.json"

# 允许进入 Prompt 的字段白名单 —— 越小越安全
API_VISIBLE_KEYS = ("user_id", "display_name", "avatar_path", "avatar_note")
# 一旦有人试图把这些塞给模型，就是 bug
FORBIDDEN_KEYS = ("gender", "birthday", "created_at", "display_name_history")


def api_view(account: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """给模型的账户视图 —— 只有名字和头像，性别生日连影子都不会出现。

    为什么连 key 都不留：留了 `"gender": None` 一样会被引擎当成"不知道该怎么填"的暗示，
    甚至让模型编一个。最干净的做法是让它从来没见过这两个字段。
    """
    if not account or not isinstance(account, dict):
        return {}
    view = {key: account.get(key) for key in API_VISIBLE_KEYS if account.get(key)}
    view.setdefault("user_id", account.get("user_id") or USER_ID)
    return view


def validate_form(display_name: str, gender: str, birthday: str) -> List[str]:
    """登录表单校验：除头像外全部必填，返回错误列表（空表示通过）。"""
    errors: List[str] = []
    if not (display_name or "").strip():
        errors.append("用户名不能为空")
    if not (gender or "").strip():
        errors.append("请选择性别")
    if not (birthday or "").strip():
        errors.append("请填写出生年月日")
    elif not _valid_birthday(birthday):
        errors.append("出生年月日格式为 YYYY-MM-DD")
    return errors


def _valid_birthday(value: str) -> bool:
    from datetime import datetime

    text = (value or "").strip()
    try:
        datetime.strptime(text, "%Y-%m-%d")
    except ValueError:
        return False
    return True


def account_dir(base_dir: Optional[Path] = None, user_id: Optional[str] = None) -> Path:
    base = Path(base_dir or DATA_DIR)
    path = base / "users" / (user_id or USER_ID)
    path.mkdir(parents=True, exist_ok=True)
    return path


def account_path(base_dir: Optional[Path] = None, user_id: Optional[str] = None) -> Path:
    return account_dir(base_dir, user_id) / ACCOUNT_FILE


def _atomic_write(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as file:
            json.dump(data, file, ensure_ascii=False, indent=2)
            file.flush()
            os.fsync(file.fileno())
        os.replace(tmp, path)
    except Exception:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def load_account(base_dir: Optional[Path] = None, user_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """已有档案返回 dict，没有返回 None（调用方据此决定要不要显示登录页）。"""
    path = account_path(base_dir, user_id)
    if not path.exists():
        return None
    try:
        with path.open("r", encoding="utf-8") as file:
            data = json.load(file)
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(data, dict) or not data.get("display_name"):
        return None
    data.setdefault("display_name_history", [])
    data.setdefault("user_id", user_id or USER_ID)
    return data


def create_account(
    display_name: str,
    base_dir: Optional[Path] = None,
    user_id: Optional[str] = None,
    avatar_path: str = "",
    gender: str = "",
    birthday: str = "",
    avatar_note: str = "",
) -> Dict[str, Any]:
    name = (display_name or "").strip()
    if not name:
        raise ValueError("名字不能为空")
    data = {
        "user_id": user_id or USER_ID,
        # ── 以下三项对模型可见 ──
        "display_name": name,
        "avatar_path": avatar_path or "",
        # 头像画面的客观描述（外观暗示）——作为权重参与人设推导，而不是剧情预设
        "avatar_note": avatar_note or "",
        # ── 以下两项永不出库给 API ──
        "gender": (gender or "").strip(),
        "birthday": (birthday or "").strip(),
        # 真人的改名记在这里；角色自己认不认、跟不跟着改，是她的事（profile.json）
        "display_name_history": [{"value": name, "changed_at": timeutil.now_str(), "by": "self"}],
        "created_at": timeutil.now_str(),
    }
    _atomic_write(account_path(base_dir, user_id), data)
    return data


def update_account(
    base_dir: Optional[Path] = None,
    user_id: Optional[str] = None,
    **fields: Any,
) -> Optional[Dict[str, Any]]:
    """局部更新档案（改名 / 换头像 / 改性别生日）。"""
    account = load_account(base_dir, user_id)
    if not account:
        return None
    for key, value in fields.items():
        if key == "display_name" and (value or "").strip():
            new_name = str(value).strip()
            if new_name != account.get("display_name"):
                history: List[Dict[str, Any]] = account.setdefault("display_name_history", [])
                history.append({"value": new_name, "changed_at": timeutil.now_str(), "by": "self"})
                account["display_name_history"] = history[-20:]
            account["display_name"] = new_name
        elif key in ("avatar_path", "avatar_note", "gender", "birthday"):
            account[key] = value
    _atomic_write(account_path(base_dir, user_id), account)
    return account


def rename_account(
    display_name: str,
    base_dir: Optional[Path] = None,
    user_id: Optional[str] = None,
) -> Dict[str, Any]:
    account = load_account(base_dir, user_id)
    if account is None:
        # 没有档案时改名必须先建档 —— 名字必填，不提供任何写死的兜底名
        account = create_account(display_name, base_dir, user_id)
    name = (display_name or "").strip()
    if not name or name == account.get("display_name"):
        return account
    account["display_name"] = name
    history: List[Dict[str, Any]] = account.setdefault("display_name_history", [])
    history.append({"value": name, "changed_at": timeutil.now_str(), "by": "self"})
    account["display_name_history"] = history[-20:]
    _atomic_write(account_path(base_dir, user_id), account)
    return account


def set_avatar(path: str, base_dir: Optional[Path] = None, user_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
    account = load_account(base_dir, user_id)
    if not account:
        return None
    account["avatar_path"] = path or ""
    _atomic_write(account_path(base_dir, user_id), account)
    return account


def ensure_account(
    display_name: Optional[str] = None,
    base_dir: Optional[Path] = None,
    user_id: Optional[str] = None,
) -> Dict[str, Any]:
    """CLI / 自检用：没有档案就按调用方给的名字建一个，不打断流程。

    注意：这里不提供任何写死的默认名。首次建档却没给名字属于调用方 bug，
    直接抛错比悄悄塞一个假名字进【绝对身份认知】要好。
    """
    account = load_account(base_dir, user_id)
    if account:
        return account
    if not (display_name or "").strip():
        raise ValueError("首次建档必须提供名字（系统不写死任何默认用户名）")
    return create_account(display_name.strip(), base_dir, user_id)
