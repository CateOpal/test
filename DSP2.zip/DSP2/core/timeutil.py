"""时间工具。

模型本身没有时钟，所有"现在几点""上次聊天是多久前""角色今年几岁"
都由这里算好后作为客观变量注入 Prompt。
"""

from __future__ import annotations

from datetime import datetime
from typing import Optional

_WEEKDAYS = ("一", "二", "三", "四", "五", "六", "日")


def now() -> datetime:
    return datetime.now()


def now_str() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def iso(dt: Optional[datetime] = None) -> str:
    return (dt or datetime.now()).strftime("%Y-%m-%dT%H:%M:%S")


def human(dt: Optional[datetime] = None) -> str:
    """给模型看的中文时间：2026-10-20 23:11 周一。"""
    dt = dt or datetime.now()
    return f"{dt.strftime('%Y-%m-%d %H:%M')} 周{_WEEKDAYS[dt.weekday()]}"


def parse(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    text = str(value).replace("T", " ").strip()
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return datetime.strptime(text[: len(fmt) + 3], fmt)
        except ValueError:
            continue
    try:
        return datetime.fromisoformat(text)
    except ValueError:
        return None


def minutes_since(value: Optional[str]) -> Optional[int]:
    dt = parse(value)
    if not dt:
        return None
    return int((datetime.now() - dt).total_seconds() // 60)


def idle_text(value: Optional[str]) -> str:
    """距上一条消息的中文描述。"""
    minutes = minutes_since(value)
    if minutes is None:
        return "未知"
    if minutes < 1:
        return "刚刚"
    if minutes < 60:
        return f"{minutes} 分钟"
    if minutes < 60 * 24:
        return f"{minutes // 60} 小时 {minutes % 60} 分钟"
    days = minutes // (60 * 24)
    return f"{days} 天 {(minutes % (60 * 24)) // 60} 小时"


def current_age(birthday: Optional[str], reference: Optional[datetime] = None) -> Optional[int]:
    """角色会随时间真实变老：按当前日期现算周岁。"""
    birth = parse(birthday)
    if not birth:
        return None
    ref = reference or datetime.now()
    age = ref.year - birth.year
    if (ref.month, ref.day) < (birth.month, birth.day):
        age -= 1
    return age


def clock_block(now_dt: Optional[datetime] = None) -> str:
    dt = now_dt or datetime.now()
    hour = dt.hour
    if 0 <= hour < 6:
        period = "深夜（正常人应该已经睡了）"
    elif 6 <= hour < 9:
        period = "清晨"
    elif 9 <= hour < 12:
        period = "上午（多半在忙）"
    elif 12 <= hour < 14:
        period = "午间"
    elif 14 <= hour < 18:
        period = "下午"
    elif 18 <= hour < 22:
        period = "晚上（一天中最容易闲聊的时段）"
    else:
        period = "夜里（临近睡觉）"
    return f"{human(dt)}，{period}"


def day_of_year_key(dt: Optional[datetime] = None) -> str:
    return (dt or datetime.now()).strftime("%Y-%m-%d")
