"""DeepSeek 统一调用客户端。

定位：这是整个项目唯一的网络出口，也是唯一的"翻译官"。
它只做三件事：发请求、把返回内容洗成干净的纯文本或 JSON、失败时重试。
它对"这段对话是什么情绪"一无所知 —— 语义永远归 17 个 API 管。
"""

from __future__ import annotations

import json
import re
import urllib.error
import urllib.request
from typing import Any, Dict, List, Optional, Sequence

from config import (
    DEEPSEEK_API_KEY,
    DEEPSEEK_BASE_URL,
    DISABLE_THINKING,
    JSON_MAX_RETRY,
    MODEL,
    REQUEST_TIMEOUT,
)

_FENCE_RE = re.compile(r"^\s*```(?:json|JSON)?\s*(.*?)\s*```\s*$", re.S)


class LLMError(Exception):
    """API 调用层异常（网络、鉴权、额度等）。"""


class DeepSeekClient:
    def __init__(
        self,
        api_key: Optional[str] = None,
        model: Optional[str] = None,
        disable_thinking: Optional[bool] = None,
        timeout: Optional[float] = None,
    ) -> None:
        self.api_key = api_key or DEEPSEEK_API_KEY
        self.model = model or MODEL
        self.disable_thinking = DISABLE_THINKING if disable_thinking is None else disable_thinking
        self.timeout = timeout or REQUEST_TIMEOUT
        self.endpoint = f"{DEEPSEEK_BASE_URL}/chat/completions"
        # 调用统计（估算成本用）
        self.stats: Dict[str, int] = {
            "calls": 0,
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "json_retries": 0,
            "failures": 0,
        }

    # ------------------------------------------------------------------ 底层
    def _post(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        request = urllib.request.Request(
            self.endpoint,
            data=body,
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
                "Authorization": f"Bearer {self.api_key}",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = ""
            try:
                detail = exc.read().decode("utf-8", "ignore")[:400]
            except Exception:  # noqa: BLE001
                pass
            raise LLMError(f"HTTP {exc.code}: {detail or exc.reason}") from exc
        except urllib.error.URLError as exc:
            raise LLMError(f"网络错误: {exc.reason}") from exc
        except Exception as exc:  # noqa: BLE001
            raise LLMError(f"未知错误: {exc}") from exc

    @staticmethod
    def _extract_text(data: Dict[str, Any]) -> str:
        try:
            choices = data["choices"]
            message = choices[0]["message"]
            # 关键：只取 content，绝不读取 reasoning_content（思维链）
            content = message.get("content") or ""
            return content.strip()
        except (KeyError, IndexError, TypeError) as exc:
            raise LLMError(f"响应结构异常: {str(data)[:300]}") from exc

    @staticmethod
    def _to_json_object(text: str) -> Any:
        """把模型输出洗成 Python 对象：去围栏、找首尾花括号。"""
        cleaned = text.strip()
        fence = _FENCE_RE.match(cleaned)
        if fence:
            cleaned = fence.group(1).strip()
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError:
            pass
        start, end = cleaned.find("{"), cleaned.rfind("}")
        if start >= 0 and end > start:
            return json.loads(cleaned[start : end + 1])
        start, end = cleaned.find("["), cleaned.rfind("]")
        if start >= 0 and end > start:
            return json.loads(cleaned[start : end + 1])
        raise ValueError(f"无法解析为 JSON: {cleaned[:200]}")

    # ------------------------------------------------------------------ 对话
    def chat(
        self,
        system: str,
        user: Optional[str] = None,
        messages: Optional[Sequence[Dict[str, str]]] = None,
        *,
        json_mode: bool = False,
        max_tokens: int = 400,
        temperature: Optional[float] = None,
    ) -> str:
        """纯文本/JSON 字符串输出。"""
        if json_mode:
            # DeepSeek 的硬性要求：开 response_format=json_object 时，
            # 消息里必须出现 "json" 这个词，否则整个请求直接 400。
            # ⑦ 号时机决策的岗位说明书是纯中文的（它只写 JSON 结构，没写"JSON"这个词），
            # 于是它每一次调用都被拒，静默走兜底 wait 3600 ——
            # 表现就是"角色从来不主动发消息"。这一行是系统性兜底，
            # 而不是逐个去改 17 份 prompt。
            combined = f"{system or ''}{user or ''}".lower()
            if "json" not in combined:
                hint = "只输出一个 JSON 对象，不要任何解释文字。"
                user = f"{user}\n\n{hint}" if user else hint

        payload_messages: List[Dict[str, str]] = [{"role": "system", "content": system}]
        if messages:
            payload_messages.extend({"role": m["role"], "content": m["content"]} for m in messages)
        if user:
            payload_messages.append({"role": "user", "content": user})

        payload: Dict[str, Any] = {
            "model": self.model,
            "messages": payload_messages,
            "max_tokens": max_tokens,
            "stream": False,
        }
        if json_mode:
            # 第一道防线：接口层锁死必须输出合法 JSON
            payload["response_format"] = {"type": "json_object"}
        if temperature is not None:
            payload["temperature"] = temperature
        if self.disable_thinking:
            # 关闭思维链，避免"思考词"外泄
            payload["thinking"] = {"type": "disabled"}

        try:
            data = self._post(payload)
        except LLMError as exc:
            # 兼容不支持 thinking 字段的网关：自动降级重试一次
            if "thinking" in str(exc) and payload.get("thinking"):
                self.disable_thinking = False
                payload.pop("thinking", None)
                data = self._post(payload)
            else:
                self.stats["failures"] += 1
                raise

        self.stats["calls"] += 1
        usage = data.get("usage") or {}
        self.stats["prompt_tokens"] += int(usage.get("prompt_tokens") or 0)
        self.stats["completion_tokens"] += int(usage.get("completion_tokens") or 0)
        return self._extract_text(data)

    def chat_json(
        self,
        system: str,
        user: str,
        *,
        required: Optional[Sequence[str]] = None,
        fallback: Optional[Any] = None,
        retries: int = JSON_MAX_RETRY,
        max_tokens: int = 400,
        temperature: Optional[float] = None,
    ) -> Any:
        """带字段校验 + 重试 + 兜底的 JSON 调用（第四道防线）。"""
        last_raw = ""
        for attempt in range(max(1, retries)):
            try:
                last_raw = self.chat(
                    system,
                    user,
                    json_mode=True,
                    max_tokens=max_tokens,
                    temperature=temperature,
                )
                data = self._to_json_object(last_raw)
                if required:
                    missing = [key for key in required if key not in (data or {})]
                    if missing:
                        raise KeyError(f"缺少必要字段 {missing}")
                return data
            except Exception as exc:  # noqa: BLE001
                self.stats["json_retries"] += 1
                if attempt == max(1, retries) - 1:
                    if fallback is not None:
                        return fallback
                    raise LLMError(f"JSON 解析失败（已重试 {retries} 次）：{exc} | 原文：{last_raw[:200]}")
        return fallback

    def usage_summary(self) -> str:
        s = self.stats
        cost = (s["prompt_tokens"] * 0.002 + s["completion_tokens"] * 0.008) / 1000
        return (
            f"调用 {s['calls']} 次 | 输入 {s['prompt_tokens']} tokens | 输出 {s['completion_tokens']} tokens "
            f"| JSON重试 {s['json_retries']} | 失败 {s['failures']} | 约 ¥{cost:.4f}"
        )
