"""本地存储层 —— "无情的 IO 机器"。

职责边界：只做读、写、加锁、原子替换。**绝不做任何语义判断**。
这里没有一行 `if 情绪 == '吃醋'`，只有 JSON 的路径与字节。

并发安全：每个角色一把 asyncio.Lock + os.replace 原子替换，
保证"用户正在发消息"和"后台意识流在写状态"不会把文件写坏。
"""

from __future__ import annotations

import asyncio
import json
import os
import tempfile
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from core import timeutil

JSON_FILES = (
    "identity.json",
    "state.json",
    "profile.json",
    "buffer.json",
    "candidates.json",
    "counter.json",
    "meta.json",
)

_LOCKS: Dict[str, asyncio.Lock] = {}


def _lock_for(key: str) -> asyncio.Lock:
    lock = _LOCKS.get(key)
    if lock is None:
        lock = asyncio.Lock()
        _LOCKS[key] = lock
    return lock


class CharacterStorage:
    def __init__(self, base_dir: Path, user_id: str, char_id: str) -> None:
        self.root = Path(base_dir) / "users" / user_id / "characters" / char_id
        self.user_id = user_id
        self.char_id = char_id
        self.root.mkdir(parents=True, exist_ok=True)
        self.reflections_dir = self.root / "reflections"
        self.db_path = self.root / "memory.db"
        self._lock = _lock_for(f"{user_id}/{char_id}")
        self._cache: Dict[str, Any] = {}

    # ---------------------------------------------------------------- 原子读写
    @staticmethod
    def _atomic_write(path: Path, data: Any) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp_path = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as file:
                json.dump(data, file, ensure_ascii=False, indent=2)
                file.flush()
                os.fsync(file.fileno())
            os.replace(tmp_path, path)
        except Exception:
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)
            raise

    def exists(self, name: str) -> bool:
        return (self.root / name).exists()

    def load(self, name: str) -> Any:
        if name in self._cache:
            return self._cache[name]
        path = self.root / name
        if not path.exists():
            raise FileNotFoundError(f"缺少数据文件 {path}，请先创建角色")
        with path.open("r", encoding="utf-8") as file:
            data = json.load(file)
        self._cache[name] = data
        return data

    def save(self, name: str, data: Any) -> None:
        self._atomic_write(self.root / name, data)
        self._cache[name] = data

    async def update(self, name: str, mutator: Callable[[Any], Any]) -> Any:
        """带锁的读-改-写，协程安全。"""
        async with self._lock:
            data = json.loads(json.dumps(self.load(name), ensure_ascii=False))
            result = mutator(data)
            self.save(name, data)
            return result

    # ---------------------------------------------------------------- 初始化
    def init_defaults(self, defaults: Dict[str, Any]) -> None:
        for name, data in defaults.items():
            if not (self.root / name).exists():
                self._atomic_write(self.root / name, data)
                self._cache[name] = data
        self.reflections_dir.mkdir(parents=True, exist_ok=True)

    # ---------------------------------------------------------------- 便捷访问
    @property
    def identity(self) -> Dict[str, Any]:
        return self.load("identity.json")

    @property
    def state(self) -> Dict[str, Any]:
        return self.load("state.json")

    @property
    def profile(self) -> Dict[str, Any]:
        return self.load("profile.json")

    @property
    def buffer(self) -> Dict[str, Any]:
        return self.load("buffer.json")

    @property
    def counter(self) -> Dict[str, Any]:
        return self.load("counter.json")

    @property
    def meta(self) -> Dict[str, Any]:
        return self.load("meta.json")

    def refresh_age(self) -> Optional[int]:
        """角色会真实变老：每次启动/新一天重算周岁。"""
        identity = self.identity
        age = timeutil.current_age(identity.get("birthday"))
        if age is not None and age != identity.get("current_age"):
            identity["current_age"] = age
            self.save("identity.json", identity)
        return age

    # ---------------------------------------------------------------- 短期上下文
    def append_buffer(self, role: str, text: str, round_no: int = 0) -> None:
        data = self.load("buffer.json")
        data.setdefault("recent_messages", [])
        data["recent_messages"].append(
            {
                "round": round_no,
                "role": role,
                "text": text,
                "time": timeutil.now_str(),
            }
        )
        keep = int(data.get("max_keep", 30) or 30)
        data["recent_messages"] = data["recent_messages"][-keep:]
        self.save("buffer.json", data)

    def recent_messages(self, limit: int = 12) -> List[Dict[str, Any]]:
        data = self.load("buffer.json")
        messages = data.get("recent_messages") or []
        return messages[-limit:]

    # ---------------------------------------------------------------- 定时任务
    def list_timers(self) -> List[Dict[str, Any]]:
        return list(self.load("state.json").get("unresolved_timers") or [])

    def set_timers(self, timers: List[Dict[str, Any]]) -> None:
        state = self.load("state.json")
        state["unresolved_timers"] = timers
        self.save("state.json", state)


class CharacterRegistry:
    """扫描 data/users/{user_id}/characters/ 下所有角色。"""

    def __init__(self, base_dir: Path, user_id: str) -> None:
        self.root = Path(base_dir) / "users" / user_id / "characters"
        self.root.mkdir(parents=True, exist_ok=True)
        self.user_id = user_id
        # 同一个角色只留一个句柄。
        # 原先每次 get() 都 new 一个 CharacterStorage，每个实例自带一份内存缓存 ——
        # UI 改完名字（写进了它那个句柄的缓存），后台生命循环却是另一个句柄，
        # 读到的还是旧的那份。表现是"改了没生效，重启才好"。
        self._instances: Dict[str, CharacterStorage] = {}

    def char_ids(self) -> List[str]:
        return sorted(p.name for p in self.root.iterdir() if p.is_dir() and (p / "identity.json").exists())

    def get(self, char_id: str) -> CharacterStorage:
        storage = self._instances.get(char_id)
        if storage is None:
            storage = CharacterStorage(Path(self.root.parent.parent.parent), self.user_id, char_id)
            self._instances[char_id] = storage
        return storage

    def next_char_id(self) -> str:
        existing = self.char_ids()
        index = len(existing)
        while f"char_{chr(ord('A') + index)}" in existing:
            index += 1
        return f"char_{chr(ord('A') + index)}" if index < 26 else f"char_{index}"
