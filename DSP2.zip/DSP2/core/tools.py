"""工具调用：① 号可以申请联网搜索，后端拦截执行。

机制（OpenAI 兼容 tools 协议）：
    ① 的回复里若带 tool_calls → llm 层拦截 → 逐个交给这里的 handler 执行
    → 结果以 role=tool 的消息回注 → 模型基于搜索结果重新组织语言。
整个过程对 ① 透明：它只觉得"我去查了一下"。

开关在 config：WEB_SEARCH_ENABLED + WEB_SEARCH_ENDPOINT。
端点是一个自建的搜索 HTTP 服务（如 SearXNG 的 /search?q=...&format=json）。
没配置端点时工具依旧声明可用，但调用会收到"当前不可用"的实话 ——
① 会用自己的话把"我查不到"表达出来，而不是编一个搜索结果。
"""

from __future__ import annotations

import json
import urllib.parse
import urllib.request
from typing import Any, Dict, List

from config import WEB_SEARCH_ENABLED, WEB_SEARCH_ENDPOINT

WEB_SEARCH_TOOL: Dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "web_search",
        "description": "联网搜索实时信息（新闻、天气、比分、汇率等你不可能知道的当下事实）",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "搜索关键词"},
            },
            "required": ["query"],
        },
    },
}


def available_tools() -> List[Dict[str, Any]]:
    """当前允许 ① 使用的工具清单。没开开关就一把都没有。"""
    return [WEB_SEARCH_TOOL] if WEB_SEARCH_ENABLED else []


def handle_tool_call(name: str, arguments: Dict[str, Any]) -> str:
    """工具分发入口：按名字执行，把结果洗成不超过 2000 字的纯文本。"""
    if name == "web_search":
        return web_search(str((arguments or {}).get("query") or ""))
    return f"未知工具：{name}"


def web_search(query: str) -> str:
    query = query.strip()
    if not query:
        return "（搜索词为空）"
    if not WEB_SEARCH_ENDPOINT:
        return "（联网搜索当前不可用：服务端没有配置搜索端点）"
    url = f"{WEB_SEARCH_ENDPOINT}?{urllib.parse.urlencode({'q': query, 'format': 'json'})}"
    try:
        request = urllib.request.Request(url, headers={"Accept": "application/json"})
        with urllib.request.urlopen(request, timeout=15) as response:
            data = json.loads(response.read().decode("utf-8"))
    except Exception as exc:  # noqa: BLE001
        return f"（搜索失败：{exc}）"
    # SearXNG 风格：results[*] = {title, content, url}
    results = data.get("results") or []
    if not results:
        return "（没有搜到相关结果）"
    lines = []
    for item in results[:5]:
        title = str(item.get("title") or "").strip()
        content = str(item.get("content") or "").strip()
        if title or content:
            lines.append(f"- {title}：{content}")
    return "\n".join(lines)[:2000] or "（没有搜到相关结果）"
