"""她的现实世界：时区换算与作息窗口的纯数值判断。

规则边界：
- 这里**不做**任何语义判断，只做"现在几点 vs ⑰ 号给的窗口"的数值比较；
- 窗口本身（几点睡、几点起、今天什么日子）全部来自 ⑰ 号 API 的输出，
  缓存在 state.world_rhythm 里，一天只问一次。
"""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any, Dict, Optional, Tuple

# 睡眠窗口前后各延 40 分钟算"迷糊带"：被吵醒能回，但回的是半梦半醒的话
DROWSY_MARGIN_MINUTES = 40


def character_now(identity: Dict[str, Any]) -> datetime:
    """她所在地的当前时间 = 用户本地时间 + 时区偏移。"""
    try:
        offset = float((identity or {}).get("timezone_offset") or 0.0)
    except (TypeError, ValueError):
        offset = 0.0
    return datetime.now() + timedelta(hours=offset)


def _hhmm(value: Any) -> Optional[int]:
    """"23:30" → 1410（分钟数），非法输入返回 None。"""
    text = str(value or "").strip()
    parts = text.split(":")
    if len(parts) != 2:
        return None
    try:
        hour, minute = int(parts[0]), int(parts[1])
    except ValueError:
        return None
    if not (0 <= hour <= 23 and 0 <= minute <= 59):
        return None
    return hour * 60 + minute


def _in_window(minutes: int, start: int, end: int) -> bool:
    """窗口允许跨零点（23:30→07:00）。"""
    if start <= end:
        return start <= minutes < end
    return minutes >= start or minutes < end


def _window_of(rhythm: Dict[str, Any], key: str) -> Optional[Tuple[int, int]]:
    window = (rhythm or {}).get(key) or {}
    start, end = _hhmm(window.get("start")), _hhmm(window.get("end"))
    if start is None or end is None:
        return None
    return start, end


def can_reply_now(identity: Dict[str, Any], state: Dict[str, Any]) -> bool:
    """此刻她**物理上**能不能回消息。

    没有节律表（⑰ 还没跑过 / 跑失败了）→ 默认能回，绝不因数据缺失把人禁言。
    有表 → 纯数值比较：她的当地时间落在睡眠窗口里就是不能。
    """
    rhythm = (state or {}).get("world_rhythm") or {}
    if not rhythm:
        return True
    window = _window_of(rhythm, "sleep_window")
    if window is None:
        return bool(rhythm.get("can_reply", True))
    now = character_now(identity)
    minutes = now.hour * 60 + now.minute
    if _in_window(minutes, window[0], window[1]):
        return False
    # 忙碌窗口只影响"想不想"，不构成物理拦截 —— 上班摸鱼回消息是人之常情
    return bool(rhythm.get("can_reply", True))


def is_drowsy_now(identity: Dict[str, Any], state: Dict[str, Any]) -> bool:
    """此刻她是不是处于"半梦半醒"（睡眠窗口 ± 40 分钟的迷糊带）。

    迷糊带里发出的消息要带 drowsy 标记：天亮后她自己不记得说过这些。
    """
    rhythm = (state or {}).get("world_rhythm") or {}
    window = _window_of(rhythm, "sleep_window")
    if window is None:
        return False
    start = (window[0] - DROWSY_MARGIN_MINUTES) % (24 * 60)
    end = (window[1] + DROWSY_MARGIN_MINUTES) % (24 * 60)
    now = character_now(identity)
    minutes = now.hour * 60 + now.minute
    return _in_window(minutes, start, end)


def minutes_until_wake(identity: Dict[str, Any], state: Dict[str, Any]) -> Optional[int]:
    """如果她正在睡眠窗口里，返回距起床还有多少分钟（给调度器定下一次巡检用）。"""
    rhythm = (state or {}).get("world_rhythm") or {}
    window = _window_of(rhythm, "sleep_window")
    if window is None:
        return None
    now = character_now(identity)
    minutes = now.hour * 60 + now.minute
    if not _in_window(minutes, window[0], window[1]):
        return None
    return (window[1] - minutes) % (24 * 60)
