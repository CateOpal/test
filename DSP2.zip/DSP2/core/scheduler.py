"""后台生命循环：需求钟摆、定时器、主动发消息、深夜反思、定期遗忘。

这是"让角色活起来"的地方，但它依然不做语义判断：
- 时间到了 → 问 ⑦ 该不该开口 → proactively 的话让 ⑩ 起草 → ⑨ 排版 → 交给 UI 播报
- 深夜到了 → 让 ⑫ 写反思日记 → 把 delta 写进 state
- 每隔 N 天 → 让 ⑬ 整理记忆
- 用户设的定时器到点 → 直接作为"主动开口"的理由

一句话：它是个闹钟，判断权仍然在 17 个 API 手里。
"""

from __future__ import annotations

import asyncio
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from apis import build_apis
from apis.codes import CORE_SET
from backend import context_builder as cb
from backend import state_writer as sw
from backend.round_handler import RoundEngine
from config import (
    CONSCIOUSNESS_EVERY_MINUTES,
    DECAY_INTERVAL_DAYS,
    PROACTIVE_TICK_SECONDS,
    RATE_LIMIT_PER_CHAR_PER_DAY,
    REFLECTION_HOURS,
)
from core import timeutil
from core.account import api_view

MAX_WAIT_SECONDS = 6 * 3600


def wait_cap(state: Dict[str, Any]) -> int:
    """本次巡检之后，最长隔多久再来问一次 ⑦。

    默认就是 MAX_WAIT_SECONDS —— ⑦ 说等一小时就等一小时，完全是它的判断。
    唯一例外是角色自己的 state 里带了 `test_wait_cap_seconds`：
    这是给"验证主动消息"用的**数值闸门**，只压缩等待时长，不改变 ⑦ 的结论。
    所以它仍然不是 `if 该主动 then 发` 那种规则，只是把"再问一次"的频率调高。
    """
    raw = state.get("test_wait_cap_seconds")
    if raw:
        try:
            return max(10, min(MAX_WAIT_SECONDS, int(raw)))
        except (TypeError, ValueError):
            return MAX_WAIT_SECONDS
    return MAX_WAIT_SECONDS


def extraversion_threshold(ocean: Optional[Dict[str, Any]]) -> int:
    """把"外向性"翻译成一个参考等待秒数 —— 只是给 ⑦ 的经验值，不是规则。

    同样的关注需求，外向的人几分钟就想找人说话，内向的人能憋一整天。
    后端不写 `if 外向: 立即发` 这种分支，只把它作为参数递给 ⑦，
    要不要真的开口仍然由那个大脑结合关系状态自己判断。
    """
    ocean = ocean or {}
    try:
        extraversion = float(ocean.get("extraversion", 0.5))
        agreeableness = float(ocean.get("agreeableness", 0.5))
        neuroticism = float(ocean.get("neuroticism", 0.5))
    except (TypeError, ValueError):
        extraversion, agreeableness, neuroticism = 0.5, 0.5, 0.5

    # 外向 + 宜人 → 基准短；神经质高 → 想得多、反而更容易憋着
    base = 5400 - int(extraversion * 3600)      # 外向 0.9 → 约 36 分钟；内向 0.1 → 约 84 分钟
    base -= int(agreeableness * 900)            # 宜人者再砍最多 15 分钟
    base += int(neuroticism * 1800)             # 神经质者最多再加 30 分钟
    return max(600, min(MAX_WAIT_SECONDS, base))


class CharacterLife:
    """一个角色的后台大脑。前台 UI 关闭也不影响逻辑上存在与否，
    但**必须有一个常驻进程**（本项目即 main.py / cli.py）才能触发。
    """

    def __init__(
        self,
        storage,
        llm,
        db,
        on_message: Optional[Callable[[str, List[Dict[str, Any]], Dict[str, Any]], Any]] = None,
        apis: Optional[Dict[str, Any]] = None,
        account: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.storage = storage
        self.llm = llm
        self.db = db
        self.apis = apis or build_apis(llm)
        self.account = account or {}
        self.on_message = on_message
        self.engine = RoundEngine(storage, llm, db, self.apis, account=self.account)
        self._task: Optional[asyncio.Task] = None
        self._next_check: float = 0.0
        self._last_tick_ts: float = time.time()
        self.running = False

    # ---------------------------------------------------------------- 生命周期
    async def start(self) -> None:
        if self._task and not self._task.done():
            return
        self.running = True
        self._last_tick_ts = time.time()
        self._task = asyncio.create_task(self._loop())

    async def stop(self) -> None:
        self.running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):  # noqa: BLE001
                pass

    async def _loop(self) -> None:
        while self.running:
            try:
                await self.tick()
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                print(f"[{self.storage.char_id}] 后台循环异常：{exc}")
            await asyncio.sleep(max(5, PROACTIVE_TICK_SECONDS))

    # ---------------------------------------------------------------- 单次巡检
    async def tick(self) -> None:
        now_ts = time.time()
        elapsed_minutes = (now_ts - self._last_tick_ts) / 60.0
        self._last_tick_ts = now_ts

        state = self.storage.load("state.json")
        sw.grow_needs(state, elapsed_minutes)
        self.storage.save("state.json", state)

        await self._maybe_consciousness(elapsed_minutes)
        await self._maybe_reflection()
        await self._maybe_decay()
        await self._check_timers()

        if now_ts < self._next_check:
            return

        decision = await self._ask_timing()
        if decision.get("action") == "proactive":
            await self._proactive(decision)
            wait = max(PROACTIVE_TICK_SECONDS, self._daily_gap())
        else:
            wait = int(decision.get("wait_seconds") or PROACTIVE_TICK_SECONDS)
        self._next_check = time.time() + min(wait_cap(state), max(10, wait))

    # ---------------------------------------------------------------- ⑦ 时机决策
    async def _ask_timing(self) -> Dict[str, Any]:
        state = self.storage.load("state.json")
        identity = self.storage.load("identity.json")
        counter = self.storage.load("counter.json")
        daily = counter.get("proactive_daily") or {}
        today = timeutil.day_of_year_key()
        today_count = int(daily.get("count", 0)) if daily.get("date") == today else 0
        hooks = self.db.open_events(limit=5)

        ocean = identity.get("personality_ocean") or {}
        first_time = not state.get("last_proactive_time") and int(counter.get("rounds", 0)) == 0

        payload = {
            "personality": {
                "ocean": ocean,
                "attachment_style": identity.get("attachment_style"),
                "speaking_style": identity.get("speaking_style"),
            },
            "needs": state.get("needs"),
            "relationship": state.get("relationship"),
            "state": state.get("emotion"),
            "clock": timeutil.clock_block(),
            "idle_since_last_user_message": timeutil.idle_text(state.get("last_user_message_time")),
            "idle_since_last_proactive": timeutil.idle_text(state.get("last_proactive_time")),
            "is_blocked": bool(state.get("is_blocked")),
            "open_hooks": cb.open_hooks_text(hooks, 5),
            "recent_topics": [m["text"][:20] for m in self.storage.recent_messages(4)],
            "proactive_today": today_count,
            "daily_limit": RATE_LIMIT_PER_CHAR_PER_DAY,
            # 是否从未主动开口 —— 外向的人在破冰这件事上应该有天然优势
            "is_first_proactive": first_time,
            # 参考等待秒数：外向者短、内向者长，⑦ 可以参考也可以推翻
            "extraversion_threshold": extraversion_threshold(ocean),
        }
        return await asyncio.to_thread(self.apis["⑦"].run, payload)

    def _daily_gap(self) -> int:
        counter = self.storage.load("counter.json")
        daily = counter.get("proactive_daily") or {}
        today = timeutil.day_of_year_key()
        today_count = int(daily.get("count", 0)) if daily.get("date") == today else 0
        if today_count >= RATE_LIMIT_PER_CHAR_PER_DAY:
            return MAX_WAIT_SECONDS
        # 主动越频繁，下一次等待越长，避免连珠炮
        return int(PROACTIVE_TICK_SECONDS * (today_count + 1))

    # ---------------------------------------------------------------- 主动发消息
    async def _proactive(self, decision: Dict[str, Any], trigger_reason: str = "需求池上涨") -> None:
        state = self.storage.load("state.json")
        if state.get("is_blocked"):
            return
        intensity = decision.get("proactive_intensity") or {}
        max_messages = int(intensity.get("max_messages") or 1)
        tone_restraint = intensity.get("tone_restraint", 0.5)

        identity = self.storage.load("identity.json")
        profile = self.storage.load("profile.json")
        recent = self.storage.recent_messages(8)
        payload = {
            "trigger_reason": trigger_reason,
            "topic_hint": intensity.get("topic_hint", ""),
            "tone_restraint": tone_restraint,
            # 主动开口最容易叫错名字/复读，所以同样带上身份锚点
            "identity_anchor": cb.identity_anchor_block(identity, profile, self.account),
            "persona": cb.persona_block(identity),
            "state": cb.state_block(state),
            "relationship": cb.relationship_block(state, profile),
            "clock": timeutil.clock_block(),
            "recent_topics": [m["text"][:20] for m in recent],
            "open_hooks": cb.open_hooks_text(self.db.open_events(limit=4), 4),
        }
        draft_pack = await asyncio.to_thread(self.apis["⑩"].run, payload)
        draft = str(draft_pack.get("draft_text") or "").strip()
        if not draft:
            return

        strategy = await asyncio.to_thread(
            self.apis["⑨"].run,
            {
                "draft": draft,
                "max_messages": max_messages,
                "tone_restraint": tone_restraint,
                "scene_intent": "light",
                "emotion": (state.get("emotion") or {}).get("label", "平静"),
            },
            draft,
        )
        messages = strategy.get("messages") or [{"text": draft, "delay_ms": 800}]
        meta = {
            "codes": ["⑦", "⑩", "⑨"],
            "trigger_reason": trigger_reason,
            "intensity": intensity,
        }

        # 落库
        counter = self.storage.load("counter.json")
        daily = counter.get("proactive_daily") or {}
        today = timeutil.day_of_year_key()
        if daily.get("date") != today:
            daily = {"date": today, "count": 0}
        daily["count"] = int(daily.get("count", 0)) + 1
        counter["proactive_daily"] = daily
        self.storage.save("counter.json", counter)

        state = self.storage.load("state.json")
        state["last_proactive_time"] = timeutil.now_str()
        needs = state.setdefault("needs", {})
        needs["attention"] = max(0.0, float(needs.get("attention", 0.3)) - 0.4)
        self.storage.save("state.json", state)

        text = draft
        self.storage.append_buffer("assistant", text, int(state.get("rounds", 0)))
        self.db.add_message("assistant", text, int(state.get("rounds", 0)), extra="proactive")
        meta_meta = self.storage.load("meta.json")
        meta_meta["last_message_preview"] = text[:30]
        meta_meta["last_message_time"] = timeutil.now_str()
        self.storage.save("meta.json", meta_meta)

        if self.on_message:
            await self.on_message(self.storage.char_id, messages, meta)

    # ---------------------------------------------------------------- 定时器
    async def _check_timers(self) -> None:
        state = self.storage.load("state.json")
        timers = list(state.get("unresolved_timers") or [])
        if not timers:
            return
        due: List[Dict[str, Any]] = []
        remain: List[Dict[str, Any]] = []
        now_dt = datetime.now()
        for timer in timers:
            created = timeutil.parse(timer.get("created_at"))
            minutes = float(timer.get("delay_minutes") or 0)
            if created and (now_dt - created).total_seconds() / 60.0 >= minutes:
                due.append(timer)
            else:
                remain.append(timer)
        if not due:
            return
        # 一次巡检只处理最早到期的那一条（避免连环轰炸），其余到期的继续留在队列里
        due.sort(key=lambda t: (timeutil.parse(t.get("created_at")) or datetime.now()))
        timer = due[0]
        remain = due[1:] + remain
        state["unresolved_timers"] = remain
        self.storage.save("state.json", state)
        decision = {
            "action": "proactive",
            "wait_seconds": 0,
            "proactive_intensity": {
                "max_messages": 1,
                "tone_restraint": 0.4,
                "topic_hint": str(timer.get("content") or ""),
                "reason": "用户之前设的提醒到期了",
            },
        }
        await self._proactive(decision, trigger_reason=f"定时器到期：{timer.get('content')}")

    # ---------------------------------------------------------------- ⑮ 意识流
    async def _maybe_consciousness(self, elapsed_minutes: float) -> None:
        state = self.storage.load("state.json")
        idle = timeutil.minutes_since(state.get("last_user_message_time"))
        if idle is None or idle < 3:
            return
        # ⑮ 是"一个人独处时的走神"，不是心跳包。
        # 原先只要空闲超过 3 分钟，每次巡检（默认 60 秒）都会调一次，
        # 五个空闲角色一小时就是 300 次请求 —— 又贵又拖慢 ⑦ 的判断。
        counter = self.storage.load("counter.json")
        gap = timeutil.minutes_since(counter.get("last_consciousness_at"))
        if gap is not None and gap < CONSCIOUSNESS_EVERY_MINUTES:
            return
        identity = self.storage.load("identity.json")
        payload = {
            "identity": cb.persona_block(identity),
            "state": cb.state_block(state),
            "recent_dialogue": self.storage.recent_messages(6),
            "open_hooks": cb.open_hooks_text(self.db.open_events(limit=4), 4),
            "idle_since_last_message": timeutil.idle_text(state.get("last_user_message_time")),
            "clock": timeutil.clock_block(),
        }
        result = await asyncio.to_thread(self.apis["⑮"].run, payload)
        await self.storage.update("state.json", lambda s: sw.apply_consciousness(s, result) or s)
        counter["last_consciousness_at"] = timeutil.now_str()
        self.storage.save("counter.json", counter)

    # ---------------------------------------------------------------- ⑫ 反思
    async def _maybe_reflection(self) -> None:
        now = datetime.now()
        state = self.storage.load("state.json")
        counter = self.storage.load("counter.json")
        today = timeutil.day_of_year_key()
        if now.hour not in REFLECTION_HOURS:
            return
        if counter.get("last_reflection_date") == today:
            return

        identity = self.storage.load("identity.json")
        hooks = self.db.open_events(limit=6)
        payload = {
            "identity": cb.persona_block(identity),
            "state": cb.state_block(state),
            "recent_dialogue": self.storage.recent_messages(12),
            "open_hooks": cb.open_hooks_text(hooks, 5),
            "today_summary": cb.scene_snapshot(state, [m["text"][:20] for m in self.storage.recent_messages(4)]),
            "clock": timeutil.clock_block(),
        }
        result = await asyncio.to_thread(self.apis["⑫"].run, payload)

        diary = str(result.get("diary_md") or "").strip()
        if diary:
            path: Path = self.storage.reflections_dir / f"{today}.md"
            content = ""
            if path.exists():
                content = path.read_text(encoding="utf-8")
            with path.open("w", encoding="utf-8") as file:
                file.write(content + f"\n\n## {timeutil.human()}\n\n{diary}\n")
        await self.storage.update("state.json", lambda s: sw.apply_reflection(s, result) or s)
        counter["last_reflection_date"] = today
        self.storage.save("counter.json", counter)

    # ---------------------------------------------------------------- ⑬ 遗忘
    async def _maybe_decay(self) -> None:
        counter = self.storage.load("counter.json")
        today = datetime.now()
        last = counter.get("last_decay_date")
        if last:
            try:
                days = (today - datetime.strptime(last, "%Y-%m-%d")).days
            except ValueError:
                days = DECAY_INTERVAL_DAYS
            if days < DECAY_INTERVAL_DAYS:
                return
        events = self.db.open_events(limit=40)
        if not events:
            counter["last_decay_date"] = timeutil.day_of_year_key()
            self.storage.save("counter.json", counter)
            return
        payload = {
            "events": [
                {
                    "id": e.get("id"),
                    "timestamp": e.get("timestamp"),
                    "event": e.get("event"),
                    "unresolved": e.get("unresolved"),
                    "arousal": e.get("arousal"),
                    "emotion_tag": e.get("emotion_tag"),
                }
                for e in events
            ],
            "decay_days": DECAY_INTERVAL_DAYS,
            "today": timeutil.day_of_year_key(),
        }
        result = await asyncio.to_thread(self.apis["⑬"].run, payload)
        archive = result.get("archive_ids") or []
        if archive:
            self.db.archive_events([int(i) for i in archive])
        counter["last_decay_date"] = timeutil.day_of_year_key()
        self.storage.save("counter.json", counter)


class LifeManager:
    """管理所有角色的后台循环（一个用户 / 多个角色互不相识）。"""

    def __init__(self, registry, llm, on_message) -> None:
        self.registry = registry
        self.llm = llm
        self.on_message = on_message
        self.lives: Dict[str, CharacterLife] = {}
        self._account: Optional[Dict[str, Any]] = None

    def set_account(self, account: Dict[str, Any]) -> None:
        """登录/改名后刷新：新建的角色和已存在角色的身份锚点都跟着变。

        入参是完整档案，但存进来的**只有 api_view 过滤后的那几个字段** ——
        性别和生日在这一步就被丢掉了，后面不管谁把 self._account 拼进 Prompt，
        都不可能泄露。把隐私约束放在数据源头，比在使用处反复叮嘱可靠。
        """
        self._account = api_view(account)
        for life in self.lives.values():
            life.account = self._account
            life.engine.account = self._account

    def _current_account(self) -> Dict[str, Any]:
        if self._account is None:
            try:
                from core.account import load_account

                base = self.registry.root.parent.parent.parent  # data/
                self._account = api_view(load_account(base))
            except Exception:  # noqa: BLE001
                self._account = {}
        return self._account

    def get(self, char_id: str) -> CharacterLife:
        if char_id not in self.lives:
            storage = self.registry.get(char_id)
            storage.refresh_age()
            db = self._db(storage)
            self.lives[char_id] = CharacterLife(
                storage, self.llm, db, self.on_message, account=self._current_account()
            )
        elif self._account:
            self.lives[char_id].account = self._account
            self.lives[char_id].engine.account = self._account
        return self.lives[char_id]

    @staticmethod
    def _db(storage):
        from core.database import CharacterDB

        return CharacterDB(storage.db_path)

    async def start_all(self) -> None:
        for char_id in self.registry.char_ids():
            await self.get(char_id).start()

    async def stop_all(self) -> None:
        for life in self.lives.values():
            await life.stop()
        self.lives.clear()
