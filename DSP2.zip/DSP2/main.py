"""DSP2 —— 拟真数字生命系统。

用法：
    python main.py               打开桌面界面（Flet）
    python main.py ui            同上
    python main.py cli ...       命令行模式
    python main.py smoke         离线自检（不消耗 token）
"""

from __future__ import annotations

import sys


def main() -> None:
    argv = sys.argv[1:]
    mode = argv[0] if argv else "ui"

    if mode in ("ui", "gui", "app"):
        from config import require_api_key

        require_api_key()
        from ui.app import run

        run()
    elif mode in ("cli", "cmd", "chat"):
        sys.argv = [sys.argv[0]] + argv[1:]
        from cli import main as cli_main

        cli_main()
    elif mode == "smoke":
        from smoke import main as smoke_main

        smoke_main()
    else:
        print(__doc__)
        sys.exit(1)


if __name__ == "__main__":
    main()
