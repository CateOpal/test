"""单角色主动消息探针：把"她为什么开口 / 为什么不开口"直接打印出来。

平时验证主动消息要等后台巡检，⑦ 号还可能一句"再等 1800 秒"就把你打回等待。
这个脚本绕过等待，直接：

    1. 打印她此刻的状态（需求、关系、多久没收到你的消息）
    2. 按后台完全相同的 payload 问一次 ⑦ 号时机决策
    3. 原样打印它的裁决：action / wait_seconds / 理由 / 这次打算发几条
    4. 加 --send 就继续走 ⑩ 起草 → ⑨ 排版 → 落库，并回显真正发出的气泡

用法：
    python tools/proactive_probe.py                # 自动挑测试角色，只问不发送
    python tools/proactive_probe.py char_E         # 指定角色
    python tools/proactive_probe.py char_E --send  # 真的发一条，验证 ⑩⑨ 和落库
"""

from __future__ import annotations

import argparse
import asyncio
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

BASE_DIR = Path(__file__).resolve().parents[1]
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from config import require_api_key  # noqa: E402
from core import timeutil  # noqa: E402
from core.database import CharacterDB  # noqa: E402
from service import DSPService  # noqa: E402


def _pick_char(service: DSPService, wanted: str) -> Optional[str]:
    ids = service.char_ids()
    if wanted:
        if wanted in ids:
            return wanted
        # 也允许直接写名字
        for char_id in ids:
            if service.name_of(char_id) == wanted:
                return char_id
        print(f"找不到角色：{wanted}")
        return None
    for char_id in ids:
        try:
            identity = service.registry.get(char_id).load("identity.json")
        except Exception:  # noqa: BLE001
            continue
        if identity.get("is_test_character"):
            return char_id
    if len(ids) == 1:
        return ids[0]
    print("已有角色（请把 id 或名字作为参数传进来）：")
    for char_id in ids:
        print(f"  {char_id}\t{service.name_of(char_id)}")
    return None


def _print_state(char_id: str, name: str, identity: Dict[str, Any], state: Dict[str, Any]) -> None:
    ocean = identity.get("personality_ocean") or {}
    rel = state.get("relationship") or {}
    needs = state.get("needs") or {}
    emotion = state.get("emotion") or {}
    counter = state.get("_counter") or {}
    print(f"角色　{name}（{char_id}）")
    print(
        f"性格　外向 {ocean.get('extraversion', 0):.2f}　宜人 {ocean.get('agreeableness', 0):.2f}"
        f"　神经质 {ocean.get('neuroticism', 0):.2f}　依恋 {identity.get('attachment_style') or '未说明'}"
    )
    print(f"情绪　{emotion.get('label') or '平静'}　能量 {float(emotion.get('energy') or 0):.2f}"
          f"　是否伪装 {'是' if emotion.get('is_masking') else '否'}")
    print(f"需求　渴望关注 {float(needs.get('attention') or 0):.2f}　渴望认可 {float(needs.get('validation') or 0):.2f}")
    print(f"关系　好感 {float(rel.get('affection') or 0):.2f}　信任 {float(rel.get('trust') or 0):.2f}"
          f"　边界感 {float(rel.get('boundary') or 0):.2f}")
    print(f"时间　距你上一条消息 {timeutil.idle_text(state.get('last_user_message_time'))}"
          f"　距她上次主动 {timeutil.idle_text(state.get('last_proactive_time'))}")
    print(f"     今天已主动 {int(counter.get('count') or 0)} 次"
          f"　是否首次开口 {'是' if not state.get('last_proactive_time') and not counter.get('rounds') else '否'}")
    if state.get("test_wait_cap_seconds"):
        print(f"闸门　测试模式：最长等待压到 {state['test_wait_cap_seconds']} 秒（只对本角色生效）")


def _print_decision(decision: Dict[str, Any], elapsed: float) -> None:
    action = decision.get("action") or "wait"
    wait = int(decision.get("wait_seconds") or 0)
    intensity = decision.get("proactive_intensity") or {}
    print("")
    print(f"—— ⑦ 号时机决策（耗时 {elapsed:.1f}s）——")
    print(f"action　　　{action}")
    print(f"wait_seconds {wait}（约 {wait / 60:.0f} 分钟）")
    print(f"理由　　　　{decision.get('reason') or '（未给）'}")
    print(f"力度　　　　最多 {intensity.get('max_messages') or 1} 条"
          f"　克制度 {float(intensity.get('tone_restraint') or 0):.2f}"
          f"（0=黏人，1=卑微）")
    if intensity.get("topic_hint"):
        print(f"切入点　　　{intensity.get('topic_hint')}")
    if intensity.get("reason"):
        print(f"力度理由　　{intensity.get('reason')}")
    print("")
    if action == "proactive":
        print("✅ 她的结论是现在开口 —— 后台巡检走到这一步就会真的发出来。")
    else:
        print(f"⏸ 她的结论是先不开口，{wait} 秒后再看。这是正常判断，不是故障。")
        print("   想验证发送链路本身，加 --send 强制发一条，或看她有没有 test_wait_cap_seconds。")


def _print_new_messages(char_id: str, service: DSPService, before: int) -> None:
    storage = service.registry.get(char_id)
    rows = CharacterDB(storage.db_path).list_messages(limit=500)
    fresh = rows[before:]
    print("")
    print(f"—— 数据库新增 {len(fresh)} 行（分条落库，一条气泡一行）——")
    for row in fresh:
        role = "她" if row.get("role") != "user" else "你"
        print(f"  [{row.get('id')}] {role}：{row.get('text')}")


async def run(wanted: str, force_send: bool) -> int:
    require_api_key()
    service = DSPService()
    char_id = _pick_char(service, wanted)
    if not char_id:
        return 1

    name = service.name_of(char_id)
    life = service.lives.get(char_id)
    identity = life.storage.load("identity.json")
    state = life.storage.load("state.json")
    counter_raw = life.storage.load("counter.json")
    daily = counter_raw.get("proactive_daily") or {}
    today = timeutil.day_of_year_key()
    state["_counter"] = {
        "count": int(daily.get("count") or 0) if daily.get("date") == today else 0,
        "rounds": int(counter_raw.get("rounds") or 0),
    }
    _print_state(char_id, name, identity, state)

    started = time.time()
    decision = await life._ask_timing()  # noqa: SLF001  和后台上报的 payload 完全一致
    _print_decision(decision, time.time() - started)

    if not force_send:
        return 0

    before = len(service.history(char_id, limit=500))
    captured: List[Dict[str, Any]] = []

    def _capture(cid: str, messages: List[Dict[str, Any]], meta: Dict[str, Any]) -> None:
        if cid == char_id:
            captured.extend(messages or [])

    service.subscribe(_capture)
    print("")
    print("—— 强制走一遍 ⑩ 起草 → ⑨ 排版 ——")
    started = time.time()
    await life._proactive(  # noqa: SLF001
        {
            "action": "proactive",
            "proactive_intensity": {
                "max_messages": 1,
                "tone_restraint": 0.35,
                "topic_hint": "",
                "reason": "调试：手动触发一次主动开口",
            },
        },
        trigger_reason="调试：手动触发一次主动开口",
    )
    service.unsubscribe(_capture)
    print(f"耗时 {time.time() - started:.1f}s")

    print("")
    print("—— 实际发出的气泡 ——")
    if not captured:
        print("  （一条都没有。可能是 ⑩ 返回空草稿，或 ⑨ 判定为撤回）")
    for item in captured:
        if not isinstance(item, dict):
            print(f"  {item}")
            continue
        action = item.get("action") or "text"
        if action == "recall":
            print("  〔撤回上一条〕")
        else:
            print(f"  [{int(item.get('delay_ms') or 0)}ms] {item.get('text') or ''}")

    _print_new_messages(char_id, service, before)
    return 0


def main() -> None:
    parser = argparse.ArgumentParser(description="主动消息探针：看 ⑦ 怎么判、看消息怎么发")
    parser.add_argument("char", nargs="?", default="", help="角色 id 或名字，留空则自动找测试角色")
    parser.add_argument("--send", action="store_true", help="不管 ⑦ 怎么判，强制走完 ⑩→⑨ 并落库")
    args = parser.parse_args()
    try:
        code = asyncio.run(run(args.char.strip(), args.send))
    except KeyboardInterrupt:
        code = 130
    sys.exit(code)


if __name__ == "__main__":
    main()
