"""生成一个"专门用来验证主动发消息"的测试角色。

为什么需要这个脚本
------------------
真实角色的主动开口是个概率事件：⑦ 号时机决策要考虑性格、关系、需求、时间、
有没有未闭环的钩子，绝大多数轮次它都会说"再等等"。等一个默认值 0.5 外向、
关系还是"陌生人"的角色主动开口，本来就要按小时计 —— 手动测试非常熬人。

这里预置的是一个**极端样本**：外向到 0.96、宜人到 0.88、关注需求 0.88、
关系已经是"每天都要聊几句的朋友"、还留着两条没闭环的小事。
不是作弊，是把"该开口"的所有前置条件都摆到位，剩下的判断仍然交给 ⑦ 号。

用法：
    python tools/seed_proactive_test.py                 # 新建（若已存在会提示）
    python tools/seed_proactive_test.py --reset         # 把她重置回"正想找人说话"
    python tools/seed_proactive_test.py --name 糖糖      # 自定义名字

脚本不调用任何 API，不花一分钱，写完七个 JSON + 一个空库就结束。
"""

from __future__ import annotations

import argparse
import shutil
import sys
from datetime import datetime, timedelta
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[1]
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from config import DATA_DIR, USER_ID  # noqa: E402
from core import defaults, timeutil  # noqa: E402
from core.account import load_account  # noqa: E402
from core.database import CharacterDB  # noqa: E402
from core.storage import CharacterRegistry, CharacterStorage  # noqa: E402

DEFAULT_NAME = "糖糖"

# 热情型人设：不是"讨好"，是那种见谁都愿意先开口、憋不住话的性格。
# 高外向 + 高宜人 + 低神经质 —— 想说话就直接说，不会反复纠结"他会不会嫌我烦"。
WARM_TEMPLATE = {
    "self_reference": "我",
    "occupation": "奶茶店店员",
    "expertise": ["调饮", "拍路边的小猫"],
    "personality_ocean": {
        "openness": 0.78,
        "conscientiousness": 0.46,
        "extraversion": 0.96,
        "agreeableness": 0.88,
        "neuroticism": 0.30,
    },
    "attachment_style": "secure",
    "speaking_style": (
        "语速快、句子短，习惯一次连发两三条；爱用感叹号和「呀」「啦」「嘿嘿」这类语气词，"
        "想到什么立刻发过来，很少铺垫"
    ),
    "culture_profile": {
        "origin": "中国南方城市，家里开小饭馆，从小在店里帮忙，跟谁都能聊上两句",
        "knowledge_domains": ["奶茶和小吃的做法", "附近哪家店好吃", "短视频热梗", "怎么哄人开心"],
        "interests": ["City walk", "拍路边的小猫", "手工饰品"],
        "blind_spots": ["职场政治与汇报话术", "金融产品和合同条款", "需要长时间钻研的理论"],
    },
}

# 预置的未闭环小事：给 ⑦ 一个开口的由头，也给 ⑩ 一个具体的切入点。
SEED_EVENTS = [
    {
        "event": "今天在店里试做了新的芋泥波波，她自己觉得特别好喝",
        "unresolved": "说好要拍照给他看，结果忙着忙着忘了拍",
        "arousal": "high",
        "emotion_tag": "兴奋",
        "event_type": "self",
    },
    {
        "event": "他提过最近总加班到很晚",
        "unresolved": "一直想问他今天有没有早点下班",
        "arousal": "normal",
        "emotion_tag": "惦记",
        "event_type": "chat",
    },
]


def _now_minus(minutes: int) -> str:
    return (datetime.now() - timedelta(minutes=minutes)).strftime("%Y-%m-%d %H:%M:%S")


def build_files(char_id: str, display_name: str, user_name: str) -> dict:
    files = defaults.build_defaults(
        USER_ID,
        char_id,
        display_name,
        gender="女",
        age=22,
        birthday="",
        base_persona="热情、自来熟、话多，情绪写在脸上",
        occupation=WARM_TEMPLATE["occupation"],
        expertise=list(WARM_TEMPLATE["expertise"]),
        template=dict(WARM_TEMPLATE),
        user_display_name=user_name,
        nationality="中国",
    )

    identity = files["identity.json"]
    identity.update(
        {
            "char_display_name": display_name,
            "occupation": WARM_TEMPLATE["occupation"],
            "expertise": list(WARM_TEMPLATE["expertise"]),
            "current_age": 22,
            "age_at_creation": 22,
            "nationality": "中国",
            "avatar_note": "笑起来眼睛弯的女生，扎着马尾",
            "avatar_impression": "看起来很好说话，站在人群里会先跟人打招呼的那种",
            # 只有带这个标记的角色，抽屉里才会出现"立即主动一条"的调试入口
            "is_test_character": True,
            "test_note": "主动消息验证专用；随时可以删，不影响其他角色",
        }
    )

    state = files["state.json"]
    state["emotion"].update(
        {
            "label": "兴奋",
            "energy": 0.84,
            "physical_state": "刚下晚班，还有点亢奋",
            "patience_threshold": 0.50,
            "is_masking": False,
        }
    )
    # 关注需求拉高：她此刻正想找人说话。这个值平时会随时间自己涨，这里直接给到位。
    state["needs"] = {"attention": 0.88, "validation": 0.74}
    state["relationship"].update(
        {
            "social_roles": [{"role": "每天都聊几句的朋友", "weight": 1.0, "is_active": True}],
            "affection": 0.76,
            "alignment": 0.74,
            "trust": 0.78,
            "dependency": 0.42,
            "dominance": 0.44,
            # 边界感低 = 开得起玩笑、不怕打扰对方
            "boundary": 0.30,
            "conflict_state": "正常",
        }
    )
    state["evolved_traits"] = {
        "catchphrases": ["嘿嘿", "真的假的"],
        "tone": "",
        "knowledge_updates": [],
    }
    state["life_events"] = ["最近在练拉花，失败了十几次"]
    # 18 分钟没说话：足够让 ⑦ 看到"他有一会儿没理我了"，
    # 又不会久到触发"被冷落"的反向抑制。
    state["last_user_message_time"] = _now_minus(18)
    state["last_proactive_time"] = None
    state["rounds"] = 0
    # ── 测试闸门（只对这个角色生效，见 core/scheduler.py 的数值钳制）──
    # ⑦ 就算说"等 1 小时"，后台最多 90 秒就会再问它一次。
    state["test_wait_cap_seconds"] = 90

    files["counter.json"] = {
        "rounds": 0,
        "last_slow_analyze": 0,
        "last_reflection_date": None,
        "last_decay_date": timeutil.day_of_year_key(),
        # 今天主动 0 次：⑦ 不受每日上限压制
        "proactive_daily": {"date": timeutil.day_of_year_key(), "count": 0},
    }
    files["candidates.json"] = {
        "catchphrases": {"嘿嘿": 1, "真的假的": 1, "冲！": 1},
        "tone_shifts": {},
    }
    files["meta.json"]["bio"] = "测试用角色：热情型，用来验证主动发消息"
    return files


def _find_existing(registry: CharacterRegistry, display_name: str) -> str:
    for char_id in registry.char_ids():
        try:
            meta = registry.get(char_id).load("meta.json")
        except Exception:  # noqa: BLE001
            continue
        if str(meta.get("display_name") or "").strip() == display_name:
            return char_id
    return ""


def _is_test_character(registry: CharacterRegistry, char_id: str) -> bool:
    try:
        return bool(registry.get(char_id).load("identity.json").get("is_test_character"))
    except Exception:  # noqa: BLE001
        return False


def seed(display_name: str, reset: bool) -> int:
    registry = CharacterRegistry(DATA_DIR, USER_ID)
    account = load_account(DATA_DIR) or {}
    user_name = str(account.get("display_name") or "").strip() or "你"

    existing = _find_existing(registry, display_name)
    if existing and not reset:
        print(f"已经有一个叫「{display_name}」的角色（{existing}）。")
        print("想把她重置回「正想找人说话」的初始状态，请加 --reset")
        return 0

    char_id = existing
    if existing:
        if not _is_test_character(registry, existing):
            print(f"拒绝重置：{existing} 不是测试角色，避免误删你真正的对话记录。")
            return 1
        root = Path(DATA_DIR) / "users" / USER_ID / "characters" / existing
        shutil.rmtree(root, ignore_errors=True)
        # 缓存里还留着旧句柄，重建时必须让 registry 重新扫描
        registry._instances.pop(existing, None)  # noqa: SLF001
    else:
        char_id = registry.next_char_id()

    files = build_files(char_id, display_name, user_name)
    storage = CharacterStorage(DATA_DIR, USER_ID, char_id)
    storage.init_defaults(files)

    db = CharacterDB(storage.db_path)
    for event in SEED_EVENTS:
        db.add_event(event)

    ocean = files["identity.json"]["personality_ocean"]
    print("")
    print(f"✅ 测试角色已就绪：{display_name}（{char_id}）")
    print(f"   人设：外向性 {ocean['extraversion']:.2f} / 宜人性 {ocean['agreeableness']:.2f}"
          "　—— 见谁都想先开口")
    print(f"   状态：渴望关注 {files['state.json']['needs']['attention']:.2f}"
          f"　距你上一条消息 18 分钟　今天主动 0 次")
    print(f"   钩子：{len(SEED_EVENTS)} 件没闭环的小事（够 ⑩ 号顺着说下去）")
    print(f"   闸门：⑦ 号即使判「再等一小时」，后台最多 {files['state.json']['test_wait_cap_seconds']} 秒后重问")
    print("")
    print("三种验证方式，任选：")
    print(f"   1) 打开界面选中「{display_name}」，什么都不用做，通常 1 分钟内她会先开口；")
    print(f"   2) 点头部菜单 → 抽屉最下方「调试：让她现在开口」，立刻走完 ⑩→⑨；")
    print(f"   3) 终端执行：python tools/proactive_probe.py {char_id}   （只问 ⑦，看它怎么判）")
    print(f"     想直接看一条真的：python tools/proactive_probe.py {char_id} --send")
    print("")
    return 0


def main() -> None:
    parser = argparse.ArgumentParser(description="生成/重置用于验证主动发消息的测试角色")
    parser.add_argument("--name", default=DEFAULT_NAME, help=f"角色名（默认 {DEFAULT_NAME}）")
    parser.add_argument("--reset", action="store_true", help="把已存在的测试角色重置回初始状态")
    args = parser.parse_args()
    sys.exit(seed(args.name.strip() or DEFAULT_NAME, args.reset))


if __name__ == "__main__":
    main()
