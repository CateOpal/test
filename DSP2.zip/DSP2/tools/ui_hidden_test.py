"""隐藏模式 UI 真实路径测试：不弹窗、不烧 token。

README 教训原文：「UI 事件路径要用真实点击方式测。直接调
asyncio.run(app._on_login(...)) 会绕过 bug 本身」——
所以这里起一个 FLET_APP_HIDDEN 的真页面，找到真控件，调它的真 on_click。

覆盖的回归点：
1. 头部 Menu 图标按钮 → _open_drawer → drawer.open → page.show_end_drawer
   （用户报告"点了什么都没有"）
2. 设置图标 → SettingsDialog.open()（曾经的 AttributeError）
3. 账号 / 新建角色弹窗 open()
4. FilePicker.pick_files 协程必须被调度，不许出现
   RuntimeWarning: coroutine ... was never awaited

用法：
    python tools/ui_hidden_test.py
"""

from __future__ import annotations

import asyncio
import os
import shutil
import sys
import tempfile
import warnings
from pathlib import Path
from typing import Any, List

BASE_DIR = Path(__file__).resolve().parents[1]
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

TEST_DIR = Path(tempfile.gettempdir()) / "dsp2_ui_hidden"

# ---------------------------------------------------------------- 警告收集
# "coroutine was never awaited" 是 GC 时通过 warnings 抛出来的，
# 不拦下来它就只躺在控制台里，测试看起来"通过了"其实按钮是死的。
SEEN_WARNINGS: List[str] = []
_orig_showwarning = warnings.showwarning


def _record_warning(message, category, filename, lineno, file=None, line=None) -> None:
    SEEN_WARNINGS.append(f"{category.__name__}: {message}")
    _orig_showwarning(message, category, filename, lineno, file, line)


warnings.showwarning = _record_warning
warnings.simplefilter("always")

RESULTS: List[bool] = []


def _ok(label: str, passed: bool, detail: str = "") -> bool:
    mark = "✓" if passed else "✗"
    print(f"  {mark} {label}{(' —— ' + detail) if detail else ''}", flush=True)
    RESULTS.append(bool(passed))
    return bool(passed)


def _walk(control, out: list, pred) -> None:
    """深度遍历控件树，把满足 pred 的控件收进 out。"""
    try:
        if pred(control):
            out.append(control)
    except Exception:  # noqa: BLE001
        pass
    for child in (getattr(control, "controls", None) or []):
        _walk(child, out, pred)
    sub = getattr(control, "content", None)
    if sub is not None and sub is not control:
        _walk(sub, out, pred)


async def _main(page) -> None:
    import flet as ft

    from service import CharacterForm, DSPService
    from smoke import StubLLM
    from ui.app import DSPApp
    from ui.widgets import pick_files

    # ---- 环境：离线桩 + 临时数据目录 ----
    if TEST_DIR.exists():
        shutil.rmtree(TEST_DIR, ignore_errors=True)
    TEST_DIR.mkdir(parents=True, exist_ok=True)

    stub = StubLLM()
    service = DSPService(api_key="stub", data_dir=TEST_DIR)
    service.llm = stub
    service.create_account("猫眼石", gender="女", birthday="2000-05-12")

    # ---- 在真页面上装间谍：记录 show_dialog / show_end_drawer 是否真的被调到 ----
    shown_dialogs: List[Any] = []
    shown_drawers: List[Any] = []
    orig_show_dialog = page.show_dialog
    orig_show_end_drawer = page.show_end_drawer

    def spy_show_dialog(dialog):
        orig_show_dialog(dialog)
        shown_dialogs.append(dialog)

    async def spy_show_end_drawer():
        # Flet 1.0 里这是无参协程；await 完才记录，抛错就算没打开
        await orig_show_end_drawer()
        shown_drawers.append(page.end_drawer)

    page.show_dialog = spy_show_dialog
    page.show_end_drawer = spy_show_end_drawer

    app = DSPApp(page, service)
    await app.mount()
    _ok("已有档案时直接进主界面", app.body.content is app.root)

    char_id = service.create_character(
        CharacterForm(display_name="隐藏测试员", gender="女", age=23, base_persona="嘴硬心软")
    )
    app.refresh_list()
    app._select(char_id)  # noqa: SLF001  模拟左侧列表点击后的选中
    await asyncio.sleep(0.2)
    _ok("选中角色后右侧是聊天面板", app.right_area.content is app.chat.view)

    # ---- 用例 1：头部 Menu 按钮 → 抽屉真的被 show_end_drawer ----
    buttons: list = []
    _walk(
        app.chat.view,
        buttons,
        lambda c: isinstance(c, ft.IconButton) and getattr(c, "icon", None) == ft.Icons.MENU_ROUNDED,
    )
    if not _ok("聊天头部找得到 Menu 图标按钮", len(buttons) == 1, f"{len(buttons)} 个"):
        buttons = []
    if buttons:
        before = len(shown_drawers)
        buttons[0].on_click(None)  # 真实点击路径，不直接调 app._open_drawer
        await asyncio.sleep(0.3)
        _ok(
            "点 Menu 后抽屉真的打开（show_end_drawer 被调用）",
            len(shown_drawers) > before and app.drawer.current == char_id,
            f"show_end_drawer 次数 {len(shown_drawers)}",
        )
        _ok("抽屉里显示的是当前角色", app.drawer.name_input.value == service.name_of(char_id),
            app.drawer.name_input.value or "")

    # ---- 用例 2：设置按钮 → SettingsDialog.open() 不抛 AttributeError ----
    before = len(shown_dialogs)
    try:
        app._open_settings()  # noqa: SLF001  左栏齿轮的真实回调
        await asyncio.sleep(0.2)
        _ok("点设置图标弹出设置面板", len(shown_dialogs) > before,
            f"show_dialog 次数 {len(shown_dialogs)}")
    except AttributeError as exc:
        _ok("点设置图标弹出设置面板", False, str(exc))

    # ---- 用例 3：账号 / 新建角色弹窗 ----
    before = len(shown_dialogs)
    try:
        app._open_account()  # noqa: SLF001
        await asyncio.sleep(0.1)
        _ok("账号弹窗能打开", len(shown_dialogs) > before)
    except Exception as exc:  # noqa: BLE001
        _ok("账号弹窗能打开", False, str(exc))

    before = len(shown_dialogs)
    try:
        app._open_create()  # noqa: SLF001
        await asyncio.sleep(0.1)
        _ok("新建角色弹窗能打开", len(shown_dialogs) > before)
    except Exception as exc:  # noqa: BLE001
        _ok("新建角色弹窗能打开", False, str(exc))

    # ---- 用例 4：FilePicker.pick_files 协程必须被调度 ----
    warnings_before = len(SEEN_WARNINGS)
    pick_files(page, app.chat.picker, allow_multiple=False, dialog_title="测试")
    await asyncio.sleep(1.0)  # 给 GC 一个抛出 never-awaited 警告的机会
    fresh_warnings = SEEN_WARNINGS[warnings_before:]
    leaked = [w for w in fresh_warnings if "never awaited" in w]
    _ok("pick_files 不产生 never-awaited 警告", not leaked, "; ".join(leaked))

    # ---- 收尾 ----
    try:
        await asyncio.wait_for(app.dispose(), timeout=3)
    except Exception:  # noqa: BLE001
        pass

    print("", flush=True)
    print("结果：", "全部通过" if all(RESULTS) else "存在失败项", flush=True)
    sys.stdout.flush()
    sys.stderr.flush()
    # 隐藏模式没有窗口可关，测完直接结束进程
    os._exit(0 if all(RESULTS) else 1)


def main() -> None:
    import flet as ft

    print("隐藏模式 UI 测试（FLET_APP_HIDDEN，真页面真点击）", flush=True)
    ft.run(_main, view=ft.AppView.FLET_APP_HIDDEN)


if __name__ == "__main__":
    main()
