"""弹窗：创建角色 / 设置 / 状态面板。

创建角色的表单字段严格遵守规格：性别 / 角色名 / 年龄 / 生日 / 基础性格 / 职业 / 特长。
其余（大五人格、依恋类型、文化底色、认知盲区）由"人设推导"翻译成数值基线。
"""

from __future__ import annotations

from typing import Any, Callable, Dict, Optional

import flet as ft

from config import (
    BASE_DIR,
    DEEPSEEK_API_KEY,
    ENV_FILE,
    MODEL,
    PROACTIVE_TICK_SECONDS,
)
from core import settings as theme_store
from ui.widgets import avatar, fire, update_safe

FIELD_LABEL = ft.TextStyle(size=12, color="#9e9e9e")


def _field(label: str, control: ft.Control, hint: str = "") -> ft.Column:
    controls = [ft.Text(label, style=FIELD_LABEL), control]
    if hint:
        controls.append(ft.Text(hint, size=10, color="#7a7a7a"))
    return ft.Column(spacing=4, tight=True, controls=controls)


def _text_field(hint: str, **kwargs) -> ft.TextField:
    return ft.TextField(
        hint_text=hint,
        filled=True,
        fill_color="#2a2a2a",
        border_radius=8,
        border_width=1,
        border_color="#3a3a3a",
        focused_border_width=1,
        focused_border_color="#1472d0",
        text_style=ft.TextStyle(size=13, color="white"),
        hint_style=ft.TextStyle(size=13, color="#6d6d6d"),
        content_padding=ft.Padding(left=10, right=10, top=8, bottom=8),
        **kwargs,
    )


class DialogHost:
    """兼容不同 flet 版本的弹窗开关。"""

    @staticmethod
    def show(page: ft.Page, dialog: ft.AlertDialog) -> None:
        try:
            page.show_dialog(dialog)
            return
        except Exception:  # noqa: BLE001
            pass
        dialog.open = True
        try:
            page.update()
        except Exception:  # noqa: BLE001
            pass

    @staticmethod
    def close(page: ft.Page, dialog: ft.AlertDialog) -> None:
        try:
            page.pop_dialog()
            return
        except Exception:  # noqa: BLE001
            pass
        dialog.open = False
        try:
            page.update()
        except Exception:  # noqa: BLE001
            pass


class CreateCharacterDialog:
    def __init__(self, page: ft.Page, service, on_created: Callable[[str], None]) -> None:
        self.page = page
        self.service = service
        self.on_created = on_created

        self.name_input = _text_field("角色名（必填）")
        self.gender_input = ft.Dropdown(
            value="女",
            width=120,
            options=[ft.dropdown.Option("女"), ft.dropdown.Option("男")],
            border_radius=8,
            border_color="#3a3a3a",
            focused_border_color="#1472d0",
            text_style=ft.TextStyle(size=13, color="white"),
        )
        self.age_input = _text_field("24", width=100, keyboard_type=ft.KeyboardType.NUMBER)
        # 提示语只说明"这一栏是什么"，不写任何内容建议 ——
        # 一旦提示里出现"例如：温柔的老师"，用户填出来的角色就都长一个样了。
        self.birthday_input = _text_field("YYYY-MM-DD（可选，用于随时间真实变老）")
        self.occupation_input = _text_field("职业（可留空）")
        self.expertise_input = _text_field("特长爱好，多个用逗号分隔（可留空）")
        self.nationality_input = _text_field("国籍（用于校准文化背景，可留空）")
        self.culture_input = _text_field(
            "文化或圈子边界：她混哪个圈子、熟悉哪些事物（可留空，留空则按国籍推导）",
            multiline=True,
            min_lines=2,
            max_lines=3,
        )
        self.persona_input = _text_field(
            "基础性格（可留空，留空时交由后端随机掷一个倾向）", multiline=True, min_lines=3, max_lines=5
        )
        self.avatar_note_input = _text_field(
            "头像画面的客观描述（作为外观暗示参与人设推导，可留空）"
        )
        self.avatar_path = ""
        self.avatar_label = ft.Text("未选择（可用角色名首字占位）", size=11, color="#7a7a7a")
        self.picker = ft.FilePicker(on_result=self._on_pick)
        self.progress = ft.ProgressRing(width=16, height=16, stroke_width=2, visible=False)
        self.tip = ft.Text("", size=11, color="#ff9c9c")

        content = ft.Container(
            width=520,
            padding=15,
            content=ft.Column(
                tight=True,
                scroll=ft.ScrollMode.AUTO,
                spacing=12,
                controls=[
                    ft.Row(spacing=12, controls=[
                        ft.Column(tight=True, spacing=4, controls=[
                            _field("角色名", self.name_input),
                        ]),
                        ft.Column(tight=True, spacing=4, controls=[
                            _field("年龄", self.age_input),
                            _field("生日", self.birthday_input),
                        ]),
                    ]),
                    _field("职业", self.occupation_input),
                    _field("特长爱好", self.expertise_input),
                    ft.Row(
                        spacing=12,
                        controls=[
                            ft.Container(width=240, content=_field("国籍", self.nationality_input)),
                            ft.Container(width=240, content=_field("性别", self.gender_input)),
                        ],
                    ),
                    _field("文化或圈子边界", self.culture_input),
                    _field("基础性格", self.persona_input),
                    _field("头像描述", self.avatar_note_input),
                    ft.Row(spacing=8, controls=[
                        ft.Text("头像", style=FIELD_LABEL),
                        ft.TextButton("选择图片", on_click=lambda e: self.picker.pick_files(allow_multiple=False)),
                        self.avatar_label,
                    ]),
                    self.tip,
                ],
            ),
        )

        self.create_btn = ft.Button(
            content=ft.Text("创建", color="white"),
            bgcolor="#1472d0",
            on_click=self._create,
        )
        self.dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("创建角色"),
            content=content,
            actions=[
                ft.TextButton("取消", on_click=lambda e: DialogHost.close(page, self.dialog)),
                ft.Row(tight=True, spacing=8, controls=[
                    self.progress,
                    self.create_btn,
                ]),
            ],
            actions_alignment=ft.MainAxisAlignment.END,
        )
        try:
            if self.picker not in page.services:
                page.services.append(self.picker)
        except Exception:  # noqa: BLE001
            try:
                page.overlay.append(self.picker)
            except Exception:  # noqa: BLE001
                pass

    # ---------------------------------------------------------------- 回调
    def open(self) -> None:
        self.tip.value = ""
        self.progress.visible = False
        DialogHost.show(self.page, self.dialog)

    def _on_pick(self, e: ft.FilePickerResultEvent) -> None:
        files = getattr(e, "files", None) or []
        if files:
            self.avatar_path = getattr(files[0], "path", "") or ""
            self.avatar_label.value = self.avatar_path.split("\\")[-1].split("/")[-1]
            self.avatar_label.update()

    async def _create_async(self) -> None:
        from service import CharacterForm

        name = (self.name_input.value or "").strip()
        if not name:
            self.tip.value = "角色名不能为空"
            self.tip.color = "#ff9c9c"
            update_safe(self.tip)
            return
        if self.service.name_taken(name):
            self.tip.value = f"已经有一个叫「{name}」的角色了"
            self.tip.color = "#ff9c9c"
            update_safe(self.tip)
            return

        # UI 先动起来，再干重活
        self.progress.visible = True
        self.tip.value = "正在把人设翻译成数值基线……"
        self.tip.color = "#9e9e9e"
        self._busy = True
        self.create_btn.disabled = True
        update_safe(self.progress)
        update_safe(self.tip)
        update_safe(self.create_btn)

        try:
            age = int(str(self.age_input.value or "").strip() or 24)
        except ValueError:
            age = 24

        form = CharacterForm(
            display_name=name,
            gender=self.gender_input.value or "女",
            age=age,
            birthday=(self.birthday_input.value or "").strip(),
            base_persona=(self.persona_input.value or "").strip(),
            occupation=(self.occupation_input.value or "").strip(),
            expertise=(self.expertise_input.value or "").strip(),
            avatar_path=self.avatar_path,
            nationality=(self.nationality_input.value or "").strip(),
            culture_boundary=(self.culture_input.value or "").strip(),
            avatar_note=(self.avatar_note_input.value or "").strip(),
            # 基础性格留空 → 后端掷一次骰子给她一个倾向
            randomize_persona=True,
        )
        try:
            # 人设推导要调一次 API 再写七个 JSON，放线程里跑，主线程不卡顿
            char_id = await self.service.create_character_async(form)
        except Exception as exc:  # noqa: BLE001
            self._busy = False
            self.create_btn.disabled = False
            self.progress.visible = False
            self.tip.value = f"创建失败：{exc}"
            self.tip.color = "#ff9c9c"
            update_safe(self.progress)
            update_safe(self.tip)
            update_safe(self.create_btn)
            return

        self._busy = False
        self.create_btn.disabled = False
        self.progress.visible = False
        self.tip.value = ""
        self._clear_inputs()
        DialogHost.close(self.page, self.dialog)
        try:
            await self.service.start_background()
        except Exception:  # noqa: BLE001
            pass
        self.on_created(char_id)

    def _clear_inputs(self) -> None:
        for widget in (
            self.name_input,
            self.birthday_input,
            self.occupation_input,
            self.expertise_input,
            self.nationality_input,
            self.culture_input,
            self.persona_input,
            self.avatar_note_input,
        ):
            widget.value = ""
            update_safe(widget)
        self.avatar_path = ""
        self.avatar_label.value = "未选择（可用角色名首字占位）"
        update_safe(self.avatar_label)

    def _create(self, e=None) -> None:
        if getattr(self, "_busy", False):
            return
        fire(self.page, self._create_async, error_hint="创建角色")


class SettingsDialog:
    def __init__(
        self,
        page: ft.Page,
        service,
        on_speed_change: Callable[[float], None],
        on_theme: Optional[Callable[[Dict[str, Any]], Any]] = None,
    ) -> None:
        self.page = page
        self.service = service
        self.on_speed_change = on_speed_change
        self.on_theme = on_theme

        self.key_input = _text_field(
            "sk-（留空表示沿用现有配置）", password=True, can_reveal_password=True, value=DEEPSEEK_API_KEY or ""
        )
        self.user_input = _text_field(service.user_name(), value=service.user_name())
        self.model_input = _text_field(MODEL, value=MODEL)
        self.tick_input = _text_field(str(PROACTIVE_TICK_SECONDS), value=str(PROACTIVE_TICK_SECONDS))
        self.speed_slider = ft.Slider(
            min=0.5, max=3.0, divisions=10, value=1.0, label="播放速度 {value}x", width=320
        )
        self.tip = ft.Text("", size=11, color="#8bc34a")

        # ── 外观 ──
        self.theme = dict(getattr(service, "theme", None) or theme_store.load_theme(service.data_dir))
        self.bg_image_input = _text_field(self.theme.get("bg_image") or "", value=self.theme.get("bg_image") or "")
        self.bg_color_input = _text_field(self.theme.get("bg_color") or "", value=self.theme.get("bg_color") or "")
        self.font_global_input = ft.Dropdown(
            label="全局字体",
            width=200,
            value=self.theme.get("font_global") or "",
            options=[ft.dropdown.Option(key=key or "", text=key or "（软件默认）") for key in theme_store.FONT_CHOICES],
            filled=True,
            fill_color="#2a2a2a",
            border_radius=8,
            border_color="#3a3a3a",
            focused_border_color="#1472d0",
            border_width=1,
            focused_border_width=1,
            text_style=ft.TextStyle(size=13, color="white"),
            label_style=ft.TextStyle(size=12, color="#9e9e9e"),
        )
        self.font_bubble_input = ft.Dropdown(
            label="气泡字体",
            width=200,
            value=self.theme.get("font_bubble") or "",
            options=[ft.dropdown.Option(key=key or "", text=key or "（跟随全局）") for key in theme_store.FONT_CHOICES],
            filled=True,
            fill_color="#2a2a2a",
            border_radius=8,
            border_color="#3a3a3a",
            focused_border_color="#1472d0",
            border_width=1,
            focused_border_width=1,
            text_style=ft.TextStyle(size=13, color="white"),
            label_style=ft.TextStyle(size=12, color="#9e9e9e"),
        )

        def _color(label: str, key: str, width: int = 130) -> ft.TextField:
            return _text_field(label, value=self.theme.get(key) or "", width=width, data=key)

        self.send_color = _color("发送按钮底", "send_button_color")
        self.send_text_color = _color("发送按钮字", "send_button_text_color")
        self.bubble_user = _color("自己气泡", "bubble_user_color")
        self.bubble_user_text = _color("自己气泡字", "bubble_user_text_color")
        self.bubble_char = _color("对方气泡", "bubble_char_color")
        self.bubble_char_text = _color("对方气泡字", "bubble_char_text_color")
        self.panel_color = _color("侧栏底色", "panel_color")
        self.input_color = _color("输入框底色", "input_color")
        self.accent_color = _color("强调色", "accent_color")
        self.drawer_color = _color("抽屉底色", "drawer_color")
        self.bubble_size = _text_field(str(self.theme.get("bubble_font_size") or 15), value=str(self.theme.get("bubble_font_size") or 15), width=90)
        self.bubble_radius = _text_field(str(self.theme.get("bubble_radius") or 10), value=str(self.theme.get("bubble_radius") or 10), width=90)

        self._color_fields = [
            self.send_color, self.send_text_color, self.bubble_user, self.bubble_user_text,
            self.bubble_char, self.bubble_char_text, self.panel_color, self.input_color,
            self.accent_color, self.drawer_color, self.bg_color_input,
        ]

        api_column = ft.Column(
            tight=True,
            spacing=10,
            controls=[
                ft.Text("API", size=13, color="#9e9e9e"),
                _field("你的名字（会被注入给角色作为称呼锚点）", self.user_input),
                _field("DeepSeek API Key（写入 .env，不进代码）", self.key_input),
                _field("模型", self.model_input, "deepseek-chat（非思考）或 deepseek-flash"),
                _field("后台巡检间隔（秒）", self.tick_input, "越小越容易触发主动消息，演示可用 30"),
                _field("消息播放速度", self.speed_slider),
            ],
        )
        look_column = ft.Column(
            tight=True,
            spacing=10,
            controls=[
                ft.Text("外观", size=13, color="#9e9e9e"),
                ft.Row(spacing=8, controls=[
                    ft.Container(width=300, content=_field("背景图片路径", self.bg_image_input)),
                    ft.Column(tight=True, spacing=4, controls=[
                        ft.Text("背景色", style=FIELD_LABEL), self.bg_color_input,
                    ]),
                ]),
                ft.Row(spacing=8, controls=[self.font_global_input, self.font_bubble_input]),
                ft.Row(spacing=8, wrap=True, controls=[
                    self.send_color, self.send_text_color, self.bubble_user, self.bubble_user_text,
                    self.bubble_char, self.bubble_char_text, self.panel_color, self.input_color,
                    self.accent_color, self.drawer_color,
                ]),
                ft.Row(spacing=8, controls=[
                    ft.Column(tight=True, spacing=4, controls=[ft.Text("气泡字号", style=FIELD_LABEL), self.bubble_size]),
                    ft.Column(tight=True, spacing=4, controls=[ft.Text("气泡圆角", style=FIELD_LABEL), self.bubble_radius]),
                    ft.TextButton("全部恢复默认", on_click=self._reset_theme),
                ]),
            ],
        )

        content = ft.Container(
            width=560,
            padding=15,
            content=ft.Column(
                tight=True,
                scroll=ft.ScrollMode.AUTO,
                spacing=14,
                controls=[api_column, ft.Divider(height=1, color="#2b2b2b"), look_column, self.tip],
            ),
        )
        self.dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("设置"),
            content=content,
            actions=[
                ft.TextButton("取消", on_click=lambda e: DialogHost.close(page, self.dialog)),
                ft.Button(content=ft.Text("保存", color="white"), bgcolor="#1472d0", on_click=self._save),
            ],
            actions_alignment=ft.MainAxisAlignment.END,
        )

    def _reset_theme(self, e=None) -> None:
        self.theme = theme_store.reset_theme(self.service.data_dir)
        if hasattr(self.service, "theme"):
            self.service.theme = dict(self.theme)
        if self.on_theme:
            self.on_theme(dict(self.theme))
        self.tip.value = "已恢复默认外观"
        update_safe(self.tip)

    def _save(self, e=None) -> None:
        updates: Dict[str, str] = {}
        name = (self.user_input.value or "").strip()
        if name and name != self.service.user_name():
            self.service.rename_user(name)
        key = (self.key_input.value or "").strip()
        if key:
            updates["DEEPSEEK_API_KEY"] = key
            self.service.llm.api_key = key
        model = (self.model_input.value or "").strip()
        if model:
            updates["DEEPSEEK_MODEL"] = model
            self.service.llm.model = model
        tick = (self.tick_input.value or "").strip()
        if tick:
            updates["PROACTIVE_TICK_SECONDS"] = tick
        if updates:
            _write_env(updates)

        saved_theme = self._save_theme()

        self.on_speed_change(float(self.speed_slider.value or 1.0))
        self.tip.value = f"已保存{(' ' + str(len(updates)) + ' 项 .env 配置') if updates else ''}　外观已应用"
        DialogHost.close(self.page, self.dialog)

    def _save_theme(self) -> Dict[str, Any]:
        """把界面上的颜色字体收拢进 theme.json，并立刻让界面生效。"""
        payload: Dict[str, Any] = {
            "bg_image": (self.bg_image_input.value or "").strip(),
            "bg_color": (self.bg_color_input.value or "").strip(),
            "font_global": self.font_global_input.value if self.font_global_input.value not in (None, "（软件默认）") else "",
            "font_bubble": self.font_bubble_input.value if self.font_bubble_input.value not in (None, "（跟随全局）") else "",
        }
        for field in self._color_fields:
            key = getattr(field, "data", None)
            if key:
                payload[key] = (field.value or "").strip()
        try:
            payload["bubble_font_size"] = max(10, min(24, int(str(self.bubble_size.value or 15).strip() or 15)))
        except ValueError:
            payload["bubble_font_size"] = 15
        try:
            payload["bubble_radius"] = max(0, min(24, int(str(self.bubble_radius.value or 10).strip() or 10)))
        except ValueError:
            payload["bubble_radius"] = 10

        saved = theme_store.save_theme(payload, self.service.data_dir)
        self.theme = dict(saved)
        if hasattr(self.service, "theme") and isinstance(self.service.theme, dict):
            self.service.theme.clear()
            self.service.theme.update(saved)
        if self.on_theme:
            self.on_theme(dict(saved))
        return saved


def _write_env(updates: Dict[str, str]) -> None:
    """把配置写回 .env（只改关心的 key，其他保持原样）。"""
    lines: list = []
    if ENV_FILE.exists():
        lines = ENV_FILE.read_text(encoding="utf-8").splitlines()
    remain = []
    seen = set()
    for line in lines:
        key = line.split("=", 1)[0].strip() if "=" in line and not line.strip().startswith("#") else ""
        if key in updates:
            remain.append(f"{key}={updates[key]}")
            seen.add(key)
        else:
            remain.append(line)
    for key, value in updates.items():
        if key not in seen:
            remain.append(f"{key}={value}")
    ENV_FILE.write_text("\n".join(remain) + "\n", encoding="utf-8")


class AccountDialog:
    """查看与修改"你自己"这份档案。

    这里改名字会同步刷掉所有角色的身份锚点；
    性别和生日也能改，但它们永远不会流进任何一个 Prompt。
    """

    def __init__(self, page: ft.Page, service, on_changed: Optional[Callable[[], Any]] = None) -> None:
        self.page = page
        self.service = service
        self.on_changed = on_changed

        account = service.account or {}
        self.avatar_path = account.get("avatar_path") or ""
        self.avatar_box = ft.Container(
            alignment=ft.Alignment(0, 0),
            content=avatar(account.get("display_name") or "?", self.avatar_path, 72),
        )
        self.picker = ft.FilePicker(on_result=self._on_pick)
        try:
            if self.picker not in (page.services or []):
                page.services.append(self.picker)
        except Exception:  # noqa: BLE001
            pass

        self.name_input = _text_field("用户名", value=account.get("display_name") or "")
        self.gender_input = ft.Dropdown(
            label="性别",
            width=200,
            value=account.get("gender") or "女",
            options=[ft.dropdown.Option("女"), ft.dropdown.Option("男"), ft.dropdown.Option("不愿填写")],
            filled=True,
            fill_color="#2a2a2a",
            border_radius=8,
            border_color="#3a3a3a",
            focused_border_color="#1472d0",
            border_width=1,
            focused_border_width=1,
            text_style=ft.TextStyle(size=13, color="white"),
            label_style=ft.TextStyle(size=12, color="#9e9e9e"),
        )
        self.birthday_input = _text_field("出生年月日 YYYY-MM-DD", value=account.get("birthday") or "")
        self.tip = ft.Text("", size=11, color="#8bc34a")

        content = ft.Container(
            width=420,
            padding=15,
            content=ft.Column(
                tight=True,
                spacing=12,
                controls=[
                    ft.Row(
                        alignment=ft.MainAxisAlignment.CENTER,
                        controls=[
                            ft.Column(
                                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                                spacing=8,
                                tight=True,
                                controls=[
                                    ft.GestureDetector(
                                        content=self.avatar_box,
                                        on_tap=lambda e: self.picker.pick_files(allow_multiple=False),
                                    ),
                                    ft.TextButton("更换头像", on_click=lambda e: self.picker.pick_files(allow_multiple=False)),
                                ],
                            )
                        ],
                    ),
                    _field("用户名", self.name_input),
                    ft.Row(spacing=8, controls=[
                        ft.Column(tight=True, spacing=4, controls=[self.gender_input]),
                        ft.Container(width=190, content=_field("出生年月日", self.birthday_input)),
                    ]),
                    ft.Text("性别与出生年月日只写进本地文件，模型永远读不到", size=11, color="#7a7a7a"),
                    self.tip,
                ],
            ),
        )
        self.dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("我的账号"),
            content=content,
            actions=[
                ft.TextButton("取消", on_click=lambda e: DialogHost.close(page, self.dialog)),
                ft.Button(content=ft.Text("保存", color="white"), bgcolor="#1472d0", on_click=self._save),
            ],
            actions_alignment=ft.MainAxisAlignment.END,
        )

    def open(self) -> None:
        account = self.service.account or {}
        self.name_input.value = account.get("display_name") or ""
        self.gender_input.value = account.get("gender") or "女"
        self.birthday_input.value = account.get("birthday") or ""
        self.avatar_path = account.get("avatar_path") or ""
        self.avatar_box.content = avatar(account.get("display_name") or "?", self.avatar_path, 72)
        self.tip.value = ""
        DialogHost.show(self.page, self.dialog)

    def _on_pick(self, e: ft.FilePickerResultEvent) -> None:
        files = getattr(e, "files", None) or []
        if files:
            self.avatar_path = getattr(files[0], "path", "") or ""
            self.avatar_box.content = avatar(self.name_input.value or "?", self.avatar_path, 72)
            update_safe(self.avatar_box)

    def _save(self, e=None) -> None:
        from core import account as account_store

        name = (self.name_input.value or "").strip()
        if not name:
            self.tip.value = "用户名不能为空"
            self.tip.color = "#ff9c9c"
            update_safe(self.tip)
            return
        birthday = (self.birthday_input.value or "").strip()
        if birthday and not account_store._valid_birthday(birthday):
            self.tip.value = "出生年月日格式应为 YYYY-MM-DD"
            self.tip.color = "#ff9c9c"
            update_safe(self.tip)
            return
        try:
            self.service.update_user_info(
                display_name=name,
                gender=(self.gender_input.value or "").strip(),
                birthday=birthday,
                avatar_path=self.avatar_path or "",
            )
        except Exception as exc:  # noqa: BLE001
            self.tip.value = f"保存失败：{exc}"
            self.tip.color = "#ff9c9c"
            update_safe(self.tip)
            return
        self.tip.value = "已保存（改名会同步到所有角色的称呼锚点）"
        self.tip.color = "#8bc34a"
        update_safe(self.tip)
        DialogHost.close(self.page, self.dialog)
        if self.on_changed:
            fire(self.page, self.on_changed, error_hint="刷新账号")


class ConfirmDialog:
    """通用二次确认弹窗（删除角色这类不可逆操作必须走这里）。"""

    def __init__(self, page: ft.Page) -> None:
        self.page = page
        self._action: Optional[Callable[[], None]] = None
        self.message = ft.Text(size=13)
        self.dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("请确认"),
            content=ft.Container(width=380, padding=10, content=self.message),
            actions=[
                ft.TextButton("取消", on_click=lambda e: DialogHost.close(page, self.dialog)),
                ft.Button(
                    content=ft.Text("确认删除", color="white"),
                    bgcolor="#c62828",
                    on_click=self._run,
                ),
            ],
            actions_alignment=ft.MainAxisAlignment.END,
        )

    def open(self, message: str, action: Callable[[], None]) -> None:
        self.message.value = message
        self._action = action
        DialogHost.show(self.page, self.dialog)

    def _run(self, e=None) -> None:
        DialogHost.close(self.page, self.dialog)
        if self._action:
            self._action()


class StateDialog:
    """把某个"生命"当前的内部状态摊开给人类看（只读，不改）。"""

    def __init__(self, page: ft.Page, service) -> None:
        self.page = page
        self.service = service
        self.body = ft.Text(size=12, selectable=True)
        self.dialog = ft.AlertDialog(
            modal=False,
            title=ft.Text("生命状态"),
            content=ft.Container(width=520, height=420, padding=10, content=ft.Column(
                expand=True, scroll=ft.ScrollMode.AUTO, tight=True, controls=[self.body]
            )),
            actions=[ft.TextButton("关闭", on_click=lambda e: DialogHost.close(page, self.dialog))],
        )

    def open(self, char_id: str) -> None:
        try:
            summary = self.service.summary(char_id)
            self.body.value = _render(summary)
        except Exception as exc:  # noqa: BLE001
            self.body.value = f"读取失败：{exc}"
        DialogHost.show(self.page, self.dialog)


def _render(summary: Dict[str, Any]) -> str:
    identity = summary.get("identity") or {}
    state = summary.get("state") or {}
    counter = summary.get("counter") or {}
    rel = state.get("relationship") or {}
    emo = state.get("emotion") or {}
    ocean = identity.get("personality_ocean") or {}
    culture = identity.get("culture_profile") or {}

    def ocean_row() -> str:
        names = {
            "openness": "开放性",
            "conscientiousness": "尽责性",
            "extraversion": "外向性",
            "agreeableness": "宜人性",
            "neuroticism": "神经质",
        }
        return "  ".join(f"{names.get(k, k)}{float(v):.2f}" for k, v in ocean.items())

    lines = [
        f"【对面那个人】{summary.get('user_name') or '未知'}（真实称呼，来自 account.json）",
        f"【身份】{identity.get('char_display_name')}　{identity.get('gender')}　{identity.get('current_age')}岁",
        f"　职业：{identity.get('occupation')}　特长：{'、'.join(identity.get('expertise') or [])}",
        f"　自称：{identity.get('self_reference')}　称呼对方：{( identity.get('active_nickname') or '') or '（暂无外号）'}",
        f"　说话方式：{identity.get('speaking_style')}",
        f"　依恋类型：{identity.get('attachment_style')}",
        f"　大五人格：{ocean_row()}",
        f"　文化底色：{culture.get('origin')}；熟悉 {'、'.join(culture.get('knowledge_domains') or [])}",
        f"　向往：{'、'.join(culture.get('interests') or [])}　盲区：{'、'.join(culture.get('blind_spots') or [])}",
        "",
        f"【情绪】{emo.get('label')}　能量 {float(emo.get('energy') or 0):.2f}　身体 {emo.get('physical_state')}　"
        f"戴面具：{'是' if emo.get('is_masking') else '否'}",
        f"　忍耐上限 {float(emo.get('patience_threshold') or 0):.2f}",
        f"【需求】关注 {float((state.get('needs') or {}).get('attention') or 0):.2f}　"
        f"认可 {float((state.get('needs') or {}).get('validation') or 0):.2f}",
        f"【关系】好感 {float(rel.get('affection') or 0):.2f}　立场一致 {float(rel.get('alignment') or 0):.2f}　"
        f"信任 {float(rel.get('trust') or 0):.2f}",
        f"　主导 {float(rel.get('dominance') or 0):.2f}　依赖 {float(rel.get('dependency') or 0):.2f}　"
        f"边界 {float(rel.get('boundary') or 0):.2f}　冲突：{rel.get('conflict_state')}",
        # 故意不列"她有没有拉黑你"：这个面板虽然摊开了大量内部数值，
        # 但唯独这一项必须对玩家不可见 —— 知道了就没意思了，
        # 只能靠发出去的消息是不是带红叹号来判断。
        "",
        f"【演化特征】口头禅：{'、'.join((state.get('evolved_traits') or {}).get('catchphrases') or []) or '暂无'}",
        f"　语气：{(state.get('evolved_traits') or {}).get('tone') or '暂无'}",
        f"【统计】对话 {counter.get('rounds')} 轮　持久化消息 {summary.get('messages')} 条",
        f"　今日主动 {(counter.get('proactive_daily') or {}).get('count')} 次　上次反思 {counter.get('last_reflection_date')}",
        "",
        "【未闭环钩子】",
    ]
    hooks = summary.get("open_hooks") or []
    if hooks:
        for hook in hooks[:10]:
            lines.append(f"　· {hook.get('event')}（{hook.get('arousal')}）")
            if hook.get("unresolved"):
                lines.append(f"　　待闭环：{hook.get('unresolved')}")
    else:
        lines.append("　暂无")
    timers = state.get("unresolved_timers") or []
    if timers:
        lines.append("")
        lines.append("【定时器】")
        for timer in timers:
            lines.append(f"　· {timer.get('content')}（{timer.get('delay_minutes')} 分钟后，创建于 {timer.get('created_at')}）")
    return "\n".join(lines)
