"""基础控件：气泡、头像、撤回提示、拒收红叹号、正在输入。

样式沿用你原来的 UI（深色气泡、蓝色用户气泡、10 圆角、15 号字）。
"""

from __future__ import annotations

import asyncio
import inspect
import traceback
from pathlib import Path
from typing import Any, Dict, List, Optional

import flet as ft


def update_safe(control) -> None:
    """还没挂到 page 上的控件调用 update() 会抛错 —— UI 层统一吞掉，不影响逻辑。"""
    try:
        control.update()
    except Exception:  # noqa: BLE001
        pass


def schedule(page, coro) -> None:
    """把一个协程真正丢进页面所在的事件循环去跑。

    优先走 page.run_task（和页面生命周期绑定），失败再退到裸事件循环，
    最后才在没有循环的环境里 asyncio.run —— 保证任何情况下协程都不是"建了就丢"。
    """
    runner: Optional[object] = None
    if page is not None:
        async def _runner() -> object:
            return await coro

        try:
            page.run_task(_runner)  # 只接受协程函数，不能传协程对象
            return
        except Exception:  # noqa: BLE001
            pass
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        asyncio.run(_guard(coro))
        return
    loop.create_task(_guard(coro))


async def _guard(coro) -> None:
    try:
        await coro
    except Exception:  # noqa: BLE001
        traceback.print_exc()


def fire(page, callback, *args, error_hint: str = "", **kwargs):
    """在同步事件处理器里调用可能返回协程的回调。

    Flet 只会在"事件处理器本身是协程"时自动 await 它；
    如果处理器是普通函数、里面又调用了 async 回调，返回值会变成一个
    没人管的协程对象就地蒸发 —— 表现就是"点了按钮毫无反应"，
    控制台里只留一句 RuntimeWarning: coroutine ... was never awaited。

    用法：fire(page, self._on_login, name)
    """
    try:
        result = callback(*args, **kwargs)
    except Exception as exc:  # noqa: BLE001
        traceback.print_exc()
        print(f"[UI] 回调执行失败{('：' + error_hint) if error_hint else ''}：{exc}")
        return None
    if inspect.isawaitable(result):
        schedule(page, result)
    return result


def pick_files(page, picker: ft.FilePicker, **kwargs) -> None:
    """FilePicker.pick_files 在 Flet 1.0 里是协程。

    on_click 里直接 picker.pick_files(...) 会拿到一个没人 await 的协程，
    选择框根本弹不出来 —— 统一走这里调度。
    """
    fire(page, picker.pick_files, error_hint="打开文件选择器", **kwargs)


def update_page(page, *controls) -> None:
    """刷一批控件（再整页刷一次），没挂到 page 上的异常直接吞掉。"""
    for control in controls:
        try:
            control.update()
        except Exception:  # noqa: BLE001
            pass
    try:
        page.update()
    except Exception:  # noqa: BLE001
        pass


def _exists(path: Optional[str]) -> bool:
    return bool(path) and Path(str(path)).exists()


def avatar(name: str, image_path: Optional[str] = None, size: int = 42):
    """头像：优先本地图片，缺失时用首字圆形占位（不依赖任何外部资源）。"""
    initial = (name or "?").strip()[:1] or "?"
    placeholder = ft.Container(
        width=size,
        height=size,
        border_radius=size / 2,
        bgcolor="#3d3d3d",
        alignment=ft.Alignment(0, 0),
        content=ft.Text(initial, size=size * 0.45, color="white", weight=ft.FontWeight.W_500),
    )
    if _exists(image_path):
        try:
            return ft.Container(
                width=size,
                height=size,
                border_radius=size / 2,
                clip_behavior=ft.ClipBehavior.HARD_EDGE,
                content=ft.Image(src=str(image_path), width=size, height=size, fit=ft.BoxFit.COVER),
            )
        except Exception:  # noqa: BLE001
            return placeholder
    return placeholder


def time_line(text: str, color: str = "#8a8a8a"):
    """仿微信的时间提示：一轮对话前后若隔了够久，中间插一行居中灰字。"""
    return ft.Row(
        alignment=ft.MainAxisAlignment.CENTER,
        controls=[
            ft.Container(
                padding=ft.Padding(left=8, right=8, top=3, bottom=3),
                content=ft.Text(text, size=11, color=color),
            )
        ],
    )


def make_bubble(text: str, is_user: bool, theme: Optional[Dict[str, Any]] = None):
    """气泡：右蓝左深灰 —— 你原来的样式，颜色改成从主题里取。"""
    theme = theme or {}
    bubble_color = theme.get("bubble_user_color") if is_user else theme.get("bubble_char_color") or "#1472d0" if is_user else "#2f2f2f"
    bubble_color = (theme.get("bubble_user_color") or "#1472d0") if is_user else (theme.get("bubble_char_color") or "#2f2f2f")
    text_color = (theme.get("bubble_user_text_color") or "#ffffff") if is_user else (theme.get("bubble_char_text_color") or "#ffffff")
    size = int(theme.get("bubble_font_size") or 15)
    radius = int(theme.get("bubble_radius") or 10)
    family = theme.get("font_bubble") or theme.get("font_global") or None

    return ft.Row(
        alignment=ft.MainAxisAlignment.END if is_user else ft.MainAxisAlignment.START,
        vertical_alignment=ft.CrossAxisAlignment.START,
        controls=[
            ft.Container(
                margin=ft.Margin(left=15, right=15, top=8, bottom=8),
                padding=10,
                alignment=ft.Alignment.CENTER,
                bgcolor=bubble_color,
                border_radius=radius,
                content=ft.Text(
                    text,
                    style=ft.TextStyle(size=size, color=text_color, font_family=family),
                    width=None if len(text) <= 40 else 450,
                    no_wrap=False,
                    selectable=True,
                ),
            )
        ],
    )


def message_row(
    text: str,
    is_user: bool,
    name: str = "",
    avatar_path: Optional[str] = None,
    theme: Optional[Dict[str, Any]] = None,
    avatar_size: int = 36,
):
    """头像 + 气泡的组合行 —— 每条消息旁边都站着说话那个人。"""
    bubble_row = make_bubble(text, is_user, theme)
    bubble = bubble_row.controls[0]
    bubble.margin = ft.Margin(left=6, right=6, top=8, bottom=8)
    picture = avatar(name, avatar_path, avatar_size)
    if is_user:
        controls: List[ft.Control] = [bubble, picture]
        row = ft.Row(alignment=ft.MainAxisAlignment.END, vertical_alignment=ft.CrossAxisAlignment.START, controls=controls)
    else:
        controls = [picture, bubble]
        row = ft.Row(alignment=ft.MainAxisAlignment.START, vertical_alignment=ft.CrossAxisAlignment.START, controls=controls)
    return row


def recalled_line(by: str = "character", color: str = "#9e9e9e"):
    text = "你撤回了一条消息" if by == "user" else "对方撤回了一条消息"
    return system_line(text, color)


def system_line(text: str, color: str = "#9e9e9e"):
    """撤回 / 时间 / 系统提示：居中灰字。"""
    return ft.Row(
        alignment=ft.MainAxisAlignment.CENTER,
        controls=[
            ft.Container(
                margin=ft.Margin(left=15, right=15, top=6, bottom=6),
                padding=ft.Padding(left=10, right=10, top=4, bottom=4),
                border_radius=8,
                bgcolor="#2a2a2a",
                content=ft.Text(text, size=12, color=color, italic=True),
            )
        ],
    )


def reject_line(text: str = "消息已发出，但被对方拒收了。"):
    """拉黑后的红叹号提示。"""
    return ft.Row(
        alignment=ft.MainAxisAlignment.CENTER,
        controls=[
            ft.Container(
                margin=ft.Margin(left=15, right=15, top=6, bottom=6),
                padding=ft.Padding(left=10, right=10, top=6, bottom=6),
                border_radius=8,
                bgcolor="#3a2323",
                content=ft.Row(
                    spacing=6,
                    tight=True,
                    controls=[
                        ft.Icon(ft.Icons.ERROR_OUTLINE, size=14, color="#ff6b6b"),
                        ft.Text(text, size=12, color="#ff9c9c"),
                    ],
                ),
            )
        ],
    )


def typing_indicator(name: str = "对方"):
    """正在输入…（走到正式气泡时会被替换掉）。

    带一个 data 标记，方便播放逻辑用一行判断把它摘走，
    不用再去猜"哪个 Row 是那个转圈的"。
    """
    row = ft.Row(
        data="typing",
        alignment=ft.MainAxisAlignment.START,
        controls=[
            ft.Container(
                margin=ft.Margin(left=15, right=15, top=8, bottom=8),
                padding=10,
                bgcolor="#2f2f2f",
                border_radius=10,
                content=ft.Row(
                    tight=True,
                    spacing=6,
                    controls=[
                        ft.ProgressRing(width=12, height=12, stroke_width=2, color="#9e9e9e"),
                        ft.Text(f"{name}正在输入…", size=13, color="#9e9e9e"),
                    ],
                ),
            )
        ],
    )
    return row


def background(bg_image: Optional[str] = None):
    if _exists(bg_image):
        for kwargs in (
            {"src": str(bg_image), "fit": ft.BoxFit.FILL, "opacity": 0.3},
            {"src": str(bg_image), "fit": ft.BoxFit.FILL},
        ):
            try:
                return ft.DecorationImage(**kwargs)
            except Exception:  # noqa: BLE001
                continue
    return None
