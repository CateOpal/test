"""左侧：图标栏 + partners 列表（沿用你原来的视觉）。

partners 数据全部来自 meta.json（仅 UI 展示用：名字、头像、最后一条预览、时间、未读），
不进入任何 API 上下文。
"""

from __future__ import annotations

from typing import Callable, List, Optional

import flet as ft

from ui.widgets import avatar


def build_dividers():
    vertical_divider = ft.VerticalDivider(width=1, color="white", opacity=0.5)
    divider = ft.Divider(height=1, color="white", opacity=0.5)
    return vertical_divider, divider


def build_left_panel(
    on_chats: Optional[Callable] = None,
    on_add: Optional[Callable] = None,
    on_settings: Optional[Callable] = None,
    on_account: Optional[Callable] = None,
    theme: Optional[dict] = None,
):
    """左侧栏：上部聊天信息，中间弹性留白，下部账号 / 建角色 / 设置。"""
    theme = theme or {}
    accent = theme.get("accent_color") or "#1472d0"
    icon_color = theme.get("text_color") or "#ffffff"

    def _icon(icon, tip, handler, selected_icon=None):
        return ft.IconButton(
            icon,
            selected_icon=selected_icon,
            selected=False,
            icon_color=icon_color,
            tooltip=tip,
            on_click=lambda e: handler() if handler else None,
        )

    return ft.Container(
        width=60,
        padding=ft.Padding(left=6, top=10, right=6, bottom=10),
        bgcolor=theme.get("panel_color") or "#252526",
        content=ft.Column(
            alignment=ft.MainAxisAlignment.START,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=6,
            controls=[
                _icon(ft.Icons.TEXTSMS_OUTLINED, "聊天信息", on_chats, ft.Icons.TEXTSMS_ROUNDED),
                ft.Container(expand=True),
                _icon(ft.Icons.ACCOUNT_CIRCLE_OUTLINED, "我的账号", on_account, ft.Icons.ACCOUNT_CIRCLE),
                _icon(ft.Icons.PERSON_ADD_ALT_1, "创建角色", on_add),
                _icon(ft.Icons.SETTINGS_OUTLINED, "设置", on_settings, ft.Icons.SETTINGS),
            ],
        ),
    )


def build_search_field(theme: Optional[dict] = None):
    """纯功能提示，不写任何"建议你输入什么"的引导。"""
    theme = theme or {}
    return ft.TextField(
        hint_text="搜索",
        filled=True,
        fill_color="#2f2f2f",
        opacity=0.8,
        hint_style=ft.TextStyle(size=15, color="white"),
        text_style=ft.TextStyle(size=15, color="white"),
        border_radius=10,
        border_color="#2f2f2f",
        focused_border_color="#1472d0",
        border_width=1,
        focused_border_width=1,
        height=40,
        content_padding=ft.Padding(left=12, top=0, right=12, bottom=0),
    )


class PartnerCard:
    """单张伙伴卡片：圆形头像 + 名字 + 时间 + 最后一条预览。"""

    def __init__(self, image=None, character="角色名", history_message="历史消息",
                 last_time="", unread: int = 0, on_click=None):
        self.character = character
        right_controls: List[ft.Control] = [
            ft.Container(width=20),
            ft.Text(last_time, width=50, size=10, color="#9e9e9e"),
        ]
        if unread:
            right_controls.insert(0, ft.Container(
                width=16, height=16, border_radius=8, bgcolor="#f44336",
                alignment=ft.Alignment(0, 0),
                content=ft.Text(str(unread), size=10, color="white", text_align=ft.TextAlign.CENTER),
            ))
        self.view = ft.Container(
            on_click=on_click,
            height=60,
            padding=ft.Padding(left=10, top=15, bottom=5, right=0),
            content=ft.Row(
                spacing=10,
                controls=[
                    avatar(character, image),
                    ft.Column(
                        spacing=2,
                        controls=[
                            ft.Row(
                                expand=True,
                                spacing=0,
                                controls=[
                                    ft.Text(
                                        character,
                                        width=100,
                                        max_lines=1,
                                        overflow=ft.TextOverflow.ELLIPSIS,
                                        style=ft.TextStyle(size=15),
                                    ),
                                    *right_controls,
                                ],
                            ),
                            ft.Text(
                                history_message,
                                width=170,
                                max_lines=1,
                                overflow=ft.TextOverflow.ELLIPSIS,
                                style=ft.TextStyle(size=11, color="#9e9e9e"),
                            ),
                        ],
                    ),
                ],
            ),
        )


def render_partners(partners_view: ft.ListView, storages, on_select: Callable[[str], None]) -> None:
    partners_view.controls.clear()
    for storage in storages:
        meta = storage.load("meta.json")
        cid = meta.get("char_id", storage.char_id)
        last_time = meta.get("last_message_time") or ""
        partners_view.controls.append(
            PartnerCard(
                image=meta.get("avatar_path"),
                character=meta.get("display_name") or storage.char_id,
                history_message=meta.get("last_message_preview") or "还什么都没说",
                last_time=last_time[11:16] if len(last_time) >= 16 else "",
                unread=int(meta.get("unread_count") or 0),
                on_click=lambda e, c=cid: on_select(c),
            ).view
        )


def build_partners_panel(theme: Optional[dict] = None):
    """返回 (panel_container, search_field, partners_view)"""
    theme = theme or {}
    search_field = build_search_field(theme)
    partners_view = ft.ListView(expand=True, padding=0, spacing=0)
    panel = ft.Container(
        width=250,
        padding=ft.Padding(left=8, top=8, right=4, bottom=8),
        bgcolor=theme.get("panel_color") or "#252526",
        content=ft.Column(
            spacing=8,
            controls=[
                search_field,
                ft.Divider(height=1, color=theme.get("divider_color") or "#2b2b2b"),
                partners_view,
            ],
        ),
    )
    return panel, search_field, partners_view
