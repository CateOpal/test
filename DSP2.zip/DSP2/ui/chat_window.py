"""右侧：消息区 + 播放策略。

发送后不是立刻出结果：这里会按 ⑨ 给的 delay_ms 一条条播出来，
期间头部状态文本变成"正在输入…"，遇到 recall 动作就真删记录并留一行灰色提示。

顶部只有角色名和 Menu 图标 —— 拉黑按钮不在这里，
因为这是否发生是她的黑盒行为，用户只能通过"发出去被拒收"来感知。
"""

from __future__ import annotations

import asyncio
import time
from typing import Any, Callable, Dict, List, Optional

import flet as ft

from backend.thresholds import scaled_delay
from config import TIME_SEPARATOR_SECONDS, USER_RECALL_WINDOW
from core import timeutil
from ui.widgets import (
    avatar,
    make_bubble,
    message_row,
    recalled_line,
    reject_line,
    system_line,
    time_line,
    typing_indicator,
    update_safe,
)

RECALL_TAG = "recall-btn"
TYPING_TAG = "typing"


class ChatPane:
    def __init__(
        self,
        on_send: Optional[Callable[[str, str], Any]] = None,
        speed: float = 1.0,
        on_menu: Optional[Callable[[], Any]] = None,
        on_recall: Optional[Callable[[], Any]] = None,
        theme: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.on_send = on_send
        self.speed = speed
        self.on_menu = on_menu
        self.on_recall = on_recall
        self.theme: Dict[str, Any] = dict(theme or {})
        self.page: Optional[ft.Page] = None

        self._busy = False
        self._pending_image: Optional[str] = None
        self._last_user_index: Optional[int] = None
        self._recall_task: Optional[asyncio.Task] = None
        self._last_ts: Optional[str] = None
        self.read_only = False
        self.char_name = ""
        self.char_avatar = ""

        self.title_text = ft.Text("角色名", style=ft.TextStyle(size=18))
        self.status_text = ft.Text("", size=11, color="#9e9e9e")
        self.messages_list = ft.ListView(expand=7, auto_scroll=True, padding=0, spacing=0)

        self.input_field = ft.TextField(
            expand=True,
            multiline=True,
            border=ft.NoInputBorder(),
            shift_enter=True,
            hint_text="发消息，Enter 发送，Shift+Enter 换行",
            hint_style=ft.TextStyle(size=15),
            text_style=ft.TextStyle(size=15),
            min_lines=1,
            max_lines=4,
            on_submit=self._on_submit,
        )
        self.send_btn = ft.Container(
            width=100,
            height=35,
            bgcolor=self.theme.get("send_button_color") or "#1472d0",
            border_radius=10,
            margin=ft.Margin(left=0, right=10, top=0, bottom=10),
            alignment=ft.Alignment(0, 0),
            content=ft.Text(
                "Enter发送",
                color=self.theme.get("send_button_text_color") or "#ffffff",
                size=14,
            ),
            on_click=self._on_submit,
        )
        self.image_btn = ft.IconButton(
            ft.Icons.IMAGE_OUTLINED,
            icon_size=20,
            tooltip="发一张图片",
            on_click=self._pick_image,
        )
        self.image_badge = ft.Text("", size=11, color="#8ec7ff", visible=False)

        self.picker = ft.FilePicker(on_result=self._on_pick_result)
        self._attach_picker = True

        self.input_row = ft.Row(
            spacing=6,
            controls=[
                self.image_btn,
                ft.Container(expand=True, content=self.input_field),
            ],
        )

        header = ft.Container(
            height=52,
            padding=ft.Padding(left=15, right=5),
            content=ft.Row(
                spacing=0,
                controls=[
                    ft.Column(spacing=0, tight=True, controls=[self.title_text, self.status_text]),
                    ft.Container(expand=True),
                    ft.IconButton(
                        ft.Icons.MENU_ROUNDED,
                        icon_size=20,
                        tooltip="角色信息与设置",
                        on_click=lambda e: self.on_menu() if self.on_menu else None,
                    ),
                ],
            ),
        )

        self.bottom_area = ft.Column(
            spacing=0,
            controls=[
                ft.Row(spacing=4, controls=[self.image_badge], alignment=ft.MainAxisAlignment.START),
                self.input_row,
                ft.Row(alignment=ft.MainAxisAlignment.END, controls=[self.send_btn]),
            ],
        )

        self.body_stack = ft.Stack(
            expand=True,
            controls=[
                ft.Column(
                    spacing=0,
                    controls=[
                        header,
                        ft.Divider(height=1, color="white", opacity=0.5),
                        self.messages_list,
                        ft.Divider(height=1, color="white", opacity=0.5),
                        self.bottom_area,
                    ],
                )
            ],
        )
        self.deleted_mask = ft.Container(
            expand=True,
            visible=False,
            bgcolor="#1e1e1e",
            opacity=0.72,
            alignment=ft.Alignment(0, 0),
            content=ft.Column(
                alignment=ft.MainAxisAlignment.CENTER,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=8,
                controls=[
                    ft.Icon(ft.Icons.LOCK_OUTLINE, size=44, color="#7a7a7a"),
                    ft.Text("对方已删除全部对话", size=15, color="#9e9e9e"),
                    ft.Text("这里只能回看历史记录", size=12, color="#6d6d6d"),
                ],
            ),
        )
        self.body_stack.controls.append(self.deleted_mask)
        self.view = self.body_stack

    # ---------------------------------------------------------------- 绑定
    def attach(self, page: ft.Page) -> None:
        self.page = page
        if self._attach_picker:
            try:
                if self.picker not in (page.services or []):
                    page.services.append(self.picker)
            except Exception:  # noqa: BLE001
                self._attach_picker = False

    def apply_theme(self, theme: Dict[str, Any]) -> None:
        """设置面板改完颜色后，把整块界面刷一遍。"""
        self.theme = dict(theme or {})
        self.send_btn.bgcolor = self.theme.get("send_button_color") or "#1472d0"
        if isinstance(self.send_btn.content, ft.Text):
            self.send_btn.content = ft.Text(
                "Enter发送",
                color=self.theme.get("send_button_text_color") or "#ffffff",
                size=14,
            )
        family = self.theme.get("font_global") or None
        size = int(self.theme.get("bubble_font_size") or 15)
        self.input_field.text_style = ft.TextStyle(size=size, color=self.theme.get("text_color") or "#ffffff", font_family=family)
        self.title_text.style = ft.TextStyle(size=18, color=self.theme.get("text_color") or "#ffffff", font_family=family)
        self.status_text.color = self.theme.get("sub_text_color") or "#9e9e9e"
        update_safe(self.input_field)
        update_safe(self.send_btn)
        update_safe(self.title_text)
        update_safe(self.status_text)

    def set_peer(self, name: str, avatar_path: str = "") -> None:
        self.char_name = name
        self.char_avatar = avatar_path or ""

    def set_read_only(self, disabled: bool, hint: str = "") -> None:
        """被删好友：面板加灰遮罩，输入区彻底停用。"""
        self.read_only = disabled
        self.deleted_mask.visible = disabled
        self.image_btn.disabled = disabled
        self.input_field.disabled = disabled
        self.send_btn.disabled = disabled
        self.send_btn.opacity = 0.4 if disabled else 1.0
        if disabled:
            self.status_text.value = hint or "对方已删除全部对话"
        update_safe(self.input_field)
        update_safe(self.send_btn)
        update_safe(self.image_btn)
        update_safe(self.deleted_mask)
        update_safe(self.body_stack)

    def set_title(self, name: str, subtitle: str = "") -> None:
        self.title_text.value = name
        if not self.read_only:
            self.status_text.value = subtitle
        update_safe(self.title_text)
        update_safe(self.status_text)

    def set_status(self, text: str) -> None:
        """头部那行状态文本 —— 平时显示情绪，她打字时显示"正在输入…"。 """
        if self.read_only:
            return
        self.status_text.value = text
        update_safe(self.status_text)

    # ---------------------------------------------------------------- 历史
    def load_history(
        self,
        messages: List[Dict[str, Any]],
        name: str = "",
        subtitle: str = "",
        user_avatar: str = "",
        char_avatar: str = "",
    ) -> None:
        """重开软件时，按库里的真实行数渲染 —— 三行就是三个气泡。

        顺带处理撤回行（库里行还在、正文已空），以及相隔够久的时间提示。
        """
        self.messages_list.controls.clear()
        self._last_ts = None
        self.set_peer(name, char_avatar)
        self.char_avatar = char_avatar
        self._user_avatar = user_avatar

        for msg in messages:
            role = msg.get("role") or "assistant"
            stamp = msg.get("timestamp") or ""
            deleted = bool(msg.get("is_deleted"))

            if deleted or msg.get("msg_type") == "recall_hint":
                by = msg.get("extra") or ""
                self._maybe_time_line(stamp)
                self._push(recalled_line("user" if by == "user" else "character"))
                self._last_ts = stamp
                continue
            if role == "system":
                self._maybe_time_line(stamp)
                self._push(system_line(msg.get("text") or ""))
                self._last_ts = stamp
                continue

            self._maybe_time_line(stamp)
            is_user = role == "user"
            image = msg.get("image_path") or ""
            text = msg.get("text") or ""
            if image and not text:
                text = "[图片]"
            elif image:
                text = f"[图片] {text}"
            self._push(
                message_row(
                    text,
                    is_user,
                    name if not is_user else "",
                    user_avatar if is_user else char_avatar,
                    self.theme,
                )
            )
            self._last_ts = stamp

        self.set_title(name, subtitle)
        if self.page:
            update_safe(self.messages_list)

    def _maybe_time_line(self, stamp: str) -> None:
        """相邻两条消息间隔超过阈值才插时间，避免刷屏。"""
        if not stamp:
            return
        previous = timeutil.parse(self._last_ts) if self._last_ts else None
        current = timeutil.parse(stamp)
        if previous and current:
            gap = (current - previous).total_seconds()
            if 0 <= gap < TIME_SEPARATOR_SECONDS:
                return
        label = self._clock_label(current)
        if label:
            self._push(time_line(label))

    @staticmethod
    def _clock_label(moment) -> str:
        if not moment:
            return ""
        today = timeutil.now()
        if moment.date() == today.date():
            return moment.strftime("%H:%M")
        return moment.strftime("%m月%d日 %H:%M")

    # ---------------------------------------------------------------- 输入
    def _on_submit(self, e=None) -> None:
        if self.read_only:
            return
        text = (self.input_field.value or "").strip()
        image = self._pending_image
        if not text and not image:
            return
        self.input_field.value = ""
        if self.page:
            update_safe(self.input_field)
        if self.on_send:
            from ui.widgets import fire

            fire(self.page, self.on_send, text, image or "", error_hint="发送")
        self._pending_image = None
        self.image_badge.value = ""
        self.image_badge.visible = False
        update_safe(self.image_badge)

    def _pick_image(self, e=None) -> None:
        if self.read_only:
            return
        try:
            from ui.widgets import fire as _fire

            _fire(self.page, self.picker.pick_files, allow_multiple=False, dialog_title="选一张图片")
        except Exception as exc:  # noqa: BLE001
            self.push_notice(f"无法打开文件选择器：{exc}")

    def _on_pick_result(self, e: ft.FilePickerResultEvent) -> None:
        files = getattr(e, "files", None) or []
        if not files:
            return
        path = getattr(files[0], "path", "") or ""
        if not path:
            return
        self._pending_image = path
        self.image_badge.value = f"已选图片：{path.split('/')[-1].split(chr(92))[-1]}（Enter 发送）"
        self.image_badge.visible = True
        update_safe(self.image_badge)

    # ---------------------------------------------------------------- 用户侧气泡
    def push_user(self, text: str, image: str = "") -> None:
        shown = text or "[图片]"
        self._maybe_time_line(timeutil.now_str())
        row = message_row(
            shown,
            True,
            "",
            getattr(self, "_user_avatar", "") or "",
            self.theme,
        )
        self.messages_list.controls.append(row)
        index = len(self.messages_list.controls) - 1
        self._last_ts = timeutil.now_str()
        if self.page:
            update_safe(self.messages_list)
        self._offer_recall(index)

    def _offer_recall(self, index: int) -> None:
        """发出去的两秒内，给自己的最后一句留一个"撤回"入口。

        两秒窗口是刻意的：真实 IM 里撤回也是这种"说完立刻反悔"的动作，
        过了这个窗口就只能等对方怎么反应。
        """
        self._clear_recall()
        if index < 0 or index >= len(self.messages_list.controls):
            return
        button = ft.TextButton(
            "撤回",
            data=RECALL_TAG,
            style=ft.ButtonStyle(color="#8ec7ff", text_style=ft.TextStyle(size=11)),
            on_click=self._on_recall_click,
        )
        self.messages_list.controls.append(
            ft.Row(alignment=ft.MainAxisAlignment.END, controls=[ft.Container(margin=ft.Margin(right=52, bottom=4), content=button)])
        )
        self._recall_index = len(self.messages_list.controls) - 1
        if self.page:
            update_safe(self.messages_list)

        async def _expire() -> None:
            await asyncio.sleep(USER_RECALL_WINDOW)
            self._clear_recall()

        try:
            self._recall_task = asyncio.get_running_loop().create_task(_expire())
        except RuntimeError:
            self._recall_task = None

    def _clear_recall(self) -> None:
        task = getattr(self, "_recall_task", None)
        if task is not None and not task.done():
            task.cancel()
        self._recall_task = None
        index = getattr(self, "_recall_index", None)
        self._recall_index = None
        if index is None:
            return
        if 0 <= index < len(self.messages_list.controls):
            # 只删我们自己加的那行撤回按钮，不碰上面的气泡
            self.messages_list.controls.pop(index)
            if self.page:
                update_safe(self.messages_list)

    def _on_recall_click(self, e=None) -> None:
        index = getattr(self, "_recall_index", None)
        if index is None or index < 1:
            return
        bubble_index = index - 1
        if 0 <= bubble_index < len(self.messages_list.controls):
            self.messages_list.controls[bubble_index] = recalled_line("user")
        self._clear_recall()
        if self.page:
            update_safe(self.messages_list)
        if self.on_recall:
            from ui.widgets import fire

            fire(self.page, self.on_recall, error_hint="撤回")

    # ---------------------------------------------------------------- 播放
    async def play_round(self, result: Dict[str, Any], name: str = "对方") -> None:
        """按 delay 逐条播放 ⑨ 排好的消息。"""
        items = result.get("messages") or []
        messages = items if isinstance(items, list) else []
        scene_intent = result.get("scene_intent") or "normal"
        status = result.get("status") or ("normal" if not result.get("blocked") else "blocked")

        if status == "deleted":
            self.set_read_only(True)
            return
        if status in ("blocked", "rejected", "friend_removed"):
            text = str((messages[0].get("text") if messages and isinstance(messages[0], dict) else "") or "消息已发出，但被对方拒收了。")
            self._maybe_time_line(timeutil.now_str())
            self._push(reject_line(text))
            self._last_ts = timeutil.now_str()
            return

        for item in messages:
            if isinstance(item, dict) and item.get("action") == "recall":
                await asyncio.sleep(0.5 / self.speed)
                self._recall_last()
                continue
            text = str(item.get("text") or "").strip() if isinstance(item, dict) else str(item)
            if not text:
                continue
            await asyncio.sleep(
                scaled_delay(item.get("delay_ms") if isinstance(item, dict) else 800, scene_intent, self.speed)
            )
            self._typing(True, name)
            await asyncio.sleep(0.4 / self.speed)
            self._typing(False)
            kind = (item.get("kind") if isinstance(item, dict) else "") or ""
            self._maybe_time_line(timeutil.now_str())
            if kind == "reject":
                self._push(reject_line(text))
            else:
                self._push(
                    message_row(text, False, self.char_name or name, self.char_avatar, self.theme)
                )
            self._last_ts = timeutil.now_str()

    def _typing(self, show: bool, name: str = "对方") -> None:
        if show:
            self.set_status(f"{name}正在输入…")
            self.messages_list.controls.append(typing_indicator(name))
        else:
            self.set_status("")
            for index in range(len(self.messages_list.controls) - 1, -1, -1):
                control = self.messages_list.controls[index]
                if getattr(control, "data", None) == TYPING_TAG:
                    self.messages_list.controls.pop(index)
                    break
                if isinstance(control, ft.Row) and control.controls:
                    inner = control.controls[0]
                    if isinstance(inner, ft.Container) and isinstance(inner.content, ft.Row):
                        texts = [c for c in inner.content.controls if isinstance(c, ft.Text)]
                        if texts and "正在输入" in (texts[0].value or ""):
                            self.messages_list.controls.pop(index)
                            break
        if self.page:
            update_safe(self.messages_list)

    def _recall_last(self) -> None:
        """把最后一条可见气泡换成灰色提示。

        数据库那边由后端负责真删，这里只负责让它"看起来消失"。
        """
        for index in range(len(self.messages_list.controls) - 1, -1, -1):
            row = self.messages_list.controls[index]
            if not isinstance(row, ft.Row):
                continue
            if getattr(row, "data", None) == TYPING_TAG:
                continue
            if self._is_bubble_row(row):
                self.messages_list.controls[index] = recalled_line("character")
                break
        if self.page:
            update_safe(self.messages_list)

    @staticmethod
    def _is_bubble_row(row: ft.Row) -> bool:
        """message_row 的结构：头像容器 + 气泡容器，气泡里的 content 是 Text。

        用"恰好两个子控件"把系统提示行（只有一个子控件）和正在输入区分开，
        免得撤回把一行灰色小字误当成气泡抽走。
        """
        children = row.controls or []
        return len(children) == 2 and any(
            isinstance(child, ft.Container) and isinstance(child.content, ft.Text)
            for child in children
        )

    def push_notice(self, text: str) -> None:
        self._push(system_line(text))

    def _push(self, control) -> None:
        self.messages_list.controls.append(control)
        if self.page:
            update_safe(self.messages_list)
