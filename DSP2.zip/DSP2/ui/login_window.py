"""登录 / 建档窗口。

第一次打开软件时先问这几个问题 —— 不是仪式感，而是在固化 ① 号需要的锚点：
名字会被注入【绝对身份认知】，避免她在长上下文里搞不清谁是谁。

控件：头像（可选）、性别、用户名、出生年月日、登录按钮。
除头像外全部必填，缺哪一项就在那一项下面飘一行红字。

隐私边界写在这里，是因为这里最容易被误解：
    这份档案里同时存着"给她看的"和"绝不给她看的"。
    名字和头像可以给；性别和生日永远不会离开本地文件。
"""

from __future__ import annotations

from typing import Any, Callable, Dict, List

import flet as ft

from core import account as account_store
from ui.widgets import avatar, fire, pick_files, update_page as update

GENDER_OPTIONS = [ft.dropdown.Option("女"), ft.dropdown.Option("男"), ft.dropdown.Option("不愿填写")]


def build_login_view(page: ft.Page, on_success: Callable[..., Any]) -> ft.Control:
    avatar_path: Dict[str, str] = {"value": ""}
    avatar_box = ft.Container(alignment=ft.Alignment(0, 0), content=avatar("?", "", 72))

    picker = ft.FilePicker(on_result=None)
    try:
        if picker not in (page.services or []):
            page.services.append(picker)
    except Exception:  # noqa: BLE001
        pass

    name_input = _field("用户名", 320)
    gender_input = ft.Dropdown(
        label="性别",
        width=320,
        options=list(GENDER_OPTIONS),
        filled=True,
        fill_color="#2a2a2a",
        border_radius=8,
        border_color="#3a3a3a",
        focused_border_color="#1472d0",
        focused_border_width=1,
        border_width=1,
        text_style=ft.TextStyle(size=14, color="white"),
        label_style=ft.TextStyle(size=12, color="#9e9e9e"),
        content_padding=ft.Padding(left=10, right=10, top=8, bottom=8),
    )
    birthday_input = _field("出生年月日  格式 YYYY-MM-DD", 320)

    errors: List[ft.Text] = []
    for _ in range(3):
        text = ft.Text("", size=11, color="#ff8a8a", text_align=ft.TextAlign.LEFT, width=320)
        errors.append(text)

    progress = ft.ProgressRing(width=16, height=16, stroke_width=2, visible=False)

    def _render_avatar() -> None:
        avatar_box.content = avatar(name_input.value or "?", avatar_path["value"], 72)
        update(page, avatar_box)

    def _on_pick(e: ft.FilePickerResultEvent) -> None:
        files = getattr(e, "files", None) or []
        if files:
            avatar_path["value"] = getattr(files[0], "path", "") or ""
            _render_avatar()

    picker.on_result = _on_pick

    def _clear_errors() -> None:
        for item in errors:
            item.value = ""
        update(page, *errors)

    def _enter(e=None) -> None:
        name = (name_input.value or "").strip()
        gender = (gender_input.value or "").strip()
        birthday = (birthday_input.value or "").strip()
        found = account_store.validate_form(name, gender, birthday)
        _clear_errors()
        if found:
            mapping = {"用户名不能为空": 0, "请选择性别": 1, "请填写出生年月日": 2, "出生年月日格式为 YYYY-MM-DD": 2}
            for message in found:
                index = mapping.get(message, 0)
                errors[index].value = message
            update(page, *errors)
            return
        progress.visible = True
        update(page, progress)
        # on_success 是 async def —— 必须走 fire，直接在同步处理器里调用
        # 会让协程没人 await，表现就是"点了按钮毫无反应"。
        fire(
            page,
            on_success,
            {
                "display_name": name,
                "gender": gender,
                "birthday": birthday,
                "avatar_path": avatar_path["value"],
            },
            error_hint="登录建档",
        )

    name_input.on_submit = _enter
    birthday_input.on_submit = _enter

    enter_btn = ft.Container(
        width=320,
        height=42,
        bgcolor="#1472d0",
        border_radius=10,
        alignment=ft.Alignment(0, 0),
        content=ft.Text("进入", color="white", size=15),
        on_click=_enter,
    )

    return ft.Container(
        expand=True,
        bgcolor="#1e1e1e",
        alignment=ft.Alignment(0, 0),
        content=ft.Column(
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=12,
            scroll=ft.ScrollMode.AUTO,
            controls=[
                ft.Text("DSG", size=42, weight=ft.FontWeight.BOLD, color="#1472d0"),
                ft.Text("初识", size=16, color="#7a7a7a"),
                ft.Container(height=10),
                ft.GestureDetector(content=avatar_box, on_tap=lambda e: pick_files(page, picker, allow_multiple=False)),
                ft.TextButton("头像（选填）", on_click=lambda e: pick_files(page, picker, allow_multiple=False)),
                ft.Container(height=8),
                name_input,
                errors[0],
                gender_input,
                errors[1],
                birthday_input,
                errors[2],
                ft.Row(tight=True, spacing=10, alignment=ft.MainAxisAlignment.CENTER, controls=[progress, enter_btn]),
                ft.Text("性别与出生年月日只存在本机，不会给模型读取", size=11, color="#5f5f5f"),
            ],
        ),
    )


def _field(label: str, width: int) -> ft.TextField:
    return ft.TextField(
        label=label,
        width=width,
        filled=True,
        fill_color="#2a2a2a",
        border_radius=8,
        border_color="#3a3a3a",
        focused_border_color="#1472d0",
        border_width=1,
        focused_border_width=1,
        text_style=ft.TextStyle(size=14, color="white"),
        hint_style=ft.TextStyle(size=12, color="#6d6d6d"),
        label_style=ft.TextStyle(size=12, color="#9e9e9e"),
        content_padding=ft.Padding(left=12, right=12, top=10, bottom=10),
    )
