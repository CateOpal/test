"""右侧抽屉（NavigationDrawer）：角色信息面板。

点头部 Menu 图标从右侧滑出。里面有：
    角色头像（可改）/ 角色名（可改）/ 删除角色

这里**故意没有任何"拉黑 / 拒收"开关**。
她有没有把你拉黑，只能靠发出去的消息是不是带红叹号来判断 ——
一旦 UI 上摆了个按钮能查、能改，这个人的"黑盒感"就没了，
你面对的又变成了一个后台可读可写的聊天机器人。
"""

from __future__ import annotations

from typing import Any, Callable, Dict, Optional

import flet as ft

from ui.widgets import avatar, fire, pick_files, update_safe


class CharacterDrawer:
    def __init__(
        self,
        page: ft.Page,
        service,
        on_changed: Optional[Callable[[], Any]] = None,
        on_deleted: Optional[Callable[[str], Any]] = None,
        on_probe: Optional[Callable[[], Any]] = None,
        theme: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.page = page
        self.service = service
        self.on_changed = on_changed
        self.on_deleted = on_deleted
        self.on_probe = on_probe
        self.theme: Dict[str, Any] = dict(theme or {})
        self.current: Optional[str] = None

        self.avatar_box = ft.Container(alignment=ft.Alignment(0, 0), content=avatar("?"))
        self.name_input = ft.TextField(
            label="角色名",
            text_style=ft.TextStyle(size=14, color="#ffffff"),
            hint_style=ft.TextStyle(size=12, color="#6d6d6d"),
            label_style=ft.TextStyle(size=12, color="#9e9e9e"),
            border_radius=8,
            filled=True,
            fill_color="#2a2a2a",
            border_color="#3a3a3a",
            focused_border_color="#1472d0",
            border_width=1,
            focused_border_width=1,
            width=240,
            content_padding=ft.Padding(left=10, right=10, top=8, bottom=8),
        )
        self.tip = ft.Text("", size=11, color="#ff8a8a")
        self.info_text = ft.Text("", size=11, color="#9e9e9e")

        self.picker = ft.FilePicker(on_result=self._on_pick)
        try:
            if self.picker not in (page.services or []):
                page.services.append(self.picker)
        except Exception:  # noqa: BLE001
            pass

        # 只对测试角色出现：正常角色的主动开口必须由时间和他自己的判断决定，
        # 抽屉里摆个"立刻发一条"的按钮，等于把黑盒拆了。
        self.probe_tile = ft.ListTile(
            leading=ft.Icon(ft.Icons.BOLT_ROUNDED, color="#8ec7ff", size=20),
            title=ft.Text("让她现在开口", color="#8ec7ff", size=13),
            subtitle=ft.Text("调试用：立刻跑一遍主动消息", size=11, color="#8a8a8a"),
            visible=False,
            on_click=lambda e: self._probe(),
        )

        self.drawer = ft.NavigationDrawer(
            bgcolor=self.theme.get("drawer_color") or "#202020",
            controls=[
                ft.Container(height=16),
                ft.Column(
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    spacing=10,
                    controls=[
                        ft.GestureDetector(
                            content=self.avatar_box,
                            on_tap=lambda e: self._pick_image(),
                        ),
                        ft.TextButton("更换头像", on_click=lambda e: self._pick_image()),
                        self.name_input,
                        ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            spacing=10,
                            controls=[
                                ft.Button(
                                    content=ft.Text("保存修改", color="white"),
                                    bgcolor=self.theme.get("accent_color") or "#1472d0",
                                    on_click=lambda e: self._save(),
                                ),
                            ],
                        ),
                        self.tip,
                    ],
                ),
                ft.Container(height=8),
                ft.Divider(height=1, color="#2b2b2b"),
                ft.Container(height=8),
                self.info_text,
                self.probe_tile,
                ft.Container(expand=True),
                ft.Divider(height=1, color="#2b2b2b"),
                ft.ListTile(
                    leading=ft.Icon(ft.Icons.DELETE_OUTLINE, color="#ff8a8a"),
                    title=ft.Text("删除角色", color="#ff8a8a", size=13),
                    subtitle=ft.Text("备份后从数据库中彻底移除", size=11, color="#8a8a8a"),
                    on_click=lambda e: self._ask_delete(),
                ),
                ft.Container(height=10),
            ],
        )
        if hasattr(page, "end_drawer"):
            page.end_drawer = self.drawer

    # ---------------------------------------------------------------- 打开
    def open(self, char_id: str) -> None:
        self.current = char_id
        try:
            storage = self.service.registry.get(char_id)
            meta = storage.load("meta.json")
            name = meta.get("display_name") or char_id
            self.name_input.value = name
            self._render_avatar(name, meta.get("avatar_path") or "")
            rows = storage.load("state.json")
            self.info_text.value = (
                f"共 {int(rows.get('rounds') or 0)} 轮对话　"
                f"好感 {float((rows.get('relationship') or {}).get('affection') or 0):.2f}"
            )
            identity = storage.load("identity.json")
            self.probe_tile.visible = bool(identity.get("is_test_character"))
        except Exception as exc:  # noqa: BLE001
            self.name_input.value = char_id or ""
            self.info_text.value = ""
            self.probe_tile.visible = False
            self.tip.value = f"读取失败：{exc}"
        update_safe(self.probe_tile)
        self.tip.value = ""
        # Flet 1.0 的 page.show_end_drawer 是【无参协程】，抽屉靠 page.end_drawer 指定。
        # 直接 show_end_drawer(self.drawer) 会拿到一个没人 await 的协程就地蒸发 ——
        # 表现就是"点了 Menu 什么都没有"，必须走 fire() 调度。
        fire(self.page, self.page.show_end_drawer, error_hint="打开角色抽屉")

    def _render_avatar(self, name: str, path: str) -> None:
        self.avatar_box.content = avatar(name, path, 78)
        update_safe(self.avatar_box)

    # ---------------------------------------------------------------- 头像
    def _pick_image(self) -> None:
        try:
            pick_files(self.page, self.picker, allow_multiple=False, dialog_title="选一张图片作头像")
        except Exception as exc:  # noqa: BLE001
            self.tip.value = f"打不开文件选择器：{exc}"
            update_safe(self.tip)

    def _on_pick(self, e: ft.FilePickerResultEvent) -> None:
        files = getattr(e, "files", None) or []
        if not files or not self.current:
            return
        path = getattr(files[0], "path", "") or ""
        if not path:
            return
        try:
            storage = self.service.registry.get(self.current)
            meta = storage.load("meta.json")
            meta["avatar_path"] = path
            storage.save("meta.json", meta)
            storage.refresh_age()
            self._render_avatar(meta.get("display_name") or self.current, path)
            self.tip.value = ""
        except Exception as exc:  # noqa: BLE001
            self.tip.value = f"保存头像失败：{exc}"
        update_safe(self.tip)
        self._notify()

    # ---------------------------------------------------------------- 改名
    def _save(self) -> None:
        if not self.current:
            return
        new_name = (self.name_input.value or "").strip()
        if not new_name:
            self.tip.value = "角色名不能为空"
            update_safe(self.tip)
            return
        try:
            storage = self.service.registry.get(self.current)
            meta = storage.load("meta.json")
            old_name = str(meta.get("display_name") or "")
            if new_name != old_name and self.service.name_taken(new_name):
                self.tip.value = "已经有同名的角色了"
                update_safe(self.tip)
                return
            meta["display_name"] = new_name
            storage.save("meta.json", meta)
            # 主名写进 identity：用户改的是"她叫什么"，但法定主名同步更新才一致
            identity = storage.load("identity.json")
            identity["char_display_name"] = new_name
            storage.save("identity.json", identity)
            self.tip.value = "已保存"
        except Exception as exc:  # noqa: BLE001
            self.tip.value = f"保存失败：{exc}"
        update_safe(self.tip)
        self._notify()

    # ---------------------------------------------------------------- 删除
    def _ask_delete(self) -> None:
        if not self.current or not self.on_deleted:
            return
        char_id = self.current
        name = (self.name_input.value or "").strip() or char_id
        self.tip.value = ""
        self._close()
        fire(self.page, self.on_deleted, char_id, name, error_hint="删除角色")

    # ---------------------------------------------------------------- 调试
    def _probe(self) -> None:
        """测试角色专用：立刻请求一次主动开口（走完整的 ⑩→⑨）。"""
        if not self.current or not self.on_probe:
            return
        self._close()
        fire(self.page, self.on_probe, error_hint="触发主动消息")

    def _close(self) -> None:
        try:
            self.drawer.open = False
            update_safe(self.drawer)
        except Exception:  # noqa: BLE001
            pass

    def _notify(self) -> None:
        if self.on_changed:
            fire(self.page, self.on_changed, error_hint="刷新角色列表")
