"""主界面：左侧图标栏 + partners 列表 + 右侧消息区。

界面层只做两件事：把用户输入交给服务层，把服务层吐出来的东西按 ⑨ 给的节奏播出来。
界面不知道"对方在吃醋"，它只知道有一条新消息要延迟 1200ms 出现。

也因此，界面**没有**任何能查看或修改"她有没有拉黑我"的开关 ——
这件事只能靠发出去的消息是不是带红叹号来感知。
"""

from __future__ import annotations

import asyncio
from typing import Any, Dict, List, Optional

import flet as ft

from config import WINDOW_HEIGHT, WINDOW_TITLE, WINDOW_WIDTH
from core import settings as theme_store
from service import DSPService
from ui.chat_list import build_dividers, build_left_panel, build_partners_panel, render_partners
from ui.chat_window import ChatPane
from ui.dialogs import AccountDialog, ConfirmDialog, CreateCharacterDialog, SettingsDialog, StateDialog
from ui.drawer import CharacterDrawer
from ui.login_window import build_login_view
from ui.widgets import background, fire, update_safe


class DSPApp:
    def __init__(self, page: ft.Page, service: Optional[DSPService] = None) -> None:
        self.page = page
        self.service = service or DSPService()
        self.current: Optional[str] = None
        self.speed = 1.0
        self._filter = ""

        try:
            self.theme: Dict[str, Any] = theme_store.load_theme(self.service.data_dir)
        except Exception:  # noqa: BLE001
            self.theme = dict(theme_store.DEFAULT_THEME)
        # 服务层也持有同一份 dict，设置面板改完后两边是同一个对象
        self.service.theme = self.theme

        self.chat = ChatPane(
            on_send=self._on_send,
            speed=self.speed,
            on_menu=self._open_drawer,
            on_recall=self._recall_last_user,
            theme=self.theme,
        )
        self.partners_panel, self.search_field, self.partners_view = build_partners_panel(self.theme)
        self.search_field.on_change = self._on_search
        self.left_panel = build_left_panel(
            on_chats=self._focus_chats,
            on_add=self._open_create,
            on_settings=self._open_settings,
            on_account=self._open_account,
            theme=self.theme,
        )

        self.vertical_divider, self.divider = build_dividers()
        self.right_area = ft.Container(expand=True, content=self._placeholder())
        self.root = ft.Row(
            expand=True,
            spacing=0,
            controls=[
                self.left_panel,
                self.vertical_divider,
                self.partners_panel,
                self.vertical_divider,
                self.right_area,
            ],
        )
        # 外壳：登录页和主界面共用同一个位置，登录完原地切换
        self.body = ft.Container(expand=True, content=self.root)

        self.create_dialog = CreateCharacterDialog(page, self.service, self._after_create)
        self.settings_dialog = SettingsDialog(page, self.service, self._on_speed, on_theme=self._apply_theme)
        self.state_dialog = StateDialog(page, self.service)
        self.confirm_dialog = ConfirmDialog(page)
        self.account_dialog = AccountDialog(page, self.service, self.refresh_list)
        self.drawer = CharacterDrawer(
            page,
            self.service,
            on_changed=self._after_drawer_change,
            on_deleted=self._ask_delete,
            on_probe=self._force_proactive,
            theme=self.theme,
        )

        self.service.subscribe(self._on_proactive)

    # ---------------------------------------------------------------- 装配
    async def mount(self) -> None:
        page = self.page
        page.title = WINDOW_TITLE
        page.padding = 0
        try:
            page.window.width = WINDOW_WIDTH
            page.window.height = WINDOW_HEIGHT
            page.window.min_width = 760
            page.window.min_height = 520
        except Exception:  # noqa: BLE001
            pass
        self._apply_theme(self.theme, repaint_page=False)

        try:
            await page.add_async(self.body)
        except Exception:  # noqa: BLE001
            page.add(self.body)

        # 没有用户档案 → 先登录建档（名字会作为【绝对身份认知】注入给 ①）
        if not self.service.has_account():
            self.body.content = build_login_view(page, self._on_login)
            update_safe(self.body)
            update_safe(page)
            return
        await self._enter_main()

    async def _on_login(self, form: Dict[str, Any]) -> None:
        """登录页回调：写档案 → 进入主界面 → 挂后台生命。"""
        self.service.create_account(
            form.get("display_name") or "",
            gender=form.get("gender") or "",
            birthday=form.get("birthday") or "",
            avatar_path=form.get("avatar_path") or "",
        )
        self.chat._user_avatar = form.get("avatar_path") or ""
        self.body.content = self.root
        update_safe(self.body)
        try:
            await self._enter_main()
        except Exception as exc:  # noqa: BLE001
            # 至少让人进得去，后台起不来不要拦在门口
            print(f"[UI] 后台生命启动失败，但已放行进界面：{exc}")
        self.refresh_list()
        update_safe(self.body)
        update_safe(self.page)

    async def _enter_main(self) -> None:
        await self.service.start_background()
        self.refresh_list()

    def _placeholder(self) -> ft.Control:
        return ft.Container(
            expand=True,
            alignment=ft.Alignment(0, 0),
            content=ft.Column(
                alignment=ft.MainAxisAlignment.CENTER,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=8,
                controls=[
                    ft.Icon(ft.Icons.CHAT_BUBBLE_OUTLINE, size=48, color="#3a3a3a"),
                    ft.Text("还没有伙伴", size=16, color="#7a7a7a"),
                    ft.Text("点左下角的 ＋ 创建一个角色", size=12, color="#5f5f5f"),
                ],
            ),
        )

    # ---------------------------------------------------------------- 主题
    def _apply_theme(self, theme: Dict[str, Any], repaint_page: bool = True) -> None:
        self.theme = dict(theme or {})
        try:
            if isinstance(self.service.theme, dict):
                self.service.theme.clear()
                self.service.theme.update(self.theme)
            else:
                self.service.theme = dict(self.theme)
        except Exception:  # noqa: BLE001
            pass

        page = self.page
        try:
            page.bgcolor = self.theme.get("bg_color") or "#1e1e1e"
            page.theme_mode = ft.ThemeMode.DARK
            image = background(self.theme.get("bg_image") or "")
            if image is not None:
                page.decoration = ft.BoxDecoration(image=image)
            elif page.decoration is not None:
                page.decoration = None
        except Exception:  # noqa: BLE001
            pass

        self.chat.apply_theme(self.theme)
        self.left_panel.bgcolor = self.theme.get("panel_color") or "#252526"
        self.partners_panel.bgcolor = self.theme.get("panel_color") or "#252526"
        self.drawer.drawer.bgcolor = self.theme.get("drawer_color") or "#202020"
        update_safe(self.left_panel)
        update_safe(self.partners_panel)
        if repaint_page:
            update_safe(page)

    # ---------------------------------------------------------------- 列表
    def refresh_list(self) -> None:
        storages = []
        for char_id in self.service.char_ids():
            try:
                storages.append(self.service.registry.get(char_id))
            except Exception:  # noqa: BLE001
                continue
        if self._filter:
            storages = [
                s for s in storages
                if self._filter.lower() in str(s.load("meta.json").get("display_name") or "").lower()
            ]
        render_partners(self.partners_view, storages, self._select)
        update_safe(self.partners_view)

    def _on_search(self, e=None) -> None:
        self._filter = (self.search_field.value or "").strip()
        self.refresh_list()

    def _focus_chats(self) -> None:
        self._filter = ""
        self.search_field.value = ""
        update_safe(self.search_field)
        self.refresh_list()

    def _select(self, char_id: str) -> None:
        self.current = char_id
        self.service.mark_read(char_id)
        storage = self.service.registry.get(char_id)
        storage.refresh_age()
        identity = storage.load("identity.json")
        meta = storage.load("meta.json")
        self.chat.attach(self.page)
        self.right_area.content = self.chat.view
        self.chat.load_history(
            self.service.history(char_id),
            identity.get("char_display_name") or char_id,
            self._subtitle(char_id),
            user_avatar=self.service.user_avatar(),
            char_avatar=meta.get("avatar_path") or "",
        )
        # 被删好友的话，进来就是灰的
        status = self.service.status_of(char_id)
        try:
            deleted = status == "deleted"
            if deleted:
                self.chat.set_read_only(True)
            else:
                self.chat.set_read_only(False)
                update_safe(self.right_area)
        except Exception:  # noqa: BLE001
            pass
        update_safe(self.right_area)
        self.refresh_list()

    def _subtitle(self, char_id: str) -> str:
        try:
            state = self.service.registry.get(char_id).load("state.json")
        except Exception:  # noqa: BLE001
            return ""
        emo = state.get("emotion") or {}
        rel = state.get("relationship") or {}
        return (
            f"{emo.get('label') or ''}　好感 {float(rel.get('affection') or 0):.2f}"
            f"　信任 {float(rel.get('trust') or 0):.2f}"
        )

    # ---------------------------------------------------------------- 发送
    def _on_send(self, text: str, image: str = "") -> None:
        if not self.current:
            self.chat.push_notice("先在左边选一个伙伴")
            return
        char_id = self.current
        self.chat.push_user(text, image)
        self.page.run_task(self._run_round, char_id, text, image)

    async def _run_round(self, char_id: str, text: str, image: str = "") -> None:
        async def _done(result: Dict[str, Any]) -> None:
            await self.chat.play_round(result, name=self.service.name_of(char_id))
            self.chat.set_title(self.service.name_of(char_id), self._subtitle(char_id))
            self.refresh_list()

        try:
            await self.service.send(char_id, text, _done, image_path=image)
        except Exception as exc:  # noqa: BLE001
            self.chat.push_notice(f"这一轮跑挂了：{exc}")

    async def _recall_last_user(self) -> None:
        """用户撤回了上一句 —— 让 ③ 号决定她是装作没看见还是追问。"""
        if not self.current:
            return
        try:
            self.service.recall_user_message(self.current)
        except Exception as exc:  # noqa: BLE001
            self.chat.push_notice(f"撤回失败：{exc}")

    # ---------------------------------------------------------------- 主动开口
    async def _on_proactive(self, char_id: str, messages: List[Dict[str, Any]], meta: Dict[str, Any]) -> None:
        name = self.service.name_of(char_id)
        if char_id != self.current:
            self.service.bump_unread(char_id)
            self.refresh_list()
            await self._notify(name, messages)
            return
        await self.chat.play_round({"messages": messages}, name=name)
        self.chat.set_title(name, self._subtitle(char_id))
        self.refresh_list()

    async def _notify(self, name: str, messages: List[Dict[str, Any]]) -> None:
        """她主动开口时，人不在这个会话里也得让你知道。

        以前这里只往 pubsub 丢一条消息，可全项目没有任何订阅者 ——
        结果就是"她明明发了，你什么都没看见，只有左侧列表悄悄多了个红点"。
        """
        text = ""
        for item in messages:
            if isinstance(item, dict):
                text = str(item.get("text") or "")
                if text:
                    break
        try:
            self.page.pubsub.send_all({"title": name, "text": text[:40]})
        except Exception:  # noqa: BLE001
            pass
        if text:
            self._toast(f"{name}：{text[:36]}")

    def _toast(self, text: str) -> None:
        try:
            self.page.show_dialog(
                ft.SnackBar(
                    content=ft.Text(text, size=13, color="#ffffff"),
                    bgcolor=self.theme.get("accent_color") or "#1472d0",
                    duration=5000,
                    behavior=ft.SnackBarBehavior.FLOATING,
                )
            )
        except Exception:  # noqa: BLE001
            try:
                self.page.open(ft.SnackBar(content=ft.Text(text, size=13)))
            except Exception:  # noqa: BLE001
                pass

    # ---------------------------------------------------------------- 各种弹窗
    def _open_create(self) -> None:
        self.create_dialog.open()

    def _after_create(self, char_id: str) -> None:
        self.refresh_list()
        self._select(char_id)

    def _open_settings(self) -> None:
        self.settings_dialog.open()

    def _on_speed(self, value: float) -> None:
        self.speed = value
        self.chat.speed = value

    def _open_state(self) -> None:
        if self.current:
            self.state_dialog.open(self.current)

    # ---------------------------------------------------------------- 抽屉 / 删除
    def _open_drawer(self) -> None:
        if not self.current:
            self.chat.push_notice("先在左边选一个伙伴")
            return
        self.drawer.open(self.current)

    # ---------------------------------------------------------------- 调试
    def _force_proactive(self) -> None:
        """调试入口：不等 ⑦ 的等待，立刻让她走一遍 ⑩→⑨。

        只有 identity 里带 is_test_character 的角色才会在抽屉里看到这个按钮，
        正常角色依然只能靠时间与她自己的判断开口。
        """
        if not self.current:
            return
        char_id = self.current
        self.chat.push_notice("调试：正在让她主动开口…")
        fire(self.page, self._run_force, char_id, error_hint="主动消息")

    async def _run_force(self, char_id: str) -> None:
        try:
            await self.service.force_proactive(char_id, reason="调试：手动触发一次主动开口")
        except Exception as exc:  # noqa: BLE001
            self.chat.push_notice(f"主动消息失败：{exc}")

    def _after_drawer_change(self) -> None:
        char_id = self.current
        self.refresh_list()
        if char_id:
            self._select(char_id)

    def _ask_delete(self, char_id: str, name: str) -> None:
        async def _run() -> None:
            try:
                target = await self.service.delete_character(char_id)
            except Exception as exc:  # noqa: BLE001
                self.chat.push_notice(f"删除失败：{exc}")
                return
            if self.current == char_id:
                self.current = None
                self.right_area.content = self._placeholder()
                update_safe(self.right_area)
            self.refresh_list()
            hint = f"已删除「{name}」，数据备份到 {target}" if target else f"已删除「{name}」"
            self.chat.push_notice(hint)

        self.confirm_dialog.open(
            f"确定删除「{name}」吗？\n她的全部记忆会被打包备份后移除，此操作不可撤销。",
            lambda: fire(self.page, _run, error_hint="删除角色"),
        )

    def _open_account(self) -> None:
        self.account_dialog.open()

    # ---------------------------------------------------------------- 退出
    async def dispose(self) -> None:
        self.service.unsubscribe(self._on_proactive)
        try:
            await self.service.stop_background()
        except Exception:  # noqa: BLE001
            pass


async def _app_main(page: ft.Page) -> None:
    app = DSPApp(page)
    try:
        page.on_close = lambda e: asyncio.ensure_future(app.dispose())
    except Exception:  # noqa: BLE001
        pass
    await app.mount()


def run(view: str = "desktop") -> None:
    """入口：python main.py

    view = desktop（桌面窗口，默认） | hidden（无窗口，只跑后台生命）
    """
    app_view = ft.AppView.FLET_APP
    if view == "hidden":
        app_view = ft.AppView.FLET_APP_HIDDEN
    try:
        ft.run(_app_main, name=WINDOW_TITLE, view=app_view)
    except TypeError:  # 老版本签名不带 name/view
        ft.run(_app_main)
