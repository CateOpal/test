"""应用服务层：把"存储 / 数据库 / 17 个 API / 后台生命"装配成一个可调用的对象。

UI（Flet）和 CLI 都只跟它打交道：
    service.create_character(...)   创建角色并立刻在后台活过来
    await service.send(cid, text)   走完一轮流水线
    service.subscribe(cb)           注册"角色主动开口"的回调

这一层同样不做语义判断，只做装配与转发。
"""

from __future__ import annotations

import asyncio
import shutil
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from config import DATA_DIR, DEFAULT_USER_NAME, USER_ID
from core import account as account_store
from core import defaults, timeutil
from core.database import CharacterDB
from core.llm import DeepSeekClient
from core.scheduler import LifeManager
from core.storage import CharacterRegistry, CharacterStorage


class CharacterForm:
    """创建角色时的一张表（UI 表单 / CLI 向导共用）。

    除姓名外全部允许留空 —— 留空的部分由 ⑭ 之外的"人设推导"自行补全，
    基础性格连 what 都不用给（`randomize=True` 时后端掷一次骰子给个倾向）。
    """

    def __init__(
        self,
        display_name: str,
        gender: str = "女",
        age: int = 24,
        birthday: str = "",
        base_persona: str = "",
        occupation: str = "",
        expertise: str = "",
        avatar_path: str = "",
        user_display_name: str = "",
        nationality: str = "",
        culture_boundary: str = "",
        avatar_note: str = "",
        randomize_persona: bool = False,
    ) -> None:
        self.display_name = display_name
        self.gender = gender
        self.age = age
        self.birthday = birthday
        self.base_persona = base_persona
        self.occupation = occupation
        self.expertise = expertise
        self.avatar_path = avatar_path
        self.user_display_name = user_display_name or DEFAULT_USER_NAME
        # 国籍：文化底色的取值范围；文化边界：圈子标签，进 ⑯ 号认知裁决
        self.nationality = nationality
        self.culture_boundary = culture_boundary
        # 头像画面的客观描述 → 作为外观暗示参与人设推导
        self.avatar_note = avatar_note
        self.randomize_persona = randomize_persona


class DSPService:
    def __init__(self, api_key: Optional[str] = None, data_dir: Optional[Path] = None) -> None:
        self.llm = DeepSeekClient(api_key=api_key) if api_key else DeepSeekClient()
        self.data_dir = Path(data_dir or DATA_DIR)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.registry = CharacterRegistry(self.data_dir, USER_ID)
        self.lives = LifeManager(self.registry, self.llm, self.emit)
        self._subscribers: List[Callable[[str, List[Dict[str, Any]], Dict[str, Any]], Any]] = []
        self.account: Optional[Dict[str, Any]] = account_store.load_account(self.data_dir)
        if self.account:
            self.lives.set_account(self.account)

    # ---------------------------------------------------------------- 用户本人
    def has_account(self) -> bool:
        return self.account is not None

    def create_account(
        self,
        display_name: str,
        gender: str = "",
        birthday: str = "",
        avatar_path: str = "",
        avatar_note: str = "",
    ) -> Dict[str, Any]:
        """登录页建档：名字会被注入 ① 的【绝对身份认知】，不再是写死的常量。

        注意 gender / birthday 只写进本地文件，**永远不会流向任何 Prompt**。
        """
        self.account = account_store.create_account(
            display_name,
            self.data_dir,
            gender=gender,
            birthday=birthday,
            avatar_path=avatar_path,
            avatar_note=avatar_note,
        )
        self.lives.set_account(self.account)
        return self.account

    def rename_user(self, display_name: str) -> Optional[Dict[str, Any]]:
        """改的是"你真叫这个名字"这份档案；她自己怎么称呼你是她的事（profile）。"""
        if not self.account:
            self.account = account_store.create_account(display_name, self.data_dir)
        else:
            self.account = account_store.update_account(
                self.data_dir, display_name=display_name
            )
        self.lives.set_account(self.account)
        return self.account

    def set_user_avatar(self, avatar_path: str, avatar_note: str = "") -> Optional[Dict[str, Any]]:
        if not self.account:
            return None
        self.account = account_store.update_account(
            self.data_dir, avatar_path=avatar_path, avatar_note=avatar_note
        )
        self.lives.set_account(self.account)
        return self.account

    def update_user_info(self, **fields: Any) -> Optional[Dict[str, Any]]:
        """账号面板：改名 / 换头像 / 改性别生日都可以走这里。"""
        if not self.account:
            return None
        self.account = account_store.update_account(self.data_dir, **fields)
        self.lives.set_account(self.account)
        return self.account

    def user_name(self) -> str:
        return (self.account or {}).get("display_name") or DEFAULT_USER_NAME

    def user_avatar(self) -> str:
        return (self.account or {}).get("avatar_path") or ""

    # ---------------------------------------------------------------- 订阅
    def subscribe(self, callback) -> None:
        """callback(char_id, messages, meta) —— 角色主动发消息时回调 UI。"""
        if callback not in self._subscribers:
            self._subscribers.append(callback)

    def unsubscribe(self, callback) -> None:
        if callback in self._subscribers:
            self._subscribers.remove(callback)

    async def emit(self, char_id: str, messages: List[Dict[str, Any]], meta: Dict[str, Any]) -> None:
        for callback in list(self._subscribers):
            result = callback(char_id, messages, meta)
            if asyncio.iscoroutine(result):
                await result

    # ---------------------------------------------------------------- 角色管理
    def char_ids(self) -> List[str]:
        return self.registry.char_ids()

    def name_of(self, char_id: str) -> str:
        try:
            return self.registry.get(char_id).load("meta.json").get("display_name") or char_id
        except Exception:  # noqa: BLE001
            return char_id

    def name_taken(self, display_name: str) -> bool:
        """创建前的重名检查 —— 同名角色很容易被用户误当成同一个人的两个会话。"""
        target = (display_name or "").strip()
        if not target:
            return False
        for char_id in self.registry.char_ids():
            try:
                meta = self.registry.get(char_id).load("meta.json")
            except Exception:  # noqa: BLE001
                continue
            if str(meta.get("display_name") or "").strip() == target:
                return True
        return False

    def create_character(self, form: CharacterForm) -> str:
        """按表单建一个角色。人设由模型翻译，做不到才回落到中性骨架。"""
        if not form.display_name.strip():
            raise ValueError("角色名不能为空")
        if self.name_taken(form.display_name):
            raise ValueError(f"已经有一个叫「{form.display_name.strip()}」的角色了")

        char_id = self.registry.next_char_id()
        expertise_list = [
            item.strip()
            for item in str(form.expertise or "").replace("，", ",").replace("、", ",").split(",")
            if item.strip()
        ]
        age = int(form.age or 24)

        persona = defaults.derive_persona(
            self.llm,
            form.gender,
            form.base_persona,
            form.occupation,
            expertise_list,
            age,
            nationality=form.nationality,
            culture_boundary=form.culture_boundary,
            avatar_note=form.avatar_note,
            randomize=form.randomize_persona,
        )
        template = defaults.skeleton_for(form.gender)
        template.update({k: v for k, v in persona.items() if v})
        if expertise_list:
            template["expertise"] = expertise_list
        if form.occupation:
            template["occupation"] = form.occupation

        files = defaults.build_defaults(
            USER_ID,
            char_id,
            form.display_name.strip(),
            gender=form.gender,
            age=age,
            birthday=form.birthday,
            base_persona=form.base_persona,
            occupation=form.occupation,
            expertise=expertise_list,
            template=template,
            user_display_name=form.user_display_name or self.user_name(),
            nationality=form.nationality,
            culture_boundary=form.culture_boundary,
            avatar_note=form.avatar_note,
            avatar_impression=persona.get("avatar_impression") or "",
        )
        files["meta.json"]["avatar_path"] = form.avatar_path or ""
        files["identity.json"]["expertise"] = expertise_list or template.get("expertise", [])
        files["identity.json"]["nationality"] = form.nationality or ""

        storage = CharacterStorage(self.data_dir, USER_ID, char_id)
        storage.init_defaults(files)

        # 模型建议的初始口头禅/特质先落进长期记忆，等待 ⑪ 号确认后再变成稳定特征
        suggestion = persona.get("traits_suggestion") or []
        if suggestion:
            candidates = storage.load("candidates.json")
            for item in suggestion:
                key = str(item).strip()
                if key:
                    candidates.setdefault("catchphrases", {})[key] = 1
            candidates["initial_suggestions"] = suggestion
            storage.save("candidates.json", candidates)
        return char_id

    async def create_character_async(self, form: CharacterForm) -> str:
        """UI 专用的非阻塞版本。

        人设推导要调一次 API、还要写七个 JSON。直接在点击事件里做这些，
        界面会僵住好几秒，看起来像卡死了 —— 丢到线程里跑，前台先动起来。
        """
        return await asyncio.to_thread(self.create_character, form)

    async def delete_character(self, char_id: str) -> Optional[Path]:
        """彻底删除角色 —— 删之前先把整份人生打包备份。

        UI 侧的删除是不可逆操作，而这份数据可能已经跑了好几百轮、
        积累了独有的口头禅和记忆钩子。直接 rmtree 太粗暴，
        这里先整目录拷进 backups/ 再删，至少留一条后悔的路。
        """
        life = self.lives.lives.pop(char_id, None)
        if life is not None and getattr(life, "_task", None):  # noqa: SLF001
            life._task.cancel()  # noqa: SLF001
        storage = self.registry.get(char_id)
        root = Path(storage.root).resolve()
        base = Path(self.data_dir).resolve() / "users" / USER_ID / "characters"
        if base not in root.parents and root.parent != base:
            raise ValueError("拒绝删除 data 目录之外的路径")

        backup_root = Path(self.data_dir).resolve() / "users" / USER_ID / "backups"
        backup_root.mkdir(parents=True, exist_ok=True)
        target = backup_root / f"{root.name}_{timeutil.now().strftime('%Y%m%d_%H%M%S')}"
        shutil.copytree(root, target, dirs_exist_ok=True)
        shutil.rmtree(root, ignore_errors=True)
        return target

    # ------------------------------------------------- 关系状态（只读给 UI）
    @staticmethod
    def relationship_status(char_id: str, storage) -> str:
        """UI 只看得懂这几种：normal / blocked / rejected / friend_removed / deleted。

        没有 setter —— 这四个状态**只能由 ⑤ 号关系演化 API 写入**，
        UI 上任何按钮都改不了。这是这套系统"黑盒感"的来源：
        用户不知道自己是不是被拉黑了，只有发消息看到红叹号才知道。
        """
        state = storage.load("state.json")
        status = str(state.get("relationship_status") or "").strip()
        if status in ("blocked", "rejected", "friend_removed", "deleted"):
            return status
        # 兼容旧数据：以前只有布尔位
        if state.get("is_blocked"):
            return "blocked"
        return "normal"

    def status_of(self, char_id: str) -> str:
        return self.relationship_status(char_id, self.registry.get(char_id))

    # ---------------------------------------------------------------- 撤回
    def recall_user_message(self, char_id: str) -> bool:
        """用户撤回上一句（2 秒窗口由 UI 把关），这里只负责删记录。"""
        storage = self.registry.get(char_id)
        db = CharacterDB(storage.db_path)
        msg_id = db.last_user_message_id()
        if not msg_id:
            return False
        return bool(db.recall_message(msg_id, by="user"))

    def recall_hint_of(self, row: Dict[str, Any]) -> str:
        by = row.get("extra") or ""
        return "你撤回了一条消息" if by == "user" else "对方撤回了一条消息"

    # ---------------------------------------------------------------- 对话
    async def send(
        self,
        char_id: str,
        text: str,
        on_result: Optional[Callable[[Dict[str, Any]], Any]] = None,
        image_path: str = "",
    ) -> None:
        """用户发一句话（可选带一张图）→ 防抖合并 → 走完流水线 → 回调 UI。

        回调收到的是 {"messages": [...], "codes": [...], "status": "normal|blocked|...", ...}
        """
        life = self.lives.get(char_id)

        async def _fire(merged: str) -> None:
            result = await life.engine.handle(merged, image_path=image_path)
            if on_result:
                maybe = on_result(result.as_dict())
                if asyncio.iscoroutine(maybe):
                    await maybe

        await life.engine.submit(text or "[图片]", _fire)

    async def start_background(self) -> None:
        """给所有已存在的角色挂上后台生命循环。"""
        await self.lives.start_all()

    async def stop_background(self) -> None:
        await self.lives.stop_all()

    # ---------------------------------------------------------------- 只读数据
    def history(self, char_id: str, limit: int = 200) -> List[Dict[str, Any]]:
        storage = self.registry.get(char_id)
        return CharacterDB(storage.db_path).list_messages(limit=limit)

    def summary(self, char_id: str) -> Dict[str, Any]:
        """给 UI 展示"这个生命现在是什么状态"。"""
        storage = self.registry.get(char_id)
        storage.refresh_age()
        identity = storage.load("identity.json")
        state = storage.load("state.json")
        counter = storage.load("counter.json")
        db = CharacterDB(storage.db_path)
        return {
            "user_name": self.user_name(),
            "identity": identity,
            "state": state,
            "counter": counter,
            "messages": db.count_messages(),
            "open_hooks": db.open_events(limit=20),
            "char_id": char_id,
        }

    def mark_read(self, char_id: str) -> None:
        storage = self.registry.get(char_id)
        meta = storage.load("meta.json")
        meta["unread_count"] = 0
        storage.save("meta.json", meta)

    def bump_unread(self, char_id: str) -> None:
        if char_id not in self.registry.char_ids():
            return
        storage = self.registry.get(char_id)
        meta = storage.load("meta.json")
        meta["unread_count"] = int(meta.get("unread_count") or 0) + 1
        meta["last_message_time"] = timeutil.now_str()
        storage.save("meta.json", meta)

    # ---------------------------------------------------------------- 一次性
    async def force_proactive(self, char_id: str, reason: str = "用户手动点了一次") -> None:
        life = self.lives.get(char_id)
        await life._proactive(  # noqa: SLF001
            {
                "action": "proactive",
                "proactive_intensity": {
                    "max_messages": 1,
                    "tone_restraint": 0.5,
                    "topic_hint": "",
                    "reason": reason,
                },
            },
            trigger_reason=reason,
        )
