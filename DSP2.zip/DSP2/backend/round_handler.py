"""单轮对话流水线（编排层）。

执行顺序：
  防抖合并 → 拉黑拦截 → ⓪ 路由 → 并行唤醒被选中的专家 → 写状态（纯数值）
  → ① 角色扮演 → ⑨ 发送策略 → 落库（buffer / messages.db / meta）

全流程没有任何一处 `if 用户很生气 then ...`。
后端不知道用户在不在生气，它只知道"⑤ 号专家给了 trust_delta = -0.2"。
"""

from __future__ import annotations

import asyncio
import time
from typing import Any, Callable, Dict, List, Optional, Tuple

from apis import build_apis
from apis.api01_roleplay import dump_guides
from apis.codes import MINIMAL_SET
from backend import context_builder as cb
from backend import state_writer as sw
from backend import thresholds
from config import DEBOUNCE_WINDOW, MAX_CONCURRENCY, SLOW_ANALYZE_EVERY
from core import timeutil
from core.account import api_view

# 每轮之外按频率补充的慢速分析（画像 / 特征演化）
SLOW_APIS = ("⑪", "⑭")


# 这四个值只能由 ⑤ 号写入。走到 pipeline 最前面时用来决定"这一轮到底让不让她看见"。
BREAK_STATES = ("blocked", "rejected", "friend_removed", "deleted")

REJECT_HINTS = {
    "blocked": "消息已发出，但被对方拒收了。",
    "rejected": "消息已发出，但被对方拒收了。",
    "friend_removed": "你还不是对方的朋友。",
}
DELETED_HINT = "对方已删除与你的全部对话，这里只能回看历史。"


def _read_break_status(state: Dict[str, Any]) -> str:
    """从 state 读关系破裂状态，兼容只存了 is_blocked 布尔位的旧数据。"""
    status = str(state.get("relationship_status") or "").strip()
    if status in BREAK_STATES:
        return status
    if state.get("is_blocked"):
        return "blocked"
    return "normal"


class RoundResult:
    def __init__(self) -> None:
        self.messages: List[Dict[str, Any]] = []
        self.blocked: bool = False
        self.codes: List[str] = []
        self.scene_intent: str = "normal"
        self.rounds: int = 0
        self.elapsed: float = 0.0
        self.text: str = ""
        # normal | blocked | rejected | friend_removed | deleted
        self.status: str = "normal"
        # 本轮实际被撤回的消息 id（⑨ 号决定撤回时才会有）
        self.recalled: List[int] = []
        self.image_path: str = ""

    def as_dict(self) -> Dict[str, Any]:
        return {
            "messages": self.messages,
            "blocked": self.blocked,
            "codes": self.codes,
            "scene_intent": self.scene_intent,
            "rounds": self.rounds,
            "elapsed": self.elapsed,
            "text": self.text,
            "status": self.status,
            "recalled": self.recalled,
            "image_path": self.image_path,
        }


class RoundEngine:
    """一个角色一份：负责把这一轮走完。"""

    def __init__(self, storage, llm, db, apis: Optional[Dict[str, Any]] = None, account: Optional[Dict[str, Any]] = None) -> None:
        self.storage = storage
        self.llm = llm
        self.db = db
        # 最后一道闸：无论谁传进来的是什么，引擎里存的只有白名单字段，
        # 性别 / 生日在这里连存在的机会都没有。
        self.account = api_view(account)
        self.apis = apis or build_apis(llm)
        self._pending: List[str] = []
        self._pending_task: Optional[asyncio.Task] = None
        self._last_input_ts: float = 0.0
        self._sem = asyncio.Semaphore(MAX_CONCURRENCY)
        # 本轮真正会播出去的消息（⑨ 排版结果，可能少于 draft），落库时按它分条
        self.result_messages: List[Dict[str, Any]] = []
        self.last_user_row_id: Optional[int] = None
        self.last_assistant_row_ids: List[int] = []

    # ---------------------------------------------------------------- 防抖
    async def submit(self, text: str, handler: Callable[[str], Any]) -> None:
        """用户连发碎句时合并成一条再处理（用户侧气泡已即时上屏，这里只合并给模型）。"""
        if not text.strip():
            return
        self._pending.append(text.strip())
        self._last_input_ts = time.time()
        if self._pending_task is None or self._pending_task.done():
            self._pending_task = asyncio.create_task(self._wait_and_fire(handler))

    async def _wait_and_fire(self, handler: Callable[[str], Any]) -> None:
        try:
            while True:
                await asyncio.sleep(DEBOUNCE_WINDOW)
                if time.time() - self._last_input_ts >= DEBOUNCE_WINDOW - 1e-6:
                    break
            merged = " / ".join(self._pending)
            self._pending = []
            await handler(merged)
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            print(f"[流水线异常] {exc}")

    # ---------------------------------------------------------------- 主流程
    async def handle(self, user_message: str, image_path: str = "") -> RoundResult:
        started = time.time()
        result = RoundResult()
        result.image_path = image_path or ""
        state = self.storage.load("state.json")
        state["last_user_message_time"] = timeutil.now_str()
        self.storage.save("state.json", state)

        break_status = _read_break_status(state)

        # 1) 关系破裂拦截 —— 被拉黑 / 被拒收 / 被删好友：这一轮她根本不会看到输入法亮起
        #    是否回到 normal 由 ⑤ 号结合她本人的性格决定，UI 上没有对应的按钮。
        if break_status in ("blocked", "rejected", "friend_removed"):
            if await self._try_unblock(user_message):
                state = self.storage.load("state.json")
                break_status = _read_break_status(state)
            if break_status in BREAK_STATES:
                hint = REJECT_HINTS.get(break_status, REJECT_HINTS["blocked"])
                result.blocked = True
                result.status = break_status
                result.messages = [{"text": hint, "delay_ms": 400, "kind": "reject"}]
                result.text = hint
                self.db.add_message("user", user_message)
                result.elapsed = time.time() - started
                return result

        # 1.5) 永久删除：连"发失败"都不算，这里是只读模式
        if break_status == "deleted":
            result.status = "deleted"
            result.blocked = True
            result.messages = [{"text": DELETED_HINT, "delay_ms": 200, "kind": "deleted"}]
            result.text = DELETED_HINT
            result.elapsed = time.time() - started
            return result

        # 1.8) 图片：转 base64 交给 ③ 号做意图识别，产出 image_context 再喂给 ①
        image_context = ""
        if image_path:
            image_context = await self._read_image(image_path)

        # 2) ⓪ 路由
        route = await self._route(user_message, has_image=bool(image_context))
        codes: List[str] = list(route.get("required_apis") or [])
        result.scene_intent = route.get("scene_intent") or "normal"
        if route.get("is_minimal"):
            codes = [c for c in codes if c in MINIMAL_SET] or list(MINIMAL_SET)

        # 3) 低频慢速 API 到了就补上
        counter = self.storage.load("counter.json")
        if counter.get("rounds", 0) - counter.get("last_slow_analyze", 0) >= SLOW_ANALYZE_EVERY:
            for code in SLOW_APIS:
                if code not in codes:
                    codes.append(code)

        codes.append("⑨")
        # 去重：路由可能也点了 ⑨，保留首次出现顺序即可
        seen: List[str] = []
        for code in codes:
            if code not in seen:
                seen.append(code)
        codes = seen
        result.codes = codes

        # 4) 并行唤醒专家（①⑨ 稍后单独跑）
        guides: Dict[str, Dict[str, Any]] = {}
        expert_codes = [c for c in codes if c not in ("①", "⑨")]
        payloads = [await self._payload_for(code, user_message, image_context=image_context) for code in expert_codes]
        outputs = await asyncio.gather(*[self._run_api(code, p) for code, p in zip(expert_codes, payloads)], return_exceptions=True)
        for code, output in zip(expert_codes, outputs):
            if isinstance(output, Exception):
                print(f"[{code}] 调用失败：{output}")
                continue
            guides[code] = output

        # 5) 写状态（纯数值 + 列表搬运）
        await self._persist(user_message, guides)

        # 6) 危机干预：⑧ 判定必须走出角色
        safety = guides.get("⑧") or {}
        if safety.get("block_output") and safety.get("crisis_reply"):
            final_text = str(safety["crisis_reply"])
            result.messages = [{"text": final_text, "delay_ms": 800, "kind": "crisis"}]
            result.text = final_text
            await self._save_round(user_message, final_text, result.scene_intent)
            result.elapsed = time.time() - started
            return result

        # 7) ① 角色扮演
        topic = guides.get("③") or {}
        needs_longform = bool(topic.get("needs_longform"))
        bundle = self._roleplay_bundle(
            user_message, guides, needs_longform, result.scene_intent,
            image_context=image_context or (topic.get("image_context") if isinstance(topic, dict) else ""),
        )
        try:
            draft = await asyncio.to_thread(self.apis["①"].run_bundle, bundle)
        except Exception as exc:  # noqa: BLE001
            draft = ""
            print(f"[① 失败] {exc}")
        if not draft:
            draft = "……"

        # 8) ⑨ 发送策略
        state = self.storage.load("state.json")
        max_messages = 3
        strategy = await self._run_api(
            "⑨",
            {
                "draft": draft,
                "max_messages": max_messages,
                "tone_restraint": (state.get("relationship") or {}).get("dependency", 0.3),
                "scene_intent": result.scene_intent,
                "emotion": (state.get("emotion") or {}).get("label", "平静"),
                # 让她能撤回：给她刚刚说出口的那些 id，她自己决定要不要抽走其中的一句
                "recent_message_ids": self._recent_assistant_ids(max_messages),
            },
            fallback_text=draft,
        )
        raw = strategy.get("messages") or [{"text": draft, "delay_ms": 600}]

        # 8.5) 处理撤回：⑨ 下发的 recall 动作在这里变成"物理删除 + 灰色提示"
        played, recalled = self._apply_recall_actions(raw)
        result.messages = played or [{"text": draft, "delay_ms": 600}]
        result.recalled = recalled
        result.text = " ".join(str(m.get("text") or "") for m in result.messages if m.get("text"))

        # 9) 落库（严格分条：真实发出的每一条各自一行）
        self.result_messages = result.messages
        await self._save_round(user_message, draft, result.scene_intent, image_path=result.image_path)
        counter = self.storage.load("counter.json")
        if counter.get("rounds", 0) - counter.get("last_slow_analyze", 0) >= SLOW_ANALYZE_EVERY:
            counter["last_slow_analyze"] = counter.get("rounds", 0)
            self.storage.save("counter.json", counter)
        result.rounds = counter.get("rounds", 0)
        result.elapsed = time.time() - started
        return result

    # ---------------------------------------------------------------- 拉黑 / 和解
    async def _try_unblock(self, user_message: str) -> bool:
        """拉黑后仍然读所有消息：由 ⑤ 结合性格决定要不要和好。"""
        payload = await self._payload_for("⑤", user_message)
        res = await self._run_api("⑤", payload)
        state = self.storage.load("state.json")
        changed = sw.apply_block_decision(state, res)
        if changed:
            self.storage.save("state.json", state)
        return changed and not state.get("is_blocked")

    async def _read_image(self, image_path: str) -> str:
        """把本地图片读成一串 base64 交给 ③ 号做意图识别。

        注意：当前配的 DeepSeek 文本模型并不接受图像输入，
        真要走通"看图"必须换成一个支持视觉的 OpenAI 兼容端点。
        这里不挑出身 —— 读得到就传，端点不支持时由 llm 层兜住降级。
        """
        try:
            import base64
            from pathlib import Path

            path = Path(image_path)
            if not path.exists():
                return ""
            data = await asyncio.to_thread(path.read_bytes)
            if len(data) > 8 * 1024 * 1024:
                return ""
            return base64.b64encode(data).decode("ascii")
        except Exception as exc:  # noqa: BLE001
            print(f"[识图降级] 读图失败（{exc}），本轮按纯文本处理。")
            return ""

    # ---------------------------------------------------------------- 路由
    async def _route(self, user_message: str, has_image: bool = False) -> Dict[str, Any]:
        payload = await self._payload_for("⓪", user_message)
        if has_image:
            payload["has_image"] = True
        return await self._run_api("⓪", payload)

    # ---------------------------------------------------------------- 统一调用入口
    async def _run_api(self, code: str, payload: Dict[str, Any], **kwargs) -> Dict[str, Any]:
        api = self.apis.get(code)
        if api is None:
            return {}

        def _call() -> Dict[str, Any]:
            if code == "⑨":
                return api.run(payload, **kwargs)
            return api.run(payload)

        async with self._sem:
            try:
                return await asyncio.to_thread(_call)
            except Exception as exc:  # noqa: BLE001
                print(f"[{code}] 异常：{exc}")
                return getattr(api, "FALLBACK", {}) or {}

    # ---------------------------------------------------------------- 构造 payload
    async def _payload_for(self, code: str, user_message: str, image_context: str = "") -> Dict[str, Any]:
        identity = self.storage.load("identity.json")
        state = self.storage.load("state.json")
        profile = self.storage.load("profile.json")
        recent = [
            {"role": m["role"], "text": m["text"]}
            for m in self.storage.recent_messages(8)
        ]
        recent_topics = [m["text"][:20] for m in self.storage.recent_messages(4)]
        hooks = self.db.open_events(limit=6)
        base = {
            "user_message": user_message,
            "recent_dialogue": recent,
            "clock": timeutil.clock_block(),
        }

        if code == "⓪":
            return {
                "user_message": user_message,
                "last_assistant_message": (recent[-1]["text"] if recent and recent[-1]["role"] == "assistant" else ""),
                "scene_snapshot": cb.scene_snapshot(state, recent_topics),
                "personality_snapshot": cb.personality_snapshot(identity),
            }
        if code == "②":
            return dict(base, user_profile_insight=profile.get("user_personality_insight", ""))
        if code == "③":
            payload = dict(
                base,
                current_topics=recent_topics,
                current_nickname=identity.get("active_nickname"),
                # 用户撤回上一句 → 交给 ③ 判断她是装没看见还是追问
                recall_event=getattr(self, "_recall_event", False),
            )
            if image_context:
                payload["image_base64"] = image_context
                payload["image_hint"] = "用户发来了一张图片，请描述画面里与对话相关的信息"
            return payload
        if code == "④":
            return dict(
                base,
                current_state=state.get("emotion"),
                personality={
                    "ocean": identity.get("personality_ocean"),
                    "attachment_style": identity.get("attachment_style"),
                },
            )
        if code == "⑤":
            return dict(
                base,
                current_relationship=state.get("relationship"),
                personality={
                    "ocean": identity.get("personality_ocean"),
                    "attachment_style": identity.get("attachment_style"),
                    "open_hooks": cb.open_hooks_text(hooks, 4),
                },
            )
        if code == "⑥":
            return dict(base, known_events=[e.get("event") for e in hooks][:6])
        if code == "⑧":
            return dict(
                base,
                character_persona=cb.persona_block(identity),
                relationship=cb.relationship_block(state, profile),
                sensitivity="unknown",
            )
        if code == "⑪":
            lines = [m["text"] for m in self.storage.recent_messages(12) if m.get("role") == "assistant"]
            return {
                "recent_character_lines": lines,
                "current_traits": (state.get("evolved_traits") or {}),
                "candidates": self.storage.load("candidates.json"),
                "user_style": profile.get("style_notes", ""),
            }
        if code == "⑭":
            return {
                "user_message": user_message,
                "recent_dialogue": recent,
                "known_profile": {
                    "insight": profile.get("user_personality_insight"),
                    "facts": profile.get("facts"),
                    "style_notes": profile.get("style_notes"),
                },
                "current_display_name": profile.get("display_name"),
                "clock": timeutil.clock_block(),
            }
        if code == "⑯":
            culture = identity.get("culture_profile") or {}
            return dict(
                base,
                topic=(recent_topics[-1] if recent_topics else ""),
                identity=culture,
                # 文化/圈子边界直接决定她在哪些话题上是圈内人
                culture_boundary=identity.get("culture_boundary") or [],
                blind_spots=list(culture.get("blind_spots") or []),
                current_age=identity.get("current_age"),
                occupation=identity.get("occupation"),
                expertise=identity.get("expertise"),
            )
        if code == "⑦":
            return dict(base, open_hooks=cb.open_hooks_text(hooks, 5), recent_topics=recent_topics)
        if code == "⑩":
            return dict(base, open_hooks=cb.open_hooks_text(hooks, 5), recent_topics=recent_topics)
        return dict(base)

    # ---------------------------------------------------------------- 写回
    async def _persist(self, user_message: str, guides: Dict[str, Dict[str, Any]]) -> None:
        identity = self.storage.load("identity.json")

        def mutate(state: Dict[str, Any]) -> Dict[str, Any]:
            if "④" in guides:
                sw.apply_char_emotion(state, guides["④"])
            penalty = 0.0
            safety = guides.get("⑧") or {}
            if safety.get("relationship_penalty"):
                penalty = thresholds.numeric(safety["relationship_penalty"], 0.0, 0.0, 0.3)
            if "⑤" in guides:
                sw.apply_relationship(state, guides["⑤"], extra_penalty=penalty)
                sw.apply_block_decision(state, guides["⑤"])
            if "⑮" in guides:
                sw.apply_consciousness(state, guides["⑮"])
            if "⑫" in guides:
                sw.apply_reflection(state, guides["⑫"])
            return state

        await self.storage.update("state.json", mutate)

        # 事件钩子入库（⑥）
        event = guides.get("⑥") or {}
        if event.get("event") and not event.get("event", "").startswith("（"):
            self.db.add_event(
                {
                    "event": event.get("event"),
                    "unresolved": event.get("unresolved"),
                    "hidden_fact": event.get("hidden_fact"),
                    "subtext": event.get("subtext"),
                    "arousal": event.get("arousal") or "normal",
                    "emotion_tag": event.get("emotion_tag"),
                    "event_type": event.get("event_type") or "chat",
                }
            )

        # 外号（③）
        nickname_accepted = None
        if "③" in guides:
            nickname_accepted = sw.apply_nickname(self.storage, guides["③"])
            timer_action = (guides["③"] or {}).get("timer_action") or {}
            if timer_action.get("intent") in ("set", "cancel"):
                self._handle_timer(timer_action)

        # 特征候选（⑪）
        if "⑪" in guides:
            sw.update_trait_candidates(self.storage, guides["⑪"])

        # 用户画像（⑭）
        if "⑭" in guides:
            new_name = sw.apply_user_facts(self.storage, guides["⑭"])
            if new_name:
                meta = self.storage.load("meta.json")
                meta["last_message_preview"] = f"（对方把名字改成了 {new_name}）"
                self.storage.save("meta.json", meta)

        # 记忆衰减（⑬）
        decay = guides.get("⑬") or {}
        if decay.get("archive_ids"):
            self.db.archive_events(list(decay["archive_ids"]))

    def _handle_timer(self, action: Dict[str, Any]) -> None:
        state = self.storage.load("state.json")
        timers = list(state.get("unresolved_timers") or [])
        if action.get("intent") == "set":
            minutes = max(1, int(action.get("minutes") or 10))
            execute_at = timeutil.iso(timeutil.now())
            timers.append(
                {
                    "task_id": f"t{int(time.time()*1000)}",
                    "created_at": timeutil.now_str(),
                    "execute_at": execute_at,
                    "delay_minutes": minutes,
                    "content": action.get("content") or "提醒一件事",
                }
            )
        else:
            content = str(action.get("content") or "")
            if content:
                timers = [t for t in timers if content not in str(t.get("content"))]
            elif timers:
                timers = timers[:-1]
        state["unresolved_timers"] = timers[-10:]
        self.storage.save("state.json", state)

    # ---------------------------------------------------------------- ① 的素材
    def _roleplay_bundle(
        self,
        user_message: str,
        guides: Dict[str, Dict[str, Any]],
        needs_longform: bool,
        scene_intent: str,
        image_context: str = "",
    ) -> Dict[str, Any]:
        identity = self.storage.load("identity.json")
        state = self.storage.load("state.json")
        profile = self.storage.load("profile.json")
        recent = self.storage.recent_messages(10)
        guides_text = dump_guides({k: v for k, v in guides.items() if k not in ("⑨",)})
        return {
            "identity_anchor_block": cb.identity_anchor_block(identity, profile, self.account),
            "persona_block": cb.persona_block(identity),
            "relationship_block": cb.relationship_block(state, profile),
            "state_block": cb.state_block(state),
            "clock_block": cb.clock_block(state),
            "recent_block": cb.recent_block(recent, limit=10),
            "guides_block": guides_text,
            "user_message": user_message,
            "char_name": identity.get("char_display_name") or "我",
            "speaking_style": cb.speaking_style(identity, state),
            "user_call": cb.user_call(profile, identity),
            "length_rule": thresholds.length_rule_for(scene_intent, needs_longform),
            "max_tokens": thresholds.max_tokens_for(scene_intent, needs_longform),
            # 图片经 ③ 号转化成的一段话，视觉底盘不支持时为空字符串
            "image_context": image_context or "",
        }

    # ---------------------------------------------------------------- 落库
    async def _save_round(
        self,
        user_message: str,
        reply: str,
        scene_intent: str,
        image_path: str = "",
    ) -> None:
        """落库 —— 严格分条。

        `self.result_messages` 是 ⑨ 号排版后**真正会播出去**的那几条。
        三条就写三行，绝不动再拼回去。
        """
        counter = self.storage.load("counter.json")
        counter["rounds"] = int(counter.get("rounds", 0)) + 1
        round_no = counter["rounds"]
        self.storage.save("counter.json", counter)

        rows: List[Dict[str, Any]] = [
            {"role": "user", "text": user_message, "round_no": round_no, "image_path": image_path or ""}
        ]
        played = [m for m in (self.result_messages or []) if m.get("text")]
        if played:
            for index, item in enumerate(played):
                rows.append(
                    {
                        "role": "assistant",
                        "text": str(item.get("text") or ""),
                        "round_no": round_no,
                        "seq": index,
                        "extra": scene_intent,
                    }
                )
        else:
            rows.append({"role": "assistant", "text": reply, "round_no": round_no, "seq": 0, "extra": scene_intent})
        group_id = self.db.new_group_id()
        for row in rows:
            row["group_id"] = group_id
        written = await asyncio.to_thread(self.db.add_message_batch, rows)
        # 第 0 条是用户消息，其后才是她说的；撤回时要用这些真实 id
        self.last_user_row_id = written[0] if written else None
        self.last_assistant_row_ids = written[1:]

        self.storage.append_buffer("user", user_message, round_no)
        for index, item in enumerate(played):
            self.storage.append_buffer("assistant", str(item.get("text") or ""), round_no)

        state = self.storage.load("state.json")
        state["rounds"] = round_no
        self.storage.save("state.json", state)

        preview = (played[-1].get("text") if played else reply) or ""
        meta = self.storage.load("meta.json")
        meta["last_message_preview"] = str(preview)[:30]
        meta["last_message_time"] = timeutil.now_str()
        self.storage.save("meta.json", meta)

    # ---------------------------------------------------------------- 撤回
    def _recent_assistant_ids(self, limit: int = 3) -> List[int]:
        try:
            rows = self.db.list_messages(limit=limit * 3)
        except Exception:  # noqa: BLE001
            return []
        ids = [int(r["id"]) for r in rows if r.get("role") == "assistant" and not r.get("is_deleted")]
        return ids[-limit:]

    def _apply_recall_actions(self, raw: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], List[int]]:
        """处理 ⑨ 下发的撤回动作：真删库 + 留一条灰色提示。"""
        played: List[Dict[str, Any]] = []
        recalled: List[int] = []
        for item in raw:
            if not isinstance(item, dict):
                continue
            if item.get("action") == "recall":
                target = item.get("target_msg_id")
                candidates = [int(t) for t in ([target] if target else self._recent_assistant_ids(1)) if t]
                for msg_id in candidates:
                    if self.db.recall_message(msg_id, by="character"):
                        recalled.append(msg_id)
                    else:
                        # 条件不足也不许崩，UI 侧会忽略这个动作
                        continue
                played.append({"action": "recall", "text": "", "hint": "对方撤回了一条消息", "delay_ms": int(item.get("delay_ms") or 700)})
                continue
            played.append(item)
        return played, recalled
