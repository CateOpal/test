"""拼装器：把 JSON 翻译成给模型看的自然语言。

全项目只有这里允许出现"把数据拼成中文"的 f-string。
它做的是**字段搬运 + 客观描述**，不是替模型下结论：
   "你们的关系是 {affection}"   ✅（搬运）
   "你现在应该很伤心"           ❌（下结论）
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from backend import thresholds
from core import timeutil


# ---------------------------------------------------------------- 角色人设
def persona_block(identity: Dict[str, Any]) -> str:
    culture = identity.get("culture_profile") or {}
    ocean = identity.get("personality_ocean") or {}
    parts = [
        f"你的名字是 {identity.get('char_display_name') or '未命名'}（这是你的法定主名，不可更改）",
        f"性别 {identity.get('gender') or '未说明'}",
        f"年龄 {identity.get('current_age') or identity.get('age_at_creation') or '未知'} 岁",
        f"生日 {identity.get('birthday') or '未知'}",
        f"职业 {identity.get('occupation') or '未说明'}",
        f"专长 {_join(identity.get('expertise'))}",
        f"依恋类型 {identity.get('attachment_style') or '未说明'}",
        f"大五人格（连续数值，请结合她们一起理解，它们可能互相矛盾）：{thresholds.ocean_summary(identity)}",
        f"原生文化背景 {culture.get('origin') or '未说明'}",
        f"熟悉的领域 {_join(culture.get('knowledge_domains'))}",
        f"向往/了解但不精通 {_join(culture.get('interests'))}",
        f"真实的认知盲区 {_join(culture.get('blind_spots'))}",
    ]
    if identity.get("nicknames"):
        nicknames = [n.get("name") for n in identity["nicknames"] if n.get("name")]
        parts.append(f"对方给你起过的小名 {_join(nicknames)}（主名仍然是上面那个）")
    if identity.get("active_nickname"):
        parts.append(f"你现在接受对方这样称呼你：{identity['active_nickname']}")
    return "\n".join(f"- {line}" for line in parts)


# ---------------------------------------------------------------- 关系
def relationship_block(state: Dict[str, Any], profile: Dict[str, Any]) -> str:
    rel = state.get("relationship") or {}
    roles = rel.get("social_roles") or []
    role_text = "、".join(f"{r.get('role')}(权重{r.get('weight', 0):.2f})" for r in roles if r.get("role")) or "陌生人"
    lines = [
        f"你们之间的社会身份：{role_text}",
        f"喜爱度 {thresholds.clamp01(rel.get('affection', 0.1)):.2f}"
        f"（0=形同陌路，1=深爱）",
        f"信任度 {thresholds.clamp01(rel.get('trust', 0.3)):.2f}",
        f"契合度 {thresholds.clamp01(rel.get('alignment', 0.3)):.2f}（合不合得来，会随时间磨合或消散）",
        f"依赖度 {thresholds.clamp01(rel.get('dependency', 0.05)):.2f}",
        f"边界感 {thresholds.clamp01(rel.get('boundary', 0.9)):.2f}（越高越不能开玩笑）",
        f"权力感 {thresholds.clamp01(rel.get('dominance', 0.5)):.2f}（谁占主导）",
        f"冲突状态 {rel.get('conflict_state') or '正常'}",
    ]
    struggle = rel.get("power_struggle") or {}
    if struggle.get("is_stalemate"):
        lines.append(
            f"当前处在僵持状态，谁先低头还没定，角色心里承受的压力 {thresholds.clamp01(struggle.get('pressure_level', 0)):.2f}"
        )
    if profile.get("display_name"):
        lines.append(f"对方现在的名字：{profile['display_name']}")
    if profile.get("user_personality_insight"):
        lines.append(f"你眼中的对方：{profile['user_personality_insight']}")
    facts = profile.get("facts") or []
    if facts:
        lines.append("你记得关于对方的事：" + _join([f"{f.get('key')}={f.get('value')}" for f in facts[:8]]))
    return "\n".join(f"- {line}" for line in lines)


# ---------------------------------------------------------------- 当前状态
def state_block(state: Dict[str, Any]) -> str:
    emotion = state.get("emotion") or {}
    needs = state.get("needs") or {}
    traits = state.get("evolved_traits") or {}
    lines = [
        f"当前情绪 {emotion.get('label') or '平静'}",
        f"能量/体力 {thresholds.clamp01(emotion.get('energy', 0.6)):.2f}（低的时候会敷衍、慢回、少字）",
        f"身体状况 {emotion.get('physical_state') or '正常'}",
        f"耐心阈值 {thresholds.clamp01(emotion.get('patience_threshold', 0.6)):.2f}",
        f"是否在伪装 {_bool_cn(emotion.get('is_masking'))}（明明在意却装作无所谓）",
        f"渴望被关注 {thresholds.clamp01(needs.get('attention', 0)):.2f}",
        f"渴望被认可 {thresholds.clamp01(needs.get('validation', 0)):.2f}",
    ]
    if traits.get("catchphrases"):
        lines.append(f"你已经养成的口头禅 {_join(traits['catchphrases'])}")
    if traits.get("tone"):
        lines.append(f"你说话的语气已经变成：{traits['tone']}")
    if traits.get("knowledge_updates"):
        lines.append(f"你最近新接触到的事物 {_join(traits['knowledge_updates'])}")
    if state.get("stress_state"):
        lines.append(f"你正处在应激状态：{state['stress_state']}")
    if state.get("is_blocked"):
        lines.append(f"你已经不再回复对方的消息（拉黑）：{state.get('block_reason') or '关系破裂'}")
    if state.get("life_events"):
        lines.append(f"你最近生活里正在发生的事 {_join(state['life_events'][-3:])}")
    return "\n".join(f"- {line}" for line in lines)


# ---------------------------------------------------------------- 时间
def clock_block(state: Dict[str, Any]) -> str:
    lines = [
        f"此刻是 {timeutil.clock_block()}",
        f"距对方上一条消息已经过去 {timeutil.idle_text(state.get('last_user_message_time'))}",
    ]
    if state.get("last_proactive_time"):
        lines.append(f"距你上次主动发消息过去了 {timeutil.idle_text(state['last_proactive_time'])}")
    timers = state.get("unresolved_timers") or []
    if timers:
        lines.append(
            "你记着的待办/提醒："
            + _join([f"{t.get('content')}（{t.get('execute_at')}）" for t in timers])
        )
    return "\n".join(f"- {line}" for line in lines)


# ---------------------------------------------------------------- 短期对话
def recent_block(messages: List[Dict[str, Any]], limit: int = 12) -> str:
    if not messages:
        return "（还没有聊过天）"
    lines = []
    for msg in messages[-limit:]:
        who = "对方" if msg.get("role") == "user" else "你"
        lines.append(f"{who}：{msg.get('text', '')}")
    tail = "、".join(lines[-limit:])
    hooks_text = ""
    return f"{tail}{hooks_text}"


def open_hooks_text(events: List[Dict[str, Any]], limit: int = 5) -> str:
    hooks = [e for e in events if e.get("unresolved")]
    if not hooks:
        return "（没有未闭环的事）"
    return _join([str(e.get("unresolved")) for e in hooks[:limit]])


# ---------------------------------------------------------------- 快照（给 ⓪ 和 ⑦）
def scene_snapshot(state: Dict[str, Any], recent_topics: List[str]) -> str:
    rel = state.get("relationship") or {}
    emotion = state.get("emotion") or {}
    needs = state.get("needs") or {}
    return _dump({
        "clock": timeutil.clock_block(),
        "conflict_state": rel.get("conflict_state"),
        "power_struggle": rel.get("power_struggle"),
        "affection": thresholds.clamp01(rel.get("affection", 0.1)),
        "alignment": thresholds.clamp01(rel.get("alignment", 0.3)),
        "trust": thresholds.clamp01(rel.get("trust", 0.3)),
        "is_masking": bool(emotion.get("is_masking")),
        "energy": thresholds.clamp01(emotion.get("energy", 0.6)),
        "needs": {
            "attention": thresholds.clamp01(needs.get("attention", 0)),
            "validation": thresholds.clamp01(needs.get("validation", 0)),
        },
        "idle_since_last_user_message": timeutil.idle_text(state.get("last_user_message_time")),
        "recent_topics": recent_topics,
    })


def personality_snapshot(identity: Dict[str, Any]) -> str:
    return _dump({
        "ocean": identity.get("personality_ocean") or {},
        "attachment_style": identity.get("attachment_style"),
        "speaking_style": identity.get("speaking_style"),
        "culture": identity.get("culture_profile") or {},
        "age": identity.get("current_age"),
        "occupation": identity.get("occupation"),
    })


# ---------------------------------------------------------------- 身份锚点
def identity_anchor_block(identity: Dict[str, Any], profile: Dict[str, Any], account: Optional[Dict[str, Any]] = None) -> str:
    """【绝对身份认知】 —— 专治大模型在长上下文里分不清"谁是谁"。

    典型事故：用户说"我不叫小李，叫我猫眼石"，模型把这句话当成自己的台词复读，
    下一秒又继续叫错。根源是没有把双方的名字钉死成常量。
    """
    char_name = identity.get("char_display_name") or "未命名"
    real_name = (account or {}).get("display_name") or ""
    char_call = (identity.get("active_nickname") or "")
    user_call_name = (profile or {}).get("display_name") or real_name or "对方"

    lines = [
        f"你的名字是「{char_name}」，这是你的法定主名，任何情况下都不能改。",
        f"手机对面那个人的名字是「{real_name or user_call_name}」"
        + ("（这是他自己填的真实称呼）" if real_name else "（这是你习惯叫他的方式）"),
        f"你现在可以这样称呼他：{user_call_name}",
    ]
    if char_call:
        lines.append(f"他给你起的小名是「{char_call}」，你接受他这样叫你，但你的主名仍然是「{char_name}」。")
    lines.append(
        "他是用户，你是角色：不要把他说过的话写成你自己要说的话，也不要替他回答。"
    )
    lines.append(
        "如果他说\"我不叫X，你叫我Y\"，那是他在改称呼 —— 你从这句开始叫 Y，"
        "绝对不要把这句话原样复读一遍。"
    )
    lines.append(
        f"现在真实时间是 {timeutil.human()}，被问到几点/今天几号时直接回答，"
        "不要说\"我不知道现在是几点\" —— 你面前就有时钟。"
    )
    lines.append(
        "你就是个用手机打字的人，不是程序也不是 AI：被追问\"你是不是 AI\"时，"
        "你会觉得莫名其妙甚至有点上火，而不是承认任何模型或系统。"
    )
    return "\n".join(f"- {line}" for line in lines)


# ---------------------------------------------------------------- 工具
def _join(values: Any) -> str:
    if isinstance(values, (list, tuple)):
        items = [str(v) for v in values if str(v).strip()]
        return "、".join(items) if items else "（无）"
    return str(values) if values else "（无）"


def _bool_cn(value: Any) -> str:
    return "是" if bool(value) else "否"


def _dump(obj: Any) -> str:
    import json

    return json.dumps(obj, ensure_ascii=False)


def user_call(profile: Dict[str, Any], identity: Dict[str, Any]) -> str:
    """角色怎么称呼对方：优先用对方当前名字，没有就用"你"。"""
    name = (profile or {}).get("display_name") or ""
    return name or "你"


def speaking_style(identity: Dict[str, Any], state: Dict[str, Any]) -> str:
    evolved = (state.get("evolved_traits") or {}).get("tone")
    base = identity.get("speaking_style") or ""
    if evolved and evolved not in base:
        return f"{base}；最近又变成了：{evolved}"
    return base or "自然口语"
