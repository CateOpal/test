"""纯数值映射层。

这里允许出现数学，不允许出现语义。
- 0~1 的钳制、delta 累加、max_tokens 映射、typing 延迟的时间缩放。
- **绝不允许**出现 `if 情绪 == '愤怒': ...` 这种判断，那是模型的事。
"""

from __future__ import annotations

from typing import Any, Dict, Optional

MAX_TOKENS_BY_SCENE = {
    "light": 120,     # 日常寒暄：短
    "normal": 220,    # 普通交流
    "heavy": 900,     # 表白/解释/承诺/分手：允许小作文
    "crisis": 400,    # 危机干预：真诚但不啰嗦
}

LENGTH_RULE_BY_SCENE = {
    "light": "日常寒暄，回复要极短，通常不超过 20 个字，可以只回一个词或一个语气词。",
    "normal": "普通聊天，像发微信一样分 1~3 句，总量控制在 60 字以内，除非对方问了具体问题。",
    "heavy": "当前是重大情境（表白/解释/承诺/分手/深谈），允许一次性说一大段话，"
             "把心里话说完整、说透，这是唯一允许长篇幅的时刻。",
    "crisis": "对方正处在极度脆弱的状态，请放下所有玩笑和角色扮演，真诚、简短、确定地回应。",
}

# 各情境下"正在输入…"的时间缩放
DELAY_SCALE_BY_SCENE = {"light": 0.6, "normal": 1.0, "heavy": 1.6, "crisis": 1.0}


def clamp01(value: Any, default: float = 0.5) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        number = default
    return max(0.0, min(1.0, number))


def apply_delta(current: Any, delta: Any, default: float = 0.5, low: float = 0.0, high: float = 1.0) -> float:
    """把模型给出的 delta 累加到当前值上再做钳制（后端唯一的'计算'）。"""
    base = clamp01(current, default)
    try:
        step = float(delta or 0.0)
    except (TypeError, ValueError):
        step = 0.0
    return max(low, min(high, base + step))


def max_tokens_for(scene_intent: str, needs_longform: bool = False) -> int:
    if needs_longform and scene_intent in ("normal", "heavy"):
        scene_intent = "heavy"
    return MAX_TOKENS_BY_SCENE.get(scene_intent, MAX_TOKENS_BY_SCENE["normal"])


def length_rule_for(scene_intent: str, needs_longform: bool = False) -> str:
    if needs_longform and scene_intent in ("normal", "heavy"):
        scene_intent = "heavy"
    return LENGTH_RULE_BY_SCENE.get(scene_intent, LENGTH_RULE_BY_SCENE["normal"])


def delay_scale_for(scene_intent: str) -> float:
    return DELAY_SCALE_BY_SCENE.get(scene_intent, 1.0)


def scaled_delay(delay_ms: Any, scene_intent: str, speed: float = 1.0) -> float:
    """把毫秒转成真实秒。speed<1 可以整体加快（演示或调试用）。"""
    try:
        raw = int(delay_ms or 800)
    except (TypeError, ValueError):
        raw = 800
    seconds = raw / 1000.0 * delay_scale_for(scene_intent)
    if speed and speed > 0:
        seconds = seconds / speed
    return max(0.15, min(8.0, seconds))


def numeric(value: Any, default: float = 0.0, low: float = -1.0, high: float = 1.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        number = default
    return max(low, min(high, number))


def ocean_summary(identity: Dict[str, Any]) -> str:
    """把大五人格拼成一句客观描述（只拼接，不翻译语义）。"""
    ocean = identity.get("personality_ocean") or {}
    names = {
        "openness": "开放性",
        "conscientiousness": "尽责性",
        "extraversion": "外向性",
        "agreeableness": "宜人性",
        "neuroticism": "神经质",
    }
    parts = [f"{cn}={clamp01(ocean.get(key, 0.5)):.2f}" for key, cn in names.items()]
    return "、".join(parts)
