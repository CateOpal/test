"""把 API 的 JSON 结论写回状态文件。

规则：只做"数值累加 + 列表追加 + 字段赋值"。
这里不存在任何 `if 角色生气 then ...` 的分支 —— 结论本身来自模型，
落库只是搬运。唯一的例外是极少的纯数值钳制（不允许越过 0~1）。
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from backend import thresholds
from config import TRAIT_CONFIRM_COUNT
from core import timeutil

SOCIAL_ROLE_LIMIT = 6


# ------------------------------------------------------------------ ④ 角色情绪
def apply_char_emotion(state: Dict[str, Any], result: Dict[str, Any]) -> None:
    if not result:
        return
    emotion = state.setdefault("emotion", {})
    if result.get("emotion_label"):
        emotion["label"] = result["emotion_label"]
    if result.get("energy") is not None:
        emotion["energy"] = thresholds.clamp01(result["energy"], emotion.get("energy", 0.6))
    if result.get("physical_state"):
        emotion["physical_state"] = result["physical_state"]
    if result.get("patience_threshold") is not None:
        emotion["patience_threshold"] = thresholds.clamp01(
            result["patience_threshold"], emotion.get("patience_threshold", 0.6)
        )
    if "is_masking" in result:
        emotion["is_masking"] = bool(result["is_masking"])
    emotion["updated_at"] = timeutil.now_str()


# ------------------------------------------------------------------ ⑤ 关系演进
def apply_relationship(state: Dict[str, Any], result: Dict[str, Any], extra_penalty: float = 0.0) -> None:
    if not result:
        return
    rel = state.setdefault("relationship", {})
    pairs = (
        ("affection", "affection_delta", "affection"),
        ("trust", "trust_delta", "trust"),
        ("alignment", "alignment_delta", "alignment"),
        ("dominance", "dominance_delta", "dominance"),
        ("dependency", "dependency_delta", "dependency"),
        ("boundary", "boundary_delta", "boundary"),
    )
    for field, delta_key, _default in pairs:
        penalty = -abs(extra_penalty) if field in ("trust", "affection") else 0.0
        delta = result.get(delta_key)
        if delta is None and not penalty:
            continue
        rel[field] = thresholds.apply_delta(
            rel.get(field, 0.3), float(delta or 0.0) + penalty, default=0.3
        )

    if result.get("conflict_state"):
        rel["conflict_state"] = result["conflict_state"]
    struggle = result.get("power_struggle")
    if isinstance(struggle, dict):
        current = rel.setdefault("power_struggle", {})
        for key in ("is_stalemate", "who_blinks_first", "pressure_level"):
            if key in struggle:
                current[key] = struggle[key]
    rel["updated_at"] = timeutil.now_str()

    suggestion = result.get("social_role_suggestion")
    if isinstance(suggestion, dict) and suggestion.get("role"):
        update_social_role(state, str(suggestion["role"]), thresholds.clamp01(suggestion.get("weight", 0.5)))

    if result.get("stress_state"):
        state["stress_state"] = result["stress_state"]
    if "vulnerability_exposed" in result:
        state["vulnerability_exposed"] = bool(result["vulnerability_exposed"])


def update_social_role(state: Dict[str, Any], role: str, weight: float) -> None:
    rel = state.setdefault("relationship", {})
    roles: List[Dict[str, Any]] = rel.setdefault("social_roles", [])
    for item in roles:
        if item.get("role") == role:
            item["weight"] = round(weight, 2)
            item["is_active"] = True
            break
    else:
        roles.append({"role": role, "weight": round(weight, 2), "is_active": True})
    roles.sort(key=lambda r: r.get("weight", 0), reverse=True)
    rel["social_roles"] = roles[:SOCIAL_ROLE_LIMIT]


# ------------------------------------------------------------------ 拉黑 / 和解
def apply_block_decision(state: Dict[str, Any], result: Dict[str, Any]) -> bool:
    """返回 True 表示本轮状态发生了变化（用于 UI 提示）。"""
    changed = False
    should_block = bool(result.get("should_block"))
    if should_block and not state.get("is_blocked"):
        state["is_blocked"] = True
        state["block_reason"] = result.get("block_reason") or "关系彻底破裂"
        changed = True
    elif not should_block and state.get("is_blocked"):
        state["is_blocked"] = False
        state["block_reason"] = ""
        if (state.get("relationship") or {}).get("conflict_state") == "破裂":
            state["relationship"]["conflict_state"] = "磨合期"
        changed = True
    return changed


# ------------------------------------------------------------------ ⑪ 特征累计
def update_trait_candidates(storage, result: Dict[str, Any]) -> None:
    """候选三次命中才转正：计数是纯数值统计，判定出自 ⑪。"""
    if not result:
        return
    candidates = storage.load("candidates.json")
    catch = candidates.setdefault("catchphrases", {})
    today = timeutil.day_of_year_key()

    for phrase in result.get("catchphrase_candidates") or []:
        entry = catch.setdefault(phrase, {"count": 0, "first_seen": today, "last_seen": today})
        entry["count"] = int(entry.get("count", 0)) + 1
        entry["last_seen"] = today

    for phrase in result.get("discarded") or []:
        if phrase in catch and catch[phrase].get("count", 0) < 2:
            catch.pop(phrase, None)

    confirmed: List[str] = []
    for phrase, entry in list(catch.items()):
        if int(entry.get("count", 0)) >= TRAIT_CONFIRM_COUNT:
            confirmed.append(phrase)
    storage.save("candidates.json", candidates)

    if confirmed:
        state = storage.load("state.json")
        traits = state.setdefault("evolved_traits", {"catchphrases": [], "tone": "", "knowledge_updates": []})
        bucket = traits.setdefault("catchphrases", [])
        for phrase in confirmed:
            if phrase not in bucket:
                bucket.append(phrase)
        bucket[:] = bucket[-8:]
        storage.save("state.json", state)
        for phrase in confirmed:
            catch.pop(phrase, None)
        storage.save("candidates.json", candidates)

    if result.get("tone_shift"):
        state = storage.load("state.json")
        traits = state.setdefault("evolved_traits", {})
        if traits.get("tone") != result["tone_shift"]:
            traits["tone"] = result["tone_shift"]
            storage.save("state.json", state)

    for item in result.get("knowledge_updates") or []:
        state = storage.load("state.json")
        traits = state.setdefault("evolved_traits", {})
        bucket = traits.setdefault("knowledge_updates", [])
        if item not in bucket:
            bucket.append(item)
            bucket[:] = bucket[-12:]
            storage.save("state.json", state)


# ------------------------------------------------------------------ ⑭ 用户画像
def apply_user_facts(storage, result: Dict[str, Any]) -> Optional[str]:
    """返回改名后的新名字（如有），供 UI 更新列表。"""
    if not result:
        return None
    profile = storage.load("profile.json")
    if result.get("personality_insight"):
        profile["user_personality_insight"] = result["personality_insight"]
    if result.get("style_notes"):
        profile["style_notes"] = result["style_notes"]

    known = {str(f.get("key")): f for f in (profile.get("facts") or [])}
    for fact in result.get("facts") or []:
        key = str(fact.get("key"))
        if not key:
            continue
        known[key] = fact
    profile["facts"] = list(known.values())[-40:]

    new_name = None
    change = result.get("name_change") or {}
    if change.get("changed") and change.get("value"):
        new_name = str(change["value"])
        if not change.get("kind"):
            change["kind"] = "meaningful"
        history = profile.setdefault("display_name_history", [])
        if new_name != profile.get("display_name"):
            history.append({"value": new_name, "changed_at": timeutil.now_str(), "kind": change.get("kind")})
            profile["display_name"] = new_name
    profile["last_updated"] = timeutil.now_str()
    storage.save("profile.json", profile)
    return new_name


# ------------------------------------------------------------------ ③ 外号
def apply_nickname(storage, topic_result: Dict[str, Any]) -> Optional[str]:
    action = (topic_result or {}).get("nickname_action") or {}
    raw = (action.get("raw") or "").strip()
    if not raw or action.get("kind") in (None, "none"):
        return None
    identity = storage.load("identity.json")
    nicknames = identity.setdefault("nicknames", [])
    exists = False
    for item in nicknames:
        if item.get("name") == raw:
            item["is_acceptable"] = bool(action.get("accept"))
            exists = True
            break
    if not exists:
        nicknames.append(
            {
                "name": raw,
                "kind": action.get("kind"),
                "is_acceptable": bool(action.get("accept")),
                "note": action.get("note") or "",
                "created_at": timeutil.now_str(),
            }
        )
    if action.get("accept"):
        identity["active_nickname"] = raw
    else:
        # 不接受的外号不会顶替当前小名
        pass
    identity["nicknames"] = nicknames[-10:]
    storage.save("identity.json", identity)
    return raw if action.get("accept") else None


# ------------------------------------------------------------------ ⑫ 反思
def apply_reflection(state: Dict[str, Any], result: Dict[str, Any]) -> None:
    if not result:
        return
    rel = state.setdefault("relationship", {})
    for field, key in (("affection", "affection_delta"), ("trust", "trust_delta"),
                       ("alignment", "alignment_delta"), ("dependency", "dependency_delta")):
        if result.get(key) is not None:
            rel[field] = thresholds.apply_delta(rel.get(field, 0.3), result[key], default=0.3)
    update = result.get("trait_update") or {}
    traits = state.setdefault("evolved_traits", {})
    if update.get("tone"):
        traits["tone"] = update["tone"]
    if update.get("add_catchphrase"):
        bucket = traits.setdefault("catchphrases", [])
        if update["add_catchphrase"] not in bucket:
            bucket.append(update["add_catchphrase"])
    if update.get("remove_catchphrase") in (traits.get("catchphrases") or []):
        traits["catchphrases"].remove(update["remove_catchphrase"])
    if update.get("knowledge_update"):
        bucket = traits.setdefault("knowledge_updates", [])
        if update["knowledge_update"] not in bucket:
            bucket.append(update["knowledge_update"])
    state["last_reflection_at"] = timeutil.now_str()


# ------------------------------------------------------------------ ⑮ 意识流
def apply_consciousness(state: Dict[str, Any], result: Dict[str, Any]) -> None:
    if not result:
        return
    emotion = state.setdefault("emotion", {})
    delta = result.get("emotion_delta") or {}
    if delta.get("energy_delta") is not None:
        emotion["energy"] = thresholds.apply_delta(emotion.get("energy", 0.6), delta["energy_delta"], default=0.6)
    if delta.get("label"):
        emotion["label"] = delta["label"]
    emotion["updated_at"] = timeutil.now_str()
    stream = state.setdefault("inner_stream", [])
    text = result.get("inner_monologue")
    if text:
        stream.append({"time": timeutil.now_str(), "text": text})
        state["inner_stream"] = stream[-20:]


# ------------------------------------------------------------------ 需求随时间上涨
def grow_needs(state: Dict[str, Any], elapsed_minutes: float) -> None:
    """需求池随时间自然上涨：没人理的时候，渴望关注会累加。"""
    needs = state.setdefault("needs", {"attention": 0.3, "validation": 0.3})
    hours = max(0.0, elapsed_minutes) / 60.0
    needs["attention"] = thresholds.clamp01(needs.get("attention", 0.3) + hours * 0.05)
    needs["validation"] = thresholds.clamp01(needs.get("validation", 0.3) + hours * 0.02)
