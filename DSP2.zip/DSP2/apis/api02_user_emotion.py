"""② 用户情绪与真实意图。

看穿嘴硬：用户说"我没事"，到底是没事还是在酸？这条结论会被原样塞进 ① 和 ⑤。
"""

from __future__ import annotations

from typing import Any, Dict

from apis.base import ApiBase, register

SYSTEM_PROMPT = """\
你是一位微表情（文字版）分析师。你的任务是判断对方这句表面上在说什么，实际想表达什么。
你不做评论、不给建议、不生成对话，只输出判断结果。

【输入】user_message（原文）、recent_dialogue（最近对话）、user_profile_insight（已知画像）、clock

【判断维度】
- 字面情绪 vs 真实情绪（嘴硬、反话、借题发挥、试探、求夸、阴阳怪气都算）
- 真实意图：倾诉 / 求安慰 / 求关注 / 质问 / 撒娇 / 开玩笑 / 敷衍 / 挑衅 / 告别 / 求助 等
- 是否伪装（is_masking）：明明在意却装作无所谓
- 强度（0~1）

【严格输出 JSON】
{
  "surface_emotion": "字面情绪",
  "real_emotion": "真实情绪，可与字面相同",
  "intent": "真实意图，一个词或短句",
  "is_masking": false,
  "intensity": 0.5,
  "evidence": "一句话说明判断依据（引用原文细节）"
}

注意：不要过度解读。如果用户真的只是在陈述事实，real_emotion 就等于 surface_emotion，\
is_masking 为 false。用户的性格底色（画像）会干扰表达方式，说话冷淡不一定代表不开心。
"""


@register
class UserEmotionAPI(ApiBase):
    code = "②"
    name = "用户情绪"
    system_prompt = SYSTEM_PROMPT
    max_tokens = 260

    FALLBACK: Dict[str, Any] = {
        "surface_emotion": "平静",
        "real_emotion": "平静",
        "intent": "日常交流",
        "is_masking": False,
        "intensity": 0.3,
        "evidence": "解析失败兜底",
    }

    def run(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        data = self.call_json(
            payload,
            required=["real_emotion", "intent"],
            fallback=dict(self.FALLBACK),
            max_tokens=self.max_tokens,
        )
        if not isinstance(data, dict):
            return dict(self.FALLBACK)
        for key, value in self.FALLBACK.items():
            data.setdefault(key, value)
        return data
