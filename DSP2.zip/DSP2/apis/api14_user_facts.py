"""⑭ 用户画像提炼（角色眼中的用户）。

注意是"这个角色眼中的用户"：同一个用户在不同角色那里会得到不同的画像。
它还负责捕获用户改名的历史 —— 名字要从 profile 里读，而不是读 UI 控件。
"""

from __future__ import annotations

from typing import Any, Dict, List

from apis.base import ApiBase, register

SYSTEM_PROMPT = """\
你是一位用户画像分析师，但请记住：你分析的是**这个角色眼中的那个人**。
同一句话，在不同性格的角色看来，画像可以完全不同。

【输入】user_message、recent_dialogue、known_profile（已知画像与事实）、\
current_display_name（用户当前名字）、clock

【抽取内容】
1. facts：稳定事实（职业、城市、作息、家庭、口味、口头禅、讨厌的东西……），\
   每条带 confidence（0~1）。不要臆测，宁缺毋滥。
2. personality_insight：一句人味儿的话概括对方是什么样的人（允许带偏见，因为这是角色的视角）。
3. name_change：对方是否在这轮**更换了称呼/自称**：
   - changed: true/false
   - value: 新名字
   - kind: meaningful（认真改的名字）| joke（闹着玩）| none
   只有对方明确表示"以后叫我 xx"/"我改名叫 xx"时才算 changed。
4. style_notes：对方的说话习惯（冷淡/爱发表情/句子很短/爱反问……），\
   用于让角色学会模仿对方的节奏 —— 这是"被用户影响"的另一条通道。

【严格输出 JSON】
{
  "facts": [{"key": "职业", "value": "程序员", "confidence": 0.9}],
  "personality_insight": "",
  "name_change": {"changed": false, "value": "", "kind": "none"},
  "style_notes": ""
}
"""


@register
class UserFactsAPI(ApiBase):
    code = "⑭"
    name = "用户画像"
    system_prompt = SYSTEM_PROMPT
    max_tokens = 360

    FALLBACK: Dict[str, Any] = {
        "facts": [],
        "personality_insight": "",
        "name_change": {"changed": False, "value": "", "kind": "none"},
        "style_notes": "",
    }

    def run(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        data = self.call_json(
            payload,
            required=["facts"],
            fallback=dict(self.FALLBACK),
            max_tokens=self.max_tokens,
        )
        if not isinstance(data, dict):
            return dict(self.FALLBACK)
        for key, value in self.FALLBACK.items():
            data.setdefault(key, value)
        facts: List[Dict[str, Any]] = []
        if isinstance(data.get("facts"), list):
            for item in data["facts"]:
                if not isinstance(item, dict):
                    continue
                key = str(item.get("key") or "").strip()
                value = str(item.get("value") or "").strip()
                if not key or not value:
                    continue
                try:
                    confidence = float(item.get("confidence", 0.6))
                except (TypeError, ValueError):
                    confidence = 0.6
                facts.append({"key": key, "value": value, "confidence": max(0.0, min(1.0, confidence))})
        data["facts"] = facts
        if not isinstance(data.get("name_change"), dict):
            data["name_change"] = dict(self.FALLBACK["name_change"])
        return data
