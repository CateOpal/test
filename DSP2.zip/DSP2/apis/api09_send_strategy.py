"""⑨ 发送策略（排版员 + 手滑模拟器）。

把 ① 生成的那段话，按"真人打字"的方式拆开：
- 日常寒暄的碎句分批发送，带 typing 延迟；
- 小作文场景合并成一整段长气泡，并加长"正在输入"的时间；
- 情绪上头时可能打错字、发完又撤回；
- max_messages 由 ⑦ 给出（冷战期再想说也只能发一条）。
"""

from __future__ import annotations

from typing import Any, Dict, List

from apis.base import ApiBase, register

SYSTEM_PROMPT = """\
你是一位聊天软件排版员，也是一个会手滑的普通人。
输入是一段角色想说的话，以及一些客观约束，你要把它切成"若干条真实消息"。

【输入】draft（① 生成的原文）、max_messages（这次最多发几条，由时机决策给出）、\
tone_restraint（0=放肆 1=卑微克制）、scene_intent、emotion（角色当前情绪）、\
recent_message_ids（她最近发过的消息 id，撤回时从这里挑）

【规则】
1. 总条数不得超过 max_messages。**如果 max_messages 为 1，无论原文多长，只能输出一条**，\
   可以适度压缩合并，但不要删掉情绪。
2. delay_ms 是"发出这条之前的打字犹豫"，单位毫秒。
   - 平淡/敷衍：400~1200
   - 犹豫/心虚/害羞：1500~4000
   - 生气/激动：200~800（手速快）
   - 长句按字数适当增加：大约每 15 字 300ms
3. 特殊情况可在数组里插入 {"action": "recall", "target_msg_id": 上一条的id}，表示"把刚发的那条撤回"。
   recent_message_ids 会给出她最近发过的消息 id，target_msg_id 必须从这里选。
   只在符合人设和情绪时使用（傲娇、心虚、说完就后悔），不要滥用。
   撤回之后通常会紧跟一句新的话（解释、装傻、岔开话题），也可以什么都不说。
4. 可以在情绪激动时轻微引入错别字/缺标点（typo），但必须保持可读。
5. heavy（表白/承诺/解释/分手）场景：合并成一整条长消息，delay 明显加长（3000~6000ms）。
6. 不要新增原文没有的内容，也不要给出解释性旁白。

【严格输出 JSON】
{
  "messages": [
    {"text": "第一条", "delay_ms": 1200},
    {"action": "recall", "target_msg_id": 128, "delay_ms": 600},
    {"text": "算了，没事。", "delay_ms": 3000}
  ]
}
"""


@register
class SendStrategyAPI(ApiBase):
    code = "⑨"
    name = "发送策略"
    system_prompt = SYSTEM_PROMPT
    max_tokens = 600

    FALLBACK: Dict[str, Any] = {"messages": [{"text": "", "delay_ms": 800}]}

    def run(self, payload: Dict[str, Any], fallback_text: str = "") -> Dict[str, Any]:
        data = self.call_json(
            payload,
            required=["messages"],
            fallback={"messages": [{"text": fallback_text, "delay_ms": 800}]},
            max_tokens=self.max_tokens,
        )
        if not isinstance(data, dict) or not isinstance(data.get("messages"), list):
            return {"messages": [{"text": fallback_text, "delay_ms": 800}]}
        return {"messages": self._sanitize(data["messages"], fallback_text, int(payload.get("max_messages") or 3))}

    @staticmethod
    def _sanitize(messages: List[Any], fallback_text: str, max_messages: int) -> List[Dict[str, Any]]:
        result: List[Dict[str, Any]] = []
        for item in messages:
            if isinstance(item, dict) and item.get("action") == "recall":
                # 撤回动作只在已经有消息之后才有意义
                if result:
                    entry: Dict[str, Any] = {"action": "recall", "delay_ms": 600}
                    target = item.get("target_msg_id")
                    if target not in (None, ""):
                        try:
                            entry["target_msg_id"] = int(target)
                        except (TypeError, ValueError):
                            pass
                    result.append(entry)
                continue
            if isinstance(item, dict) and item.get("text"):
                try:
                    delay = int(item.get("delay_ms") or 800)
                except (TypeError, ValueError):
                    delay = 800
                result.append({"text": str(item["text"]).strip(), "delay_ms": max(200, min(8000, delay))})
                continue
            if isinstance(item, str) and item.strip():
                result.append({"text": item.strip(), "delay_ms": 800})
        if not result:
            result = [{"text": fallback_text, "delay_ms": 800}]
        if len(result) > max_messages:
            result = result[:max_messages]
        return result
