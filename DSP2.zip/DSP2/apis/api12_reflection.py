"""⑫ 后台反思（深夜复盘）。

角色睡着前会自己在心里复盘：这段关系到底怎么回事，我是不是也有错，
我要不要改变一点自己的坚持。它会写出一篇 markdown 日记，并给出关系数值的微调和
特征更新建议 —— 性格的演化从这里长出来，而不是开发者改代码改出来的。
"""

from __future__ import annotations

from typing import Any, Dict

from apis.base import ApiBase, register

SYSTEM_PROMPT = """\
你正在扮演一个夜深人静、睡不着的人，在心里默默复盘自己和那个人的关系。
请以第一人称写一段真实的内心日记（markdown 小段落），并给出这次复盘带来的客观变化。

【输入】identity / state / recent_dialogue / open_hooks（未闭环的事）/ today_summary / clock

【写作要求】
1. 不要写成总结报告，也不要写"通过沟通我们可以……"这种咨询口吻。
2. 允许自我辩护、允许嘴硬、允许承认"其实我也有错"、允许突然释怀。
3. 允许**否定自己过去的坚持**（"我突然觉得，我之前坚持的那些其实挺傻的"）。
4. 结合性格：焦虑型容易反复琢磨；回避型会告诉自己别多想却停不下来；\
   高神经质容易把小事放大；高尽责会反思自己是不是没做好。
5. 篇幅 80~300 字。

【严格输出 JSON】
{
  "diary_md": "第一人称的内心日记（markdown）",
  "affection_delta": 0.0,
  "trust_delta": 0.0,
  "alignment_delta": 0.0,
  "dependency_delta": 0.0,
  "trait_update": {"tone": "", "add_catchphrase": "", "remove_catchphrase": "", "knowledge_update": ""},
  "next_move_hint": "明天打算怎么办（一句话，可以什么都不做）"
}

delta 范围 -0.1 ~ 0.1。trait_update 里不想改的字段留空字符串。
"""


@register
class ReflectionAPI(ApiBase):
    code = "⑫"
    name = "后台反思"
    system_prompt = SYSTEM_PROMPT
    max_tokens = 900

    FALLBACK: Dict[str, Any] = {
        "diary_md": "今天也没什么特别的，想了想还是算了。",
        "affection_delta": 0.0,
        "trust_delta": 0.0,
        "alignment_delta": 0.0,
        "dependency_delta": 0.0,
        "trait_update": {"tone": "", "add_catchphrase": "", "remove_catchphrase": "", "knowledge_update": ""},
        "next_move_hint": "照常",
    }

    def run(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        data = self.call_json(
            payload,
            required=["diary_md"],
            fallback=dict(self.FALLBACK),
            max_tokens=self.max_tokens,
        )
        if not isinstance(data, dict):
            return dict(self.FALLBACK)
        for key, value in self.FALLBACK.items():
            data.setdefault(key, value)
        if not isinstance(data.get("trait_update"), dict):
            data["trait_update"] = dict(self.FALLBACK["trait_update"])
        return data
