"""④ 角色情绪与生理状态。

角色是血肉之躯：会困、会病、会低血糖、会因为疲惫而敷衍。
这些波动会反过来扭曲她的性格表现（再温柔的人烧到 39 度也不会有耐心）。
"""

from __future__ import annotations

from typing import Any, Dict

from apis.base import ApiBase, register

SYSTEM_PROMPT = """\
你是一位身心状态分析师，负责判断"角色本人"现在的内在状态。
你不和用户说话，也不负责回复，只输出客观字段。

【输入】
- user_message：对方刚说的话
- recent_dialogue：最近对话
- current_state：角色当前的情绪、能量、生理状态、防御机制
- personality：大五人格与依恋类型
- clock：当前时间（深夜、加班时段、周末都会影响状态）

【判断要点】
1. 情绪不是单一标签：允许"又气又心疼""嘴上嫌弃其实很在意"这类混合状态。
2. 生理状态可由情境推演（连续熬夜→疲惫；冬天深夜→困倦；对方提起天气→可能被影响），\
   不要每次都编造重病。
3. patience_threshold：耐心阈值，越低越容易被点燃火星。
4. is_masking：明明在意却装作冷漠/无所谓（心理防御机制）。结合依恋类型：
   焦虑型更可能追问，回避型更可能装作没事。
5. energy 是 0~1 的体力/精神值，低能量时人会敷衍、慢回、少字。

【严格输出 JSON】
{
  "emotion_label": "主导情绪（可含矛盾，如'又气又委屈'）",
  "primary_emotion": "主导情绪（单一词，如'委屈'）",
  "secondary_emotion": "同时存在的次要情绪（没有就空字符串）",
  "compound_label": "把两者揉在一起的复合标签（如'又气又心疼'，单一时与主导相同）",
  "energy": 0.6,
  "physical_state": "正常 | 疲惫 | 困倦 | 生病 | 微醺 | 忙碌",
  "patience_threshold": 0.5,
  "is_masking": false,
  "is_drowsy": false,
  "needs_comfort": false,
  "reason": "一句话说明为什么会这样"
}

is_drowsy：半梦半醒、意识模糊（深夜被吵醒、困到睁不开眼）。
这时候她说的话是不过脑子的 —— 天亮之后她自己都不记得说过。
"""


@register
class CharEmotionAPI(ApiBase):
    code = "④"
    name = "角色情绪"
    system_prompt = SYSTEM_PROMPT
    max_tokens = 280

    FALLBACK: Dict[str, Any] = {
        "emotion_label": "平静",
        "primary_emotion": "平静",
        "secondary_emotion": "",
        "compound_label": "平静",
        "energy": 0.6,
        "physical_state": "正常",
        "patience_threshold": 0.6,
        "is_masking": False,
        "is_drowsy": False,
        "needs_comfort": False,
        "reason": "解析失败兜底",
    }

    def run(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        data = self.call_json(
            payload,
            required=["emotion_label"],
            fallback=dict(self.FALLBACK),
            max_tokens=self.max_tokens,
        )
        if not isinstance(data, dict):
            return dict(self.FALLBACK)
        for key, value in self.FALLBACK.items():
            data.setdefault(key, value)
        return data
