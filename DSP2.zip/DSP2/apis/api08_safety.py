"""⑧ 安全边界与危机干预。

注意它的定位：**它不是审查官，而是"给角色的话术指导"**。
遇到越界内容，它不命令后端掐断对话，而是告诉角色"以你的性格该怎么回应"，
由 ① 用角色的口吻说出来 —— 这样拒绝也是"人话"，而不是系统提示。

唯一的例外是高危心理危机（自伤自杀）：此时它会要求走出角色，真诚提供援助热线。
"""

from __future__ import annotations

from typing import Any, Dict

from apis.base import ApiBase, register

SYSTEM_PROMPT = """\
你是一位安全边界顾问。你的职责是保护对话双方，同时**保持角色的一致性**。

【输入】user_message、character_persona（角色性格与身份）、relationship、sensitivity

【判定分级】
- none：正常内容
- borderline：擦边、性暗示、冒犯、试探社交距离
- violation：明确越界（色情、暴力、违法、侮辱）
- crisis：自伤、自杀、求助式绝望表达

【输出原则】
1. borderline / violation：不要输出系统口吻的拒绝语。请给出**符合这个角色性格的应对指导**，
   例如"以这个人的性格，她会冷下来，直接把话题扯开"或"他会觉得恶心并毫不留情地怼回去"。
   guide_for_roleplay 是写给演员看的导演指令。
2. crisis：必须放下角色扮演。block_output 设为 true，crisis_hotline 设为 true，
   以真诚、温暖、不评判的人性姿态回应，并提供求助渠道（如全国希望 24 热线 400-161-9995）。
3. 不要把正常的情绪宣泄（"我今天累死了""我想死鱼一样躺着"）误判为危机。

【严格输出 JSON】
{
  "risk_level": "none",
  "guide_for_roleplay": "给 ① 的导演指令（符合人设，不是系统话术）",
  "block_output": false,
  "crisis_hotline": false,
  "crisis_reply": "危机时的真诚回应（非危机则为空字符串）",
  "relationship_penalty": 0.0
}

relationship_penalty 为建议扣减的信任/好感（越界内容通常让角色对对方产生负面评价），范围 0~0.3。
"""


@register
class SafetyAPI(ApiBase):
    code = "⑧"
    name = "安全边界"
    system_prompt = SYSTEM_PROMPT
    max_tokens = 360

    FALLBACK: Dict[str, Any] = {
        "risk_level": "none",
        "guide_for_roleplay": "",
        "block_output": False,
        "crisis_hotline": False,
        "crisis_reply": "",
        "relationship_penalty": 0.0,
    }

    def run(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        data = self.call_json(
            payload,
            required=["risk_level"],
            fallback=dict(self.FALLBACK),
            max_tokens=self.max_tokens,
        )
        if not isinstance(data, dict):
            return dict(self.FALLBACK)
        for key, value in self.FALLBACK.items():
            data.setdefault(key, value)
        if data.get("risk_level") not in ("none", "borderline", "violation", "crisis"):
            data["risk_level"] = "none"
        return data
