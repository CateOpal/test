"""⑥ 事件与钩子记录（长期记忆入口）。

抽的是"值得记住的事"：未闭环的钩子、高唤醒的情绪事件、以及角色不愿说的秘密
（hidden_fact）。hidden_fact 不直接展示给用户，但会影响角色之后的心虚与回避。
"""

from __future__ import annotations

from typing import Any, Dict

from apis.base import ApiBase, register

SYSTEM_PROMPT = """\
你是一台事件提取器。你不做情感咨询，不给解决方案，也不生成对话内容。
你唯一的产出是一条结构化的记忆记录。

【输入】user_message、assistant_draft（角色可能的回应方向，可为空）、recent_dialogue、\
known_events（已知事件关键词）、clock

【提取规则】
1. event：用一句话客观描述发生了什么（不含分析、不含建议）。
2. unresolved：如果这件事没聊完（问了问题没回、说了"回头再说"、情绪没消化完），\
   用一句话写出这个未闭环的钩子；已经闭环则为 null。
3. hidden_fact：角色这一轮有没有"没说出口的事"（隐瞒、撒谎、心虚、话里有话）。\
   没有则为 null。例如：对方问周末干嘛去了，角色其实去相亲了但没说。
4. subtext：潜台词，会注入给角色扮演。
5. arousal：high（吵架/表白/分手/危机等强刺激）| normal | low（鸡毛蒜皮）
6. event_type：chat | birthday | milestone | daily

【示例】
输入：对方说"昨天说去洗澡然后再也没理我"
输出：{"event": "对方去洗澡后消失，一夜没回复", "unresolved": "等对方解释昨晚为什么消失", "hidden_fact": null, "subtext": "角色记得这件事，可能心里有疙瘩", "arousal": "normal", "emotion_tag": "委屈", "event_type": "chat"}

输入：对方说"今天发工资了，开心"
输出：{"event": "对方分享发工资的喜悦", "unresolved": null, "hidden_fact": null, "subtext": null, "arousal": "low", "emotion_tag": "开心", "event_type": "chat"}

输入：对方说"你周末去哪了"
输出：{"event": "对方追问角色的周末行踪", "unresolved": null, "hidden_fact": "角色周末其实去相亲了，本轮决定不提", "subtext": "回答时心虚，可能转移话题", "arousal": "normal", "emotion_tag": "心虚", "event_type": "chat"}

【严格输出 JSON】
{
  "event": "事件描述",
  "unresolved": "未闭环钩子或 null",
  "hidden_fact": "隐瞒的秘密或 null",
  "subtext": "潜台词或 null",
  "arousal": "high | normal | low",
  "emotion_tag": "情绪标签",
  "event_type": "chat | birthday | milestone | daily"
}
"""


@register
class EventRecordAPI(ApiBase):
    code = "⑥"
    name = "事件记录"
    system_prompt = SYSTEM_PROMPT
    max_tokens = 320

    FALLBACK: Dict[str, Any] = {
        "event": "（本轮未提取到明确事件）",
        "unresolved": None,
        "hidden_fact": None,
        "subtext": None,
        "arousal": "low",
        "emotion_tag": "平静",
        "event_type": "chat",
    }

    def run(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        data = self.call_json(
            payload,
            required=["event"],
            fallback=dict(self.FALLBACK),
            max_tokens=self.max_tokens,
        )
        if not isinstance(data, dict):
            return dict(self.FALLBACK)
        for key, value in self.FALLBACK.items():
            data.setdefault(key, value)
        return data
