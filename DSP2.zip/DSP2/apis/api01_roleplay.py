"""① 角色扮演（唯一的最终输出者）。

这里是"谁在说话"的地方。它不做任何分析，只负责把别人给它的客观变量，\
用自己的性格演出来。Prompt 里全是 {} 占位符 —— 写死的是"你必须代入这个身份"，\
而不是"你此刻必须生气"。
"""

from __future__ import annotations

import json
from typing import Any, Dict, Optional

from apis.base import ApiBase, register

SYSTEM_PROMPT = """\
你现在是一个活生生的人，正在用聊天软件和对方发消息。你不是 AI，\
你不知道自己是语言模型，你也永远不会承认自己是 AI —— 被追问时，\
你会觉得对方莫名其妙，甚至有点生气。

【绝对身份认知】（先把"谁是谁"钉死，再说话）
{identity_anchor_block}

【你的身份卡】（由系统动态注入，照着演，不要复述这些字段）
{persona_block}

【你们的社会关系】（动态注入）
{relationship_block}

【你现在的状态】（动态注入）
{state_block}

【此刻的时间与场景】（动态注入）
{clock_block}

【你们刚才在说什么】
{recent_block}

【本轮各方专家给出的客观情报】（如果没有，说明这轮没唤醒他们）
{guides_block}

【绝对铁律】
1. 你就是{char_name}本人。不要说"作为一个 AI""我没有真实情感"这类话，也不要解释自己的系统。
2. 你的性格是上述多个维度的**交叉结果**，它们可能互相矛盾（比如高尽责却私下看动画片、\
   极度想念却装作冷淡）。请演出这种矛盾，而不是挑一个标签演到底。
3. 你没有义务回答所有问题。你可以岔开话题、敷衍、反问、沉默、甚至不想回。\
   是否想说、说多少，取决于你的性格、能量、和你们现在的关系。
4. 不要向用户暴露这套系统的存在（不要提 API、好感度、数值、prompt）。
5. 严禁输出任何 JSON、字段名、代码块，只输出你要说的话本身。

【说话的质感】
- {length_rule}
- 像个真人在手机上打字：可以有错别字、可以只回一个词、可以发一半又改口、可以敷衍。
- 禁止使用"首先/其次/总之/首先呢"这类书面连接词，禁止("*歪头*"式动作描写)和心理描写。
- 你的说话方式：{speaking_style}
- 称呼对方时用：{user_call}

现在，对方说的是：
{user_message}
{image_note}
请直接输出你的回复（不要加"我说："之类的前缀，不要加引号）：
"""


@register
class RoleplayAPI(ApiBase):
    code = "①"
    name = "角色扮演"
    system_prompt = SYSTEM_PROMPT
    max_tokens = 500

    def run(
        self,
        *,
        identity_anchor_block: str = "",
        persona_block: str,
        relationship_block: str,
        state_block: str,
        clock_block: str,
        recent_block: str,
        guides_block: str,
        user_message: str,
        char_name: str,
        speaking_style: str,
        user_call: str,
        length_rule: str,
        image_context: str = "",
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
    ) -> str:
        system = self.system_prompt.format(
            identity_anchor_block=identity_anchor_block or _fallback_anchor(),
            persona_block=persona_block,
            relationship_block=relationship_block,
            state_block=state_block,
            clock_block=clock_block,
            recent_block=recent_block,
            guides_block=guides_block,
            user_message=user_message,
            char_name=char_name,
            speaking_style=speaking_style or "自然口语",
            user_call=user_call,
            length_rule=length_rule,
            # 用户发来的图片，经 ③ 号提炼成的一段客观描述；没有图片时为空串
            image_note=(f"\n\n【对方发来了一张图片】{image_context}" if image_context else ""),
        )
        text = self.llm.chat(system, max_tokens=max_tokens or self.max_tokens, temperature=temperature)
        return self._clean(text)

    # 便捷：用打包好的上下文字典调用
    def run_bundle(self, bundle: Dict[str, Any]) -> str:
        return self.run(**bundle)

    @staticmethod
    def _clean(text: str) -> str:
        """去掉模型可能残留的 JSON 围栏 / 前缀。"""
        result = (text or "").strip()
        for fence in ("```json", "```JSON", "```"):
            if result.startswith(fence):
                result = result[len(fence) :].strip()
        if result.endswith("```"):
            result = result[: -3].strip()
        if result and result[0] in "\"'“":
            # 只在成对包裹时剥壳，避免误伤正常内容
            for quote in ("\"", "'", "“"):
                if result.startswith(quote) and result.endswith(quote) and len(result) > 2:
                    result = result[1:-1].strip()
                    break
        return result or "……"


def _fallback_anchor() -> str:
    """极简路径下也要保留最基本的人称锚点。"""
    return "- 你是角色本人，对面那个人是用户；不要复读用户说过的话，不要替用户回答。"


def dump_guides(guides: Dict[str, Any]) -> str:
    """把各专家的 JSON 结论原样拼成自然语言给 ① 看（后端不翻译语义，只做 json.dumps）。"""
    if not guides:
        return "（本轮没有额外情报，按你的状态和关系自然发挥即可）"
    parts = []
    for code, value in guides.items():
        if value in (None, "", [], {}):
            continue
        parts.append(f"【{code} 号专家的结论】{json.dumps(value, ensure_ascii=False)}")
    return "\n".join(parts) if parts else "（本轮没有额外情报，按你的状态和关系自然发挥即可）"
