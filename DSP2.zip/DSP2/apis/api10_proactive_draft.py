"""⑩ 主动消息草稿。

后台想说话时，由它起草"第一句话"。它拿到的全是客观变量：
待办定时器到点了、需求池满了、昨天那个未闭环的钩子、⑦ 给的幅度和话题切入点。
草稿会交给 ① 用角色的嘴说出来，再交给 ⑨ 排版。
"""

from __future__ import annotations

from typing import Any, Dict

from apis.base import ApiBase, register

SYSTEM_PROMPT = """\
你是一位主动搭话的起草助手。角色现在想主动给对方发一句话，\
但"怎么开口"很讲分寸 —— 请你先起草一句原始草稿。

【输入】
- trigger_reason：这次想开口的原因（定时器到期 / 需求池满了 / 想起某个未完成的事 / 深夜闲着 / 想求和）
- topic_hint：⑦ 给的话题切入点
- tone_restraint：0=放肆黏人，1=卑微克制
- persona / state / relationship / clock / open_hooks / recent_topics

【起草原则】
1. 开头要像人突然想起一件事，不要有"你好，我是来关心你的"这种客服味。
2. 克制时，一句话甚至半句就够了（"睡了吗" "那个，昨天的事"）。
3. 放肆时可以连珠炮（"在干嘛""理理我""我今天看到一只超可爱的狗"）。
4. 如果是求和/破冰，语气里的挣扎要能被看出来：想靠近又怕被拒绝。
5. 不要替对方回答，不要写小说，不要加任何描写。

【严格输出 JSON】
{
  "draft_text": "主动发的原始草稿",
  "topic": "话题标签",
  "tone": "一句话描述这次开口的分寸感"
}
"""


@register
class ProactiveDraftAPI(ApiBase):
    code = "⑩"
    name = "主动草稿"
    system_prompt = SYSTEM_PROMPT
    max_tokens = 300

    FALLBACK: Dict[str, Any] = {
        "draft_text": "在干嘛呢",
        "topic": "搭话",
        "tone": "轻描淡写地靠近",
    }

    def run(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        data = self.call_json(
            payload,
            required=["draft_text"],
            fallback=dict(self.FALLBACK),
            max_tokens=self.max_tokens,
        )
        if not isinstance(data, dict):
            return dict(self.FALLBACK)
        for key, value in self.FALLBACK.items():
            data.setdefault(key, value)
        if not str(data.get("draft_text") or "").strip():
            data["draft_text"] = self.FALLBACK["draft_text"]
        return data
