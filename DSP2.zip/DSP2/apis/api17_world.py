"""⑰ 现实日历与作息（她活在自己的时区里）。

一个有国籍、有职业的人，作息不是 24 小时在线：
- 国籍/居住地决定她的时区，她的"现在"和用户的"现在"可能日夜颠倒；
- 职业决定她的忙碌窗口（护士有夜班，学生有课，摊贩凌晨起床）；
- 节假日、生理期、考试周都会改变她能不能回消息。

这个 API 每次只算**一天的作息表**，结果缓存进 state.world_rhythm。
后端拿到表之后只做纯数值比较（现在几点 vs 睡眠窗口），
不在代码里写任何"如果是护士就怎样"的分支 —— 表本身是模型给的。

can_reply=false 的物理意义：她睡着了 / 在手术台上 / 在考场里，
这时候后台主动消息**发不出去**（不是不想，是不能）。
"""

from __future__ import annotations

from typing import Any, Dict

from apis.base import ApiBase, register

SYSTEM_PROMPT = """\
你是一位生活节律分析师。你要替一个具体的"人"排出她/他**今天**在现实世界里的作息。

【输入】
- identity：国籍、职业、年龄、生理约束（physical_constraints）、时区偏移
- user_clock：用户所在地的当前时间
- timezone_offset：她所在地相对用户的时差（小时，可正可负，0 表示同一时区）

【推算规则】
1. 先把她所在地的当前时间算出来：her_clock = user_clock + timezone_offset。
2. 按职业与年龄推睡眠窗口 sleep_window（24 小时制 HH:MM，允许跨零点，如 23:30→07:00）。
   夜班职业（护士/便利店/代驾）窗口可以整个反过来。
3. busy_windows：白天里她大概率没法看手机的时段（上课/上工/开车），最多 3 段。
4. holiday_note：按她的国籍与日期判断今天是不是她所在文化圈的节日/特殊日子，
   不是就留空；不要硬编，也不要把别国的节日安到她头上。
5. can_reply：此刻她物理上能不能回消息（睡着了/在手术室/在考场 → false）。
6. is_drowsy_window：睡眠窗口前后各延 40 分钟算"迷糊带"，这个带里被吵醒回的消息
   是半梦半醒的，第二天她自己都不记得。

【严格输出 JSON】
{
  "her_clock": "2026-10-20 07:11 周二（她所在地此刻）",
  "sleep_window": {"start": "23:30", "end": "07:00"},
  "busy_windows": [{"start": "09:00", "end": "12:00", "note": "上课"}],
  "holiday_note": "",
  "can_reply": true,
  "rhythm_note": "一句话概括她今天的节奏（写给其他专家看的客观描述）"
}
"""


@register
class WorldAPI(ApiBase):
    code = "⑰"
    name = "现实日历作息"
    system_prompt = SYSTEM_PROMPT
    max_tokens = 360

    FALLBACK: Dict[str, Any] = {
        "her_clock": "",
        # 兜底：没有节律表时按"和用户同一时区、普通人作息"处理
        "sleep_window": {"start": "23:30", "end": "07:00"},
        "busy_windows": [],
        "holiday_note": "",
        "can_reply": True,
        "rhythm_note": "",
    }

    def run(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        data = self.call_json(
            payload,
            required=["sleep_window", "can_reply"],
            fallback=dict(self.FALLBACK),
            max_tokens=self.max_tokens,
        )
        if not isinstance(data, dict):
            return dict(self.FALLBACK)
        for key, value in self.FALLBACK.items():
            data.setdefault(key, value if not isinstance(value, (dict, list)) else
                            (dict(value) if isinstance(value, dict) else list(value)))
        window = data.get("sleep_window")
        if not isinstance(window, dict) or not window.get("start") or not window.get("end"):
            data["sleep_window"] = dict(self.FALLBACK["sleep_window"])
        if not isinstance(data.get("busy_windows"), list):
            data["busy_windows"] = []
        data["busy_windows"] = [
            w for w in data["busy_windows"]
            if isinstance(w, dict) and w.get("start") and w.get("end")
        ][:3]
        data["can_reply"] = bool(data.get("can_reply", True))
        return data
