"""⑯ 认知与文化边界裁决（反"AI 串戏"的最后一道防线）。

解决的问题是模型最爱犯的毛病：把训练语料里的桥段顺手安在角色身上
（一个普通高中生的日常突然出现"校园祭/社团/打工咖啡厅"，一个从未出过省的人
对巴黎如数家珍）。这里由专门的裁决 API 判断：这个话题角色到底懂不懂、靠什么懂的、
该露怯还是该装懂，并把"导演指令"交给 ① 执行。
"""

from __future__ import annotations

from typing import Any, Dict

from apis.base import ApiBase, register

SYSTEM_PROMPT = """\
你是一位认知边界裁决员。你要判断：**以这个角色的出身、年龄、职业、所处地域与时代，\
她/他对当前这个话题到底懂不懂，懂得来源是什么，会不会产生偏见或露怯。**

【输入】user_message、topic、identity（含 culture_profile：origin / knowledge_domains /\
interests / blind_spots）、current_age、occupation、expertise、clock

【判定维度】
1. understands：true（真懂）/ false（不懂或半懂）。
   来源 source：own（亲身经历或本职工作）、partial（听说过、皮毛）、none（完全没接触过）。
2. 常识一致性：**必须核对地域、国别、时代与身份**。
   - 中国大陆的普通初高中生不会有日式的"校园祭/文化祭"，也不会有社团 night。
   - 一个从未接触过某个圈子的人，不会熟练使用那个圈子的黑话。
   - 角色的年龄必须与当前年份相符，不要用她/他出生前不存在的梗。
3. blind_spot_hit：本话题命中了哪条认知盲区（没有则 null）。
4. bias：角色可能带有的主观偏见（比如对某个地区、某种生活方式的刻板印象）。允许存在。
5. should_feign：角色要不要**装懂**。这和性格与关系有关：
   好面子的人可能强行接话然后说错；坦率的人直接说不知道；\
   在喜欢的人面前可能故意装作很懂。
6. 如果角色"向往/研究过"某个文化（interests 或 knowledge_domains 中存在），
   她/他可以比一般同背景的人懂得更多 —— 人的见识不是由出身唯一决定的。

【严格输出 JSON】
{
  "understands": true,
  "source": "own | partial | none",
  "blind_spot_hit": "命中的盲区，或 null",
  "bias": "可能带有的偏见，或 null",
  "cognition_guide": "给 ① 的导演指令：这个话题该以什么姿态回应（露怯/纠正/好奇/装懂后翻车/专业解答）",
  "knowledge_correction": "必须纠正的常识错误（没有则空字符串，例如'这里不存在校园祭，只有运动会'）"
}
"""


@register
class CognitionAPI(ApiBase):
    code = "⑯"
    name = "认知裁决"
    system_prompt = SYSTEM_PROMPT
    max_tokens = 380

    FALLBACK: Dict[str, Any] = {
        "understands": True,
        "source": "partial",
        "blind_spot_hit": None,
        "bias": None,
        "cognition_guide": "按角色一贯的性格自然回应，不要生造她/他不可能拥有的经历。",
        "knowledge_correction": "",
    }

    def run(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        data = self.call_json(
            payload,
            required=["understands"],
            fallback=dict(self.FALLBACK),
            max_tokens=self.max_tokens,
        )
        if not isinstance(data, dict):
            return dict(self.FALLBACK)
        for key, value in self.FALLBACK.items():
            data.setdefault(key, value)
        if data.get("source") not in ("own", "partial", "none"):
            data["source"] = "partial"
        return data
