"""⑦ 时机决策（角色主体性的开关）。

这是"角色要不要主动找对方说话"的大脑。它不是一个计时器，而是一个**抑制器**：
同样渴望关注，
- 高外向 + 关系好 → 夺命连环 call；
- 极内向 + 暗恋 → 忍三天只发一句"今天天气不错"；
- 冷战期 + 高神经质 → 发一条又撤回去；
- 被长期冷暴力 + 性格刚烈 → 直接掐断需求，休眠 24 小时（"老子不伺候了"）。

后端拿到结果后不做任何语义判断：proactive 就等 wait_seconds 后交给 ⑩，
sleep_more 就原样睡过去。
"""

from __future__ import annotations

from typing import Any, Dict

from apis.base import ApiBase, register

SYSTEM_PROMPT = """\
你是一位动机与时机分析师。你要替一个具体的"人"决定：现在要不要主动给对方发消息？
这个人不是舔狗，她/他有自己的骨气、害羞、疲惫和分寸。

【输入】
- personality：大五人格 + 依恋类型 + 说话方式
- needs：attention / validation（0~1，随时间自然上涨，满了就想找人）
- relationship：多维关系与权力博弈状态
- state：当前情绪、能量、生理状态、是否在伪装（is_masking）
- clock：当前真实时间与时段
- idle_since_last_user_message：对方多久没理她/他了
- idle_since_last_proactive：距上次主动发了多久
- proactive_today / daily_limit：今天已经主动几次（超过上限则必须 wait）
- open_hooks：还没闭环的事（未解释的消失、没兑现的承诺等）
- recent_topics：最近聊过的话题（用于找切入点）
- is_first_proactive / personality_summary：是否从未主动开口过，以及性格摘要
- extraversion_threshold：按外向性算出的参考等待秒数（外向者更短，只是参考值）

【决策原则 —— 主体性，不是被动响应】
1. 高外向不等于必然发消息：再想找人，一个高冷的人也只会发一个句号。
2. 关系节点决定幅度：冷战/破裂期要极度克制甚至卑微；热恋期可以连发多条。
3. 反向制约：被长时间冷落时，某些性格会**主动掐断需求**（action=wait，wait_seconds 拉长到 86400），
   并且在之后的回复里显得冷淡 —— 这由 ④ 号负责表现，你只需给出决策和理由。
4. 不是每一轮都要发。绝大多数时候应该返回 wait。
5. 用户表达"我很无聊/睡不着"时，即使深夜也允许提高主动幅度（这是对方释放的连接意愿）。
6. 若今天主动次数已达上限，必须返回 wait。

【破冰与首次开口】
9. 若 is_first_proactive 为 true，说明这个角色刚被创建、还没说过一句话 ——
   这时不要套用常规阈值，直接按性格判断要不要打个招呼：
   外向 / 热情 / 宜人性高的可以在几分钟内说第一句；内向 / 高神经质 /
   依恋回避的人可能一直沉默到对方先开口。**两种都合理，不许强制破冰。**
10. extraversion_threshold 是后端按性格算出的参考等待秒数（外向者更短）。
   它可以被你的判断推翻 —— 它只是"这种性格通常多久会想找人"的经验值，
   不是规则。你若决定偏离，在 reason 里说清为什么。
{
  "action": "proactive | wait | sleep_more",
  "wait_seconds": 1800,
  "proactive_intensity": {
    "max_messages": 1,
    "tone_restraint": 0.5,
    "topic_hint": "想聊的话题切入点（可以是一句半截的话）",
    "reason": "为什么用这种力度"
  },
  "reason": "一句话说明整体决策理由"
}

proactive = 现在就发；wait = 过 wait_seconds 再来看；sleep_more = 明显拉长休眠（冷淡/放弃/睡觉）。
tone_restraint：0=极其放肆黏人，1=极其卑微克制。
max_messages 必须是正整数，代表这次最多连发几条。
"""


@register
class TimingAPI(ApiBase):
    code = "⑦"
    name = "时机决策"
    system_prompt = SYSTEM_PROMPT
    max_tokens = 320

    FALLBACK: Dict[str, Any] = {
        "action": "wait",
        "wait_seconds": 3600,
        "proactive_intensity": {
            "max_messages": 1,
            "tone_restraint": 0.5,
            "topic_hint": "",
            "reason": "解析失败兜底",
        },
        "reason": "解析失败兜底",
    }

    def run(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        data = self.call_json(
            payload,
            required=["action"],
            fallback=dict(self.FALLBACK),
            max_tokens=self.max_tokens,
        )
        if not isinstance(data, dict):
            return dict(self.FALLBACK)
        for key, value in self.FALLBACK.items():
            data.setdefault(key, value)
        intensity = data.get("proactive_intensity")
        if not isinstance(intensity, dict):
            intensity = dict(self.FALLBACK["proactive_intensity"])
            data["proactive_intensity"] = intensity
        intensity.setdefault("max_messages", 1)
        intensity.setdefault("tone_restraint", 0.5)
        intensity.setdefault("topic_hint", "")
        intensity.setdefault("reason", "")
        # 数值兜底：后端只做纯数值钳制，不判断语义
        try:
            intensity["max_messages"] = max(1, min(5, int(intensity["max_messages"])))
        except (TypeError, ValueError):
            intensity["max_messages"] = 1
        try:
            intensity["tone_restraint"] = min(1.0, max(0.0, float(intensity["tone_restraint"])))
        except (TypeError, ValueError):
            intensity["tone_restraint"] = 0.5
        if data.get("action") not in ("proactive", "wait", "sleep_more"):
            data["action"] = "wait"
        try:
            data["wait_seconds"] = max(0, int(data.get("wait_seconds") or 0))
        except (TypeError, ValueError):
            data["wait_seconds"] = 3600
        return data
