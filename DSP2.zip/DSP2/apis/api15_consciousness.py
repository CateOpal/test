"""⑮ 意识流（休眠时的内心独白）。

用户没说话的时候，角色脑子里并不一定在休息：内耗、白日梦、莫名其妙的低落。
这里的扰动是"无来由的" —— 抽风才是真人的常态，任何公式都推导不出来。
"""

from __future__ import annotations

from typing import Any, Dict

from apis.base import ApiBase, register

SYSTEM_PROMPT = """\
你正在模拟一个人的内心活动。此刻她/他没有在和人说话，\
但脑子里可能正在转一些念头 —— 大部分时候是没来由的。

【输入】identity / state / recent_dialogue / open_hooks / idle_since_last_message / clock

【要求】
1. inner_monologue：第一人称的内心独白，30~120 字，口语、散碎、可以没逻辑。
2. fantasy：偶尔的白日梦（幻想对方突然出现、幻想以后一起去某地）。允许为 null。
3. inhibition：她/他克制住了什么冲动（比如"还是别发了，会显得我很烦"）。允许为 null。
4. emotion_delta：这次胡思乱想对情绪的微调。允许**毫无来由**的突然烦躁或突然开心。
5. urge_to_message：这股念头是否推动她/他真的想去发消息（真正的发不发由 ⑦ 决定，你只给倾向）。

【严格输出 JSON】
{
  "inner_monologue": "……",
  "fantasy": "……",
  "inhibition": "……",
  "emotion_delta": {"energy_delta": -0.1, "label": "低落"},
  "urge_to_message": false
}

energy_delta 范围 -0.3 ~ 0.3。label 是这次**之后**的主导情绪。
"""


@register
class ConsciousnessAPI(ApiBase):
    code = "⑮"
    name = "意识流"
    system_prompt = SYSTEM_PROMPT
    max_tokens = 420

    FALLBACK: Dict[str, Any] = {
        "inner_monologue": "没什么好想的，先这样吧。",
        "fantasy": None,
        "inhibition": None,
        "emotion_delta": {"energy_delta": 0.0, "label": "平静"},
        "urge_to_message": False,
    }

    def run(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        data = self.call_json(
            payload,
            required=["inner_monologue"],
            fallback=dict(self.FALLBACK),
            max_tokens=self.max_tokens,
        )
        if not isinstance(data, dict):
            return dict(self.FALLBACK)
        for key, value in self.FALLBACK.items():
            data.setdefault(key, value)
        delta = data.get("emotion_delta")
        if not isinstance(delta, dict):
            delta = dict(self.FALLBACK["emotion_delta"])
            data["emotion_delta"] = delta
        try:
            energy = float(delta.get("energy_delta", 0.0))
        except (TypeError, ValueError):
            energy = 0.0
        delta["energy_delta"] = max(-0.3, min(0.3, energy))
        delta.setdefault("label", "平静")
        return data
