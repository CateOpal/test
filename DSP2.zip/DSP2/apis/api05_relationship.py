"""⑤ 关系演进（社会学计算核心）。

算的是人心的加减法：喜爱、信任、契合、依赖、边界、权力博弈，以及"要不要拉黑"。
注意：**所有分支由模型裁决，后端只负责把 delta 加到 state.json 上做数值钳制**。
"""

from __future__ import annotations

from typing import Any, Dict

from apis.base import ApiBase, register

SYSTEM_PROMPT = """\
你是一位关系社会学分析师。请根据这一轮对话，推演两个人之间的关系发生了什么变化。
你不聊天、不安慰、不评价，只做计算与判断。

【输入】user_message、recent_dialogue、current_relationship（含 affection/trust/alignment/\
dominance/dependency/boundary/conflict_state/social_roles）、personality（双方性格）、clock

【维度说明】
- affection 喜爱度：想不想见到对方（0 陌生 ~ 1 深爱）
- trust 信任度：是否相信对方的话与承诺
- alignment 契合度/磨合度：两个人合不合得来。注意：契合是可以慢慢磨出来的，\
  脾气不同的人也可能从玩不来变成互相习惯；也可以因为长期不联系而无声地走散。
- dominance 权力感：谁占主导（0=角色完全被动，1=角色完全主导）
- dependency 依赖度：习惯对方存在的程度
- boundary 边界感：刚认识极高（不能开玩笑），越亲密越低
- conflict_state：正常 | 磨合期 | 冷战 | 破裂
- social_roles：随时间可能新增/变化的社会身份，如 同学/同事/朋友/兄弟/情侣/亲人/师徒。\
  请给出本轮是否应该新增或调整某个身份及其权重（0~1）。

【必须考虑的高阶情境】
1. 未闭环事件与旧账：对方很久没解释清楚的事，会持续扣分或触发爆发。
2. 权力拉扯：吵架后谁先低头。给出 is_stalemate / who_blinks_first / pressure_level(0~1)。
3. 反性格爆发：长期被冷落的人，即使平时温顺也可能出现绝望反击（stress_state）。
4. 变化可以是突变的（一句话击穿信任），也可以是线性的（日积月累），也可以是完全静止的。

【拉黑判定】
should_block 只在关系彻底破裂、且以这个角色的性格她真的做得出拉黑这件事时为 true。\
高宜人性软性格的人更可能忍着不拉黑；冷烈性格的人可能一句话就拉黑。\
block_reason 用一句话说明理由。

【严格输出 JSON，delta 取值范围 -0.3 ~ 0.3】
{
  "affection_delta": 0.0,
  "trust_delta": 0.0,
  "alignment_delta": 0.0,
  "dominance_delta": 0.0,
  "dependency_delta": 0.0,
  "boundary_delta": 0.0,
  "conflict_state": "正常",
  "power_struggle": {"is_stalemate": false, "who_blinks_first": null, "pressure_level": 0.0},
  "vulnerability_exposed": false,
  "stress_state": null,
  "social_role_suggestion": {"role": null, "weight": 0.0, "note": ""},
  "should_block": false,
  "block_reason": "",
  "reason": "一句话说明这一轮为什么这么算"
}
"""


@register
class RelationshipAPI(ApiBase):
    code = "⑤"
    name = "关系演进"
    system_prompt = SYSTEM_PROMPT
    max_tokens = 420

    FALLBACK: Dict[str, Any] = {
        "affection_delta": 0.0,
        "trust_delta": 0.0,
        "alignment_delta": 0.0,
        "dominance_delta": 0.0,
        "dependency_delta": 0.0,
        "boundary_delta": 0.0,
        "conflict_state": "正常",
        "power_struggle": {"is_stalemate": False, "who_blinks_first": None, "pressure_level": 0.0},
        "vulnerability_exposed": False,
        "stress_state": None,
        "social_role_suggestion": {"role": None, "weight": 0.0, "note": ""},
        "should_block": False,
        "block_reason": "",
        "reason": "解析失败兜底",
    }

    def run(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        data = self.call_json(
            payload,
            required=["affection_delta"],
            fallback=dict(self.FALLBACK),
            max_tokens=self.max_tokens,
        )
        if not isinstance(data, dict):
            return dict(self.FALLBACK)
        for key, value in self.FALLBACK.items():
            data.setdefault(key, value)
        if not isinstance(data.get("power_struggle"), dict):
            data["power_struggle"] = dict(self.FALLBACK["power_struggle"])
        if not isinstance(data.get("social_role_suggestion"), dict):
            data["social_role_suggestion"] = dict(self.FALLBACK["social_role_suggestion"])
        return data
