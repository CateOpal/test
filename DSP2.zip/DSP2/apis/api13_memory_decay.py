"""⑬ 记忆遗忘。

真实的记忆会褪色。低频、低唤醒、且没有未闭环钩子的旧事件会被归档；
高唤醒事件（吵架、表白、生日）即使很久也没那么容易忘。
"""

from __future__ import annotations

from typing import Any, Dict, List

from apis.base import ApiBase, register

SYSTEM_PROMPT = """\
你是一位记忆管理员。请判断哪些长期记忆应该被归档（遗忘），哪些必须留下。

【输入】events（长期事件列表，含 id / 时间 / 内容 / 唤醒度 / 状态）、decay_days（距上次整理的间隔天数）、today

【判断规则】
1. 高唤醒（arousal=high）或生日/里程碑类事件基本不归档，除非极其久远。
2. 仍有未闭环钩子（unresolved 非空且未处理）的事件不归档。
3. 低唤醒、日常、且很久没被想起的事件可以归档。
4. 归档不等于删除，只是不再进入短期上下文；不要把超过一半的事件一次性归档。

【严格输出 JSON】
{
  "archive_ids": [1, 2],
  "keep_ids": [3, 4],
  "summary": "一句话说明这次整理的印象"
}
"""


@register
class MemoryDecayAPI(ApiBase):
    code = "⑬"
    name = "记忆遗忘"
    system_prompt = SYSTEM_PROMPT
    max_tokens = 320

    FALLBACK: Dict[str, Any] = {"archive_ids": [], "keep_ids": [], "summary": "解析失败，暂不整理"}

    def run(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        data = self.call_json(
            payload,
            required=["archive_ids"],
            fallback=dict(self.FALLBACK),
            max_tokens=self.max_tokens,
        )
        if not isinstance(data, dict):
            return dict(self.FALLBACK)
        for key, value in self.FALLBACK.items():
            data.setdefault(key, value)
        if not isinstance(data.get("archive_ids"), list):
            data["archive_ids"] = []
        if not isinstance(data.get("keep_ids"), list):
            data["keep_ids"] = []
        clean: List[int] = []
        for item in data["archive_ids"]:
            try:
                clean.append(int(item))
            except (TypeError, ValueError):
                continue
        data["archive_ids"] = clean
        return data
