"""API 基类。

每个 API = 一份"岗位说明书"（SYSTEM_PROMPT）+ 一个 JSON 契约 + 一组兜底值。
后端只是把客观变量塞进 user 消息，收货后原样往下传。
"""

from __future__ import annotations

import json
from typing import Any, Dict, Optional, Sequence

from apis.codes import CODE_LIST


class ApiBase:
    code: str = ""          # ①
    name: str = ""          # 角色扮演
    system_prompt: str = ""
    max_tokens: int = 500

    def __init__(self, llm) -> None:
        self.llm = llm

    def _payload(self, payload: Dict[str, Any]) -> str:
        return json.dumps(payload, ensure_ascii=False)

    def call_json(
        self,
        payload: Dict[str, Any],
        *,
        required: Optional[Sequence[str]] = None,
        fallback: Optional[Any] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
    ) -> Any:
        return self.llm.chat_json(
            self.system_prompt,
            self._payload(payload),
            required=required,
            fallback=fallback if fallback is not None else {},
            max_tokens=max_tokens or self.max_tokens,
            temperature=temperature,
        )

    def call_text(
        self,
        payload: Dict[str, Any],
        *,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
    ) -> str:
        return self.llm.chat(
            self.system_prompt,
            self._payload(payload),
            json_mode=False,
            max_tokens=max_tokens or self.max_tokens,
            temperature=temperature,
        )


# ---------------------------------------------------------------- 编号常量
CODE = CODE_LIST
NAME_BY_CODE: Dict[str, str] = {}


def register(cls):
    """把 Code->名称 登记进全局表（供 UI 展示"这一轮唤醒了哪些大脑"）。"""
    NAME_BY_CODE[cls.code] = cls.name
    return cls
