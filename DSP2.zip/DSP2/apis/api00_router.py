"""⓪ 路由总控（流量指挥官）。

职责：只分流，不完形。**绝不拦截、绝不修改用户原文**。
- 敏感/越界内容 → 交给 ⑧ 安全守卫处理，而不是在这里掐掉。
- 极简短句（嗯/哦/好） → 走极速通道，只唤醒 ①。
- 输入只有"上一句 + 当前句 + 场景快照"，不读全量历史（省 token，也避免误判）。
"""

from __future__ import annotations

from typing import Any, Dict, List

from apis.base import ApiBase, register

SYSTEM_PROMPT = """\
你是一位聊天系统的调度调度员（流量指挥官）。你的唯一任务是判断：\
处理用户这一句话，需要唤醒哪些专家大脑。

【可用专家（编号即代号）】
① 角色扮演（最终说话的人，任何情况下都会被唤醒）
② 用户情绪与真实意图（看穿嘴硬、反话、隐藏诉求）
③ 话题与记忆（识别话题、敏感度、外号、定时任务、是否需要长篇输出）
④ 角色情绪与生理状态（角色现在烦不烦、累不累、生没生病）
⑤ 关系演进（好感/信任/契合/权力博弈/是否拉黑）
⑥ 事件钩子（记录值得记住的事、未闭环的钩子、隐瞒的秘密）
⑧ 安全边界与危机干预（越界、挑衅、自伤等高危信号）
⑯ 认知裁决（角色对这个话题到底懂不懂，会不会露怯或有偏见）

【绝对规则】
1. 你绝不审查内容。遇到敏感、越界、过激的话，你只负责把 ⑧ 叫醒，由它去处理。
2. 你不需要也不允许总结、转写或修改用户的话，原文会原封不动传给下游。
3. ① 永远必须在 required_apis 里。
4. 判断依据以"场景快照"为准，不要只看字面。例：关系刚破镜重圆时的一句"晚上好"，\
   不是普通日常，需要唤醒 ⑤ 做关系评估。
5. 短句要分情况：延续语境的"嗯/哦/好"走极速通道；突然的冷淡短句（语义转折）反而要唤醒 ②⑤。

【输入字段】
- user_message：用户这句话（原文）
- last_assistant_message：角色上一句话
- scene_snapshot：当前场景与关系快照（含 clock / idle / conflict_state / power_struggle / recent_topics）
- personality_snapshot：角色性格参数快照

【严格输出 JSON】
{
  "required_apis": ["①", "③"],
  "scene_intent": "light | normal | heavy | crisis",
  "is_minimal": false,
  "reason": "一句话说明为什么这么调度"
}

scene_intent 说明：light=日常寒暄，normal=普通交流，heavy=冲突/表白/分手/承诺等重大情境，\
crisis=自伤自杀等高危危机（此时必须带上 ⑧）。
"""


@register
class RouterAPI(ApiBase):
    code = "⓪"
    name = "路由总控"
    system_prompt = SYSTEM_PROMPT
    max_tokens = 260

    FALLBACK: Dict[str, Any] = {
        "required_apis": ["①", "③", "⑨"],
        "scene_intent": "normal",
        "is_minimal": False,
        "reason": "路由兜底：未取得模型结论，按核心组执行",
    }

    def run(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        data = self.call_json(
            payload,
            required=["required_apis"],
            fallback=dict(self.FALLBACK),
            max_tokens=self.max_tokens,
        )
        if not isinstance(data, dict):
            return dict(self.FALLBACK)
        apis = [str(a).strip() for a in (data.get("required_apis") or [])]
        data["required_apis"] = self._sanitize(apis)
        if not data["required_apis"]:
            data["required_apis"] = list(self.FALLBACK["required_apis"])
        data.setdefault("scene_intent", "normal")
        data.setdefault("is_minimal", False)
        data.setdefault("reason", "")
        return data

    @staticmethod
    def _sanitize(apis: List[str]) -> List[str]:
        from apis.codes import ALIAS, normalize

        result: List[str] = []
        for item in apis:
            code = normalize(item)
            if code and code not in result and code in ALIAS:
                result.append(code)
        # ① 永远在场：它是唯一的最终输出者
        if "①" not in result:
            result.insert(0, "①")
        return result
