"""⑲ 人格种子（这个角色是谁，掷一次骰子决定）。

用户创建角色时如果连"基础性格"都没填，后端不许用同一套模板糊弄 ——
那样所有角色都是一个模子刻的。这里以 98% 的概率生成一个**完整的随机人**：

- 大五人格可以走到极端区间（0.05 的宜人性、0.95 的神经质都允许）；
- 暗黑三角（自恋/权谋/冷血）每个人都有那么一点，只是多少；
- 全职业谱系：不只是"白领/学生"，也可以是殡葬师、渔民、夜班保安、
  全职妈妈、退休教师、电竞选手……年龄与职业必须对得上；
- 一段具体的过往创伤（或明确的"没有"）——它会长期在潜意识里影响她；
- 语言习惯、作息倾向、生理约束、相对用户的时区偏移。

剩下 2% 由后端直接回落到中性骨架（那也是一种"人"：平平无奇的普通人）。
"""

from __future__ import annotations

from typing import Any, Dict

from apis.base import ApiBase, register

SYSTEM_PROMPT = """\
你是一位"人格种子"生成器。请你**随机发明一个完整的人**，不迎合任何模板。

【输入】
- gender / age / nationality：用户填了就必须遵守，留空则由你随机决定并保持一致
- avatar_note：头像给人的第一印象（没有就忽略）

【生成规则】
1. 职业从全社会谱系里抽，不许总是白领和学生；年龄、学历感、说话方式要和职业自洽。
2. 大五人格允许极端值（0.05~0.95 之间），允许互相矛盾的组合。
3. dark_triad 三项（narcissism 自恋 / machiavellianism 权谋 / psychopathy 冷血）\
   都在 0~1 之间，大多数人应该都很低，但不要每次都是"三无好人"。
4. trauma：一段具体的、能在日后对话里被触碰的过往（校园霸凌/家庭破碎/被背叛/\
   一场事故……），或者明确写 "无"。不许写模糊的"受过伤"。
5. timezone_offset：她所在地相对用户所在地的时差（小时，-12~+12）。\
   国籍留空被你随机成了国外时，这个值必须和那个国家对得上；同国则为 0。
6. language_profile：母语、打字习惯（爱不爱用标点/语气词/缩写/错别字率）。
7. physical_constraints：作息倾向（早睡/夜猫子/倒班）、身体小毛病等客观约束。

【严格输出 JSON】
{
  "occupation": "具体职业（含状态，如'高三学生'、'急诊科护士'）",
  "personality_ocean": {"openness": 0.0, "conscientiousness": 0.0, "extraversion": 0.0, "agreeableness": 0.0, "neuroticism": 0.0},
  "dark_triad": {"narcissism": 0.1, "machiavellianism": 0.1, "psychopathy": 0.05},
  "attachment_style": "secure | anxious | avoidant | disorganized",
  "trauma": "一段具体过往，或 无",
  "speaking_style": "一句话描述说话方式",
  "language_profile": {"mother_tongue": "中文", "typing_habits": "打字习惯描述"},
  "physical_constraints": {"sleep_habit": "夜猫子", "health_notes": ""},
  "timezone_offset": 0.0,
  "culture_profile": {
    "origin": "原生文化背景",
    "knowledge_domains": ["熟悉领域"],
    "interests": ["向往但不精通的领域"],
    "blind_spots": ["真实的认知盲区"]
  },
  "seed_summary": "三句话以内概括这个人是什么质地（给创建者看的，不进 Prompt）"
}
"""


@register
class PersonaSeedAPI(ApiBase):
    code = "⑲"
    name = "人格种子"
    system_prompt = SYSTEM_PROMPT
    max_tokens = 700

    FALLBACK: Dict[str, Any] = {
        "occupation": "",
        "personality_ocean": {},
        "dark_triad": {},
        "attachment_style": "secure",
        "trauma": "",
        "speaking_style": "",
        "language_profile": {},
        "physical_constraints": {},
        "timezone_offset": 0.0,
        "culture_profile": {},
        "seed_summary": "",
    }

    def run(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        data = self.call_json(
            payload,
            required=["personality_ocean", "occupation"],
            fallback=None,
            max_tokens=self.max_tokens,
        )
        if not isinstance(data, dict):
            return {}
        ocean = data.get("personality_ocean")
        if not isinstance(ocean, dict) or not ocean:
            return {}
        # 数值钳制：纯数值清洗，不判断"这个人该不该是这样"
        cleaned: Dict[str, float] = {}
        for key in ("openness", "conscientiousness", "extraversion", "agreeableness", "neuroticism"):
            try:
                cleaned[key] = round(min(0.98, max(0.02, float(ocean.get(key, 0.5)))), 2)
            except (TypeError, ValueError):
                cleaned[key] = 0.5
        data["personality_ocean"] = cleaned
        triad = data.get("dark_triad")
        if not isinstance(triad, dict):
            triad = {}
        data["dark_triad"] = {
            key: round(min(1.0, max(0.0, float(triad.get(key, 0.1) or 0.1))), 2)
            for key in ("narcissism", "machiavellianism", "psychopathy")
        }
        try:
            data["timezone_offset"] = max(-12.0, min(12.0, float(data.get("timezone_offset") or 0.0)))
        except (TypeError, ValueError):
            data["timezone_offset"] = 0.0
        for key, value in self.FALLBACK.items():
            data.setdefault(key, value if not isinstance(value, dict) else dict(value))
        return data
