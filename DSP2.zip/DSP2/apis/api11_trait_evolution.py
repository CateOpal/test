"""⑪ 特征演化（被用户改变的部分）。

角色的口头禅、语气、被科普的新知识，都是和用户相处过程中慢慢长出来的。
这里只产出**候选**，后端负责计数（达到 N 次才写进 state.json）——
计数是纯数值统计，语义判断仍然在模型这。
"""

from __future__ import annotations

from typing import Any, Dict, List

from apis.base import ApiBase, register

SYSTEM_PROMPT = """\
你是一位语言习惯观察员。请从角色最近说过的话里，找出她/他被对方影响而产生的语言习惯。
你不创造新的说话方式，只做发现。

【输入】recent_character_lines（角色最近说过的话）、current_traits（已有的口头禅和语气）、\
candidates（历史候选及出现次数）、user_style（对方的说话风格）

【规则】
1. catchphrase_candidates：真正有辨识度的短句才算（带情绪色彩、重复出现、像这个人才会说的话）。
   **单字语气词（嗯、哦、好吧）一律不算**，必须是有内容的短句。
2. 如果候选历史上已经出现过，直接让它继续命中（重复命中会被后端累计，达到阈值就转正）。
3. tone_shift：语气层面的整体变化（例如"从客气变得可以互相损了"），没有则空字符串。
4. knowledge_updates：被对方科普到的新知识/新梗（用于让角色的见识随时间增长）。
5. discarded：明确建议不要再用的候选（过时、已被用户嫌弃、出现次数太少）。

【严格输出 JSON】
{
  "catchphrase_candidates": ["最多 3 个短句"],
  "tone_shift": "",
  "knowledge_updates": ["被科普的内容"],
  "discarded": ["建议丢弃的候选"]
}
"""


@register
class TraitEvolutionAPI(ApiBase):
    code = "⑪"
    name = "特征演化"
    system_prompt = SYSTEM_PROMPT
    max_tokens = 320

    FALLBACK: Dict[str, Any] = {
        "catchphrase_candidates": [],
        "tone_shift": "",
        "knowledge_updates": [],
        "discarded": [],
    }

    def run(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        data = self.call_json(
            payload,
            required=["catchphrase_candidates"],
            fallback=dict(self.FALLBACK),
            max_tokens=self.max_tokens,
        )
        if not isinstance(data, dict):
            return dict(self.FALLBACK)
        for key, value in self.FALLBACK.items():
            data.setdefault(key, value)

        def _list(value: Any, limit: int = 3) -> List[str]:
            if not isinstance(value, list):
                return []
            items = [str(v).strip() for v in value if str(v).strip()]
            return items[:limit]

        data["catchphrase_candidates"] = _list(data["catchphrase_candidates"])
        data["knowledge_updates"] = _list(data["knowledge_updates"], 5)
        data["discarded"] = _list(data["discarded"], 5)
        data["tone_shift"] = str(data.get("tone_shift") or "")
        return data
