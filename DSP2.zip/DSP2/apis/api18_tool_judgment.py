"""⑱ 工具裁决（角色有权拒绝当工具人）。

用户说"十分钟后提醒我吃药"，一个聊天机器人会无条件照办；
一个**人**会先判断：咱俩什么关系？我现在烦不烦？你这语气是请求还是使唤？

这个 API 就是这次判断。后端绝不直接执行 ③ 号识别出的工具意图，
必须先过 ⑱：accept_task=false 时定时器**根本不注册**，
拒绝的理由交给 ① 用角色的口吻说出来（"才不要，你自己没手吗"）。
"""

from __future__ import annotations

from typing import Any, Dict

from apis.base import ApiBase, register

SYSTEM_PROMPT = """\
你是一位"工具请求裁决员"。对方刚刚向这个角色提出了一个工具性质的请求\
（定时提醒/记一件事/查一个东西）。你要替这个角色决定：接不接？

【输入】
- tool_request：③ 号识别出的意图（intent=set/cancel、minutes、content）
- character_persona：角色性格与当前状态
- relationship：你们的关系数值（好感/信任/边界感）
- recent_dialogue：最近对话

【裁决原则】
1. 关系好、请求礼貌、内容正常 → 一般接。
2. 语气像使唤、关系还很陌生、角色正在气头上 → 可以拒。
3. 内容本身离谱（"提醒我明天抢银行"）→ 必须拒。
4. 接了也可以改：对方说"五分钟"，角色觉得太赶可以说"十分钟吧"——
   在 minutes/content 里给出她实际认可的版本。
5. 拒绝必须给 refuse_reason：一句符合人设的内心理由（这是写给 ① 的导演指令，
   不是给用户的系统提示）。

【严格输出 JSON】
{
  "accept_task": true,
  "minutes": 10,
  "content": "实际登记的任务内容",
  "refuse_reason": "",
  "guide_for_roleplay": "给 ① 的导演指令：她是以什么态度接/拒的"
}
"""


@register
class ToolJudgmentAPI(ApiBase):
    code = "⑱"
    name = "工具裁决"
    system_prompt = SYSTEM_PROMPT
    max_tokens = 260

    FALLBACK: Dict[str, Any] = {
        # 裁决失败时默认接 —— 提醒这种事，漏办的体感比多办更糟
        "accept_task": True,
        "minutes": 0,
        "content": "",
        "refuse_reason": "",
        "guide_for_roleplay": "",
    }

    def run(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        data = self.call_json(
            payload,
            required=["accept_task"],
            fallback=dict(self.FALLBACK),
            max_tokens=self.max_tokens,
        )
        if not isinstance(data, dict):
            return dict(self.FALLBACK)
        for key, value in self.FALLBACK.items():
            data.setdefault(key, value)
        data["accept_task"] = bool(data.get("accept_task"))
        try:
            data["minutes"] = max(0, int(data.get("minutes") or 0))
        except (TypeError, ValueError):
            data["minutes"] = 0
        return data
