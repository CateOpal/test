"""API 编号表：⓪①…⑯

⓪ 是路由总控（流量指挥官），其余 16 个是专家。
注意：编号只是代号，不代表执行顺序；真正顺序由 ⓪ 的输出列表决定。
"""

CODE_LIST = [
    "⓪", "①", "②", "③", "④", "⑤", "⑥", "⑦", "⑧",
    "⑨", "⑩", "⑪", "⑫", "⑬", "⑭", "⑮", "⑯",
]

# 编号 -> 英文代号（用于 required_apis 的兼容解析）
ALIAS = {
    "⓪": "router",
    "①": "roleplay",
    "②": "user_emotion",
    "③": "topic_memory",
    "④": "char_emotion",
    "⑤": "relationship",
    "⑥": "event_record",
    "⑦": "timing",
    "⑧": "safety",
    "⑨": "send_strategy",
    "⑩": "proactive_draft",
    "⑪": "trait_evolution",
    "⑫": "reflection",
    "⑬": "memory_decay",
    "⑭": "user_facts",
    "⑮": "consciousness",
    "⑯": "cognition",
}

# 每轮最少也要跑的核心组（保证能对话）
CORE_SET = ["①", "③", "⑨"]

# 极简短句时的极速特批通道
MINIMAL_SET = ["①"]


def normalize(item: str) -> str:
    """把 "①" / "api03" / "topic_memory" 统一成带圈数字编号。"""
    text = str(item).strip()
    if text in ALIAS:
        return text
    if text.lower() in ALIAS.values():
        for code, alias in ALIAS.items():
            if alias == text.lower():
                return code
        return ""
    # 支持 "api03_topic_memory" / "api03"
    if text.lower().startswith("api"):
        digits = "".join(ch for ch in text[3:] if ch.isdigit())
        if digits:
            index = int(digits[:2])
            if 0 <= index < len(CODE_LIST):
                return CODE_LIST[index]
    return ""
