"""API 注册表：把 17 个"大脑"一次性装配好。

编号 -> 实例。后端只认编号，不认业务，这样新增/调参都不动编排层。
"""

from __future__ import annotations

from typing import Any, Dict

from apis.api00_router import RouterAPI
from apis.api01_roleplay import RoleplayAPI
from apis.api02_user_emotion import UserEmotionAPI
from apis.api03_topic_memory import TopicMemoryAPI
from apis.api04_char_emotion import CharEmotionAPI
from apis.api05_relationship import RelationshipAPI
from apis.api06_event_record import EventRecordAPI
from apis.api07_timing import TimingAPI
from apis.api08_safety import SafetyAPI
from apis.api09_send_strategy import SendStrategyAPI
from apis.api10_proactive_draft import ProactiveDraftAPI
from apis.api11_trait_evolution import TraitEvolutionAPI
from apis.api12_reflection import ReflectionAPI
from apis.api13_memory_decay import MemoryDecayAPI
from apis.api14_user_facts import UserFactsAPI
from apis.api15_consciousness import ConsciousnessAPI
from apis.api16_cognition import CognitionAPI

BUILDERS = (
    RouterAPI,
    RoleplayAPI,
    UserEmotionAPI,
    TopicMemoryAPI,
    CharEmotionAPI,
    RelationshipAPI,
    EventRecordAPI,
    TimingAPI,
    SafetyAPI,
    SendStrategyAPI,
    ProactiveDraftAPI,
    TraitEvolutionAPI,
    ReflectionAPI,
    MemoryDecayAPI,
    UserFactsAPI,
    ConsciousnessAPI,
    CognitionAPI,
)


def build_apis(llm) -> Dict[str, Any]:
    apis: Dict[str, Any] = {}
    for builder in BUILDERS:
        instance = builder(llm)
        apis[instance.code] = instance
    return apis
