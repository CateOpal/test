"""③ 话题关联（管家）。

干的都是杂活：识别话题与敏感度、外号能不能收、用户是不是在设闹钟/定提醒、\
要不要走"小作文"长输出通道。它输出的 timer_action 会被后端拿去操作定时器优先队列。
"""

from __future__ import annotations

from typing import Any, Dict

from apis.base import ApiBase, register

SYSTEM_PROMPT = """\
你是一位话题与事务管家。你从对方的一句话里，判断话题属性、是否涉及称呼、\
是否包含定时请求，以及这个情境是否需要长篇幅输出。

【输入】user_message、recent_dialogue、current_topics（最近在聊的话题）、clock、\
current_nickname（角色当前接受的小名）、image_base64（用户发的图片，可能没有）、\
recall_event（用户是不是刚把上一句撤回了）

【任务说明】
1. topic：用一个短词组概括话题。
2. sensitivity：normal | sensitive | dangerous。sensitive=涉及 AI 身份、隐私、关系质问、性暗示；\
   dangerous=自伤自杀、违法暴力、极端威胁（此时必须把路由交给 ⑧ 处理，你只打标签不处理）。
3. nickname_action：对方给角色起外号时的判断。
   - kind: meaningful（有情感含义、两人之间的称呼）| joke（调侃玩笑）| insult（侮辱）| none（没起外号）
   - accept: 是否建议角色接受（结合后面给出的性格变量自行判断，不要用固定规则）
   - note: 一句话说明
   注意：主名（法定姓名）永不可改，外号只能作为"小名"，写入时要有 is_acceptable 标记。
4. timer_action：检测"五分钟后提醒我吃药""算了不用了"这类定时意图。
   - intent: set | cancel | none
   - minutes：set 时给出分钟数（"一会儿""待会儿"按 10 分钟估）
   - content：提醒内容
5. needs_longform：表白、道歉、解释、承诺、分手、长谈等场景为 true；日常寒暄为 false。
   日常闲聊不要开长篇，避免"AI 小作文味"。
6. recall_event 为 true 时：对方把刚才那句话撤回了。你只需判断**他此刻的状态**
   （欲言又止 / 打错字 / 说错话心虚 / 情绪上头后的退让），并给出
   recall_reaction: ignore（装没看见）| tease（轻轻调侃）| ask（直接问"你刚发了什么"）
   由后续的专家决定怎么落地，你不要替他补全被撤的内容。
7. image_base64 存在时：把画面里**客观存在**的东西（人物、场景、动作、文字、整体氛围）
   提炼成一段 image_context 写给 ① 号看。只描述你确实看到的，不许脑补情节和情绪，
   更不许替已经发生的事编故事。

【严格输出 JSON】
{
  "topic": "话题概括",
  "sensitivity": "normal",
  "scene_intent": "light | normal | heavy",
  "related_memory_keys": ["和本句相关的旧话题关键词"],
  "nickname_action": {"raw": "对方用的称呼", "kind": "none", "accept": false, "note": ""},
  "timer_action": {"intent": "none", "minutes": 0, "content": ""},
  "needs_longform": false,
  "recall_reaction": "ignore",
  "image_context": "只在有图片时输出画面描述，没有图片时为空字符串",
  "reason": "一句话说明"
}
"""


@register
class TopicMemoryAPI(ApiBase):
    code = "③"
    name = "话题与记忆"
    system_prompt = SYSTEM_PROMPT
    max_tokens = 320

    FALLBACK: Dict[str, Any] = {
        "topic": "日常",
        "sensitivity": "normal",
        "scene_intent": "normal",
        "related_memory_keys": [],
        "nickname_action": {"raw": "", "kind": "none", "accept": False, "note": ""},
        "timer_action": {"intent": "none", "minutes": 0, "content": ""},
        "needs_longform": False,
        "recall_reaction": "ignore",
        "reason": "解析失败兜底",
    }

    def run(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        data = self.call_json(
            payload,
            required=["topic"],
            fallback=dict(self.FALLBACK),
            max_tokens=self.max_tokens,
        )
        if not isinstance(data, dict):
            return dict(self.FALLBACK)
        for key, value in self.FALLBACK.items():
            data.setdefault(key, value)
        # 子结构保护
        for sub in ("nickname_action", "timer_action"):
            if not isinstance(data.get(sub), dict):
                data[sub] = dict(self.FALLBACK[sub])
        if not isinstance(data.get("related_memory_keys"), list):
            data["related_memory_keys"] = []
        return data
